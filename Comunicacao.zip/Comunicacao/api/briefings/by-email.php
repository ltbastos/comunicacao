<?php

require __DIR__ . '/../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'ok' => false,
        'message' => 'Método não permitido.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$email = trim((string) ($_POST['email'] ?? ''));

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode([
        'ok' => false,
        'message' => 'Informe um e-mail válido para continuar.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$pdo = db();

if (!$pdo instanceof PDO) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Não foi possível conectar ao banco de dados.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$normalizedEmail = strtolower($email);

try {
    $lookupName = null;

    $nameStatement = $pdo->prepare(
        'SELECT nome
         FROM usuarios_informados
         WHERE email = :email
            OR LOWER(email) = :email_lower
         LIMIT 1'
    );
    $nameStatement->execute([
        'email' => $normalizedEmail,
        'email_lower' => $normalizedEmail,
    ]);
    $storedUser = $nameStatement->fetch();

    if ($storedUser && !empty($storedUser['nome'])) {
        $lookupName = $storedUser['nome'];
    }

    if ($lookupName === null) {
        $fallbackNameStatement = $pdo->prepare(
            'SELECT nome_solicitante
             FROM briefings
             WHERE (
                    email_solicitante = :email
                    OR LOWER(email_solicitante) = :email_lower
                )
               AND nome_solicitante IS NOT NULL
               AND nome_solicitante <> ""
             ORDER BY atualizado_em DESC, id DESC
             LIMIT 1'
        );
        $fallbackNameStatement->execute([
            'email' => $normalizedEmail,
            'email_lower' => $normalizedEmail,
        ]);
        $fallbackUser = $fallbackNameStatement->fetch();

        if ($fallbackUser && !empty($fallbackUser['nome_solicitante'])) {
            $lookupName = $fallbackUser['nome_solicitante'];
        }
    }

    $upsertUser = $pdo->prepare(
        'INSERT INTO usuarios_informados (nome, email)
         VALUES (:nome, :email)
         ON DUPLICATE KEY UPDATE
            nome = COALESCE(NULLIF(VALUES(nome), ""), nome),
            atualizado_em = CURRENT_TIMESTAMP'
    );
    $upsertUser->execute([
        'nome' => $lookupName,
        'email' => $normalizedEmail,
    ]);

    $briefingStatement = $pdo->prepare(
        'SELECT
            b.id,
            b.codigo,
            b.titulo,
            COALESCE(NULLIF(b.produto_tema, ""), b.titulo) AS tema,
            COALESCE(b.data_publicacao, b.data_desejada_publicacao) AS data_publicacao_base,
            b.prazo_limite,
            COALESCE(NULLIF(b.responsavel_atual_nome, ""), "A definir") AS atendimento,
            cs.chave AS status_chave,
            cs.nome AS status_nome,
            cs.cor AS status_cor,
            (
                SELECT GROUP_CONCAT(cc.nome ORDER BY bc.ordem, bc.id SEPARATOR ", ")
                FROM briefing_canais bc
                INNER JOIN canais_comunicacao cc ON cc.id = bc.canal_id
                WHERE bc.briefing_id = b.id
            ) AS canais
         FROM briefings b
         LEFT JOIN configuracoes_status cs ON cs.id = b.status_id
         WHERE b.email_solicitante = :email
            OR LOWER(b.email_solicitante) = :email_lower
         ORDER BY
            COALESCE(b.data_publicacao, b.data_desejada_publicacao, DATE(b.criado_em)) DESC,
            b.id DESC'
    );
    $briefingStatement->execute([
        'email' => $normalizedEmail,
        'email_lower' => $normalizedEmail,
    ]);
    $briefings = $briefingStatement->fetchAll();

    $payload = array_map(static function (array $briefing) use ($normalizedEmail) {
        return [
            'id' => (int) $briefing['id'],
            'codigo' => $briefing['codigo'],
            'titulo' => $briefing['titulo'],
            'tema' => $briefing['tema'],
            'data_publicacao' => format_date_br($briefing['data_publicacao_base']),
            'prazo_limite' => format_date_br($briefing['prazo_limite'], true),
            'atendimento' => $briefing['atendimento'],
            'canais' => $briefing['canais'] ?: '',
            'status' => [
                'key' => $briefing['status_chave'] ?: '',
                'nome' => $briefing['status_nome'] ?: 'Sem status',
                'cor' => $briefing['status_cor'] ?: '#64748B',
            ],
            'can_edit' => ($briefing['status_chave'] ?? '') === 'rascunho',
            'edit_url' => ($briefing['status_chave'] ?? '') === 'rascunho'
                ? route_url('novo-briefing', ['briefing_id' => (int) $briefing['id'], 'email' => $normalizedEmail])
                : null,
        ];
    }, $briefings);

    echo json_encode([
        'ok' => true,
        'email' => $normalizedEmail,
        'nome' => $lookupName,
        'total' => count($payload),
        'briefings' => $payload,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Não foi possível consultar os briefings agora.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
