<?php

return [
    'name' => 'Central de Comunicação',
    'tagline' => 'Workflow premium para briefings, grade editorial e operação do time de Comunicação.',
    'timezone' => 'America/Sao_Paulo',
    'navigation' => [
        ['key' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'bi-grid-1x2'],
        ['key' => 'planejamento', 'label' => 'Planejamento da Grade', 'icon' => 'bi-calendar3'],
        ['key' => 'meus-briefings', 'label' => 'Meus Briefings', 'icon' => 'bi-journal-richtext'],
        ['key' => 'operacao', 'label' => 'Operacao da Comunicacao', 'icon' => 'bi-kanban'],
        ['key' => 'historico', 'label' => 'Consulta e Historico', 'icon' => 'bi-search'],
    ],
    'pages' => [
        'home' => [
            'title' => 'Central de Comunicação',
            'eyebrow' => 'Entrada principal',
            'description' => 'Escolha por onde deseja começar.',
            'layout' => 'immersive',
        ],
        'envio-briefing' => [
            'title' => 'Envie Seu Briefing',
            'eyebrow' => 'Próxima etapa',
            'description' => 'Fluxo em construção a partir da nova home.',
            'layout' => 'immersive',
        ],
        'solicitacao-grade' => [
            'title' => 'Solicitação de Grade',
            'eyebrow' => 'Próxima etapa',
            'description' => 'Fluxo em construção a partir da nova home.',
            'layout' => 'immersive',
        ],
        'encaixe' => [
            'title' => 'Solicitação de Encaixe',
            'eyebrow' => 'Próxima etapa',
            'description' => 'Fluxo em construção a partir da nova home.',
            'layout' => 'immersive',
        ],
        'acompanhar-pedidos' => [
            'title' => 'Acompanhe Seus Pedidos',
            'eyebrow' => 'Próxima etapa',
            'description' => 'Fluxo em construção a partir da nova home.',
            'layout' => 'immersive',
        ],
        'novo-briefing' => [
            'title' => 'Novo Briefing',
            'eyebrow' => 'Formulário guiado',
            'description' => 'Monte seu briefing em etapas.',
            'layout' => 'immersive',
        ],
        'dashboard' => [
            'title' => 'Dashboard',
            'eyebrow' => 'Visao executiva',
            'description' => 'Leitura rapida de volume, gargalos, proximos prazos e distribuicao da operacao.',
            'actions' => [
                ['label' => 'Ver grade do mes', 'icon' => 'bi-arrow-up-right', 'href' => 'index.php?page=planejamento', 'variant' => 'primary'],
                ['label' => 'Novo briefing', 'icon' => 'bi-plus-circle', 'href' => 'index.php?page=meus-briefings#novo-briefing', 'variant' => 'secondary'],
            ],
        ],
        'planejamento' => [
            'title' => 'Planejamento da Grade',
            'eyebrow' => 'Agenda editorial',
            'description' => 'Visao mensal da grade com capacidade, itens criticos e distribuicao por canal.',
            'actions' => [
                ['label' => 'Novo item de grade', 'icon' => 'bi-plus-circle', 'href' => '#grade-form', 'variant' => 'primary'],
            ],
        ],
        'meus-briefings' => [
            'title' => 'Meus Briefings',
            'eyebrow' => 'Solicitante',
            'description' => 'Identifique-se por e-mail, acompanhe demandas e envie novos briefings em etapas.',
            'actions' => [
                ['label' => 'Iniciar novo briefing', 'icon' => 'bi-stars', 'href' => '#novo-briefing', 'variant' => 'primary'],
            ],
        ],
        'operacao' => [
            'title' => 'Operacao da Comunicacao',
            'eyebrow' => 'Esteira operacional',
            'description' => 'Tabela operacional, pipeline visual, historico e acompanhamento por responsavel.',
            'actions' => [
                ['label' => 'Atualizar status', 'icon' => 'bi-arrow-repeat', 'href' => '#operacao-tabela', 'variant' => 'primary'],
            ],
        ],
        'historico' => [
            'title' => 'Consulta e Historico',
            'eyebrow' => 'Auditoria funcional',
            'description' => 'Busca avancada com filtros cruzados, visao detalhada e base pronta para exportacao futura.',
            'actions' => [
                ['label' => 'Buscar registros', 'icon' => 'bi-funnel', 'href' => '#filtros-historico', 'variant' => 'primary'],
            ],
        ],
        'not-found' => [
            'title' => 'Pagina nao encontrada',
            'eyebrow' => 'Navegacao',
            'description' => 'A rota solicitada nao existe nesta versao inicial da ferramenta.',
            'actions' => [
                ['label' => 'Voltar ao inicio', 'icon' => 'bi-house', 'href' => 'index.php?page=home', 'variant' => 'primary'],
            ],
        ],
    ],
];
