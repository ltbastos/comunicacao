<?php

if (!function_exists('app_config')) {
    function app_config($key = null, $default = null)
    {
        $config = $GLOBALS['app_config'] ?? [];
        return $key === null ? $config : ($config[$key] ?? $default);
    }
}

if (!function_exists('database_config')) {
    function database_config($key = null, $default = null)
    {
        $config = $GLOBALS['database_config'] ?? [];
        return $key === null ? $config : ($config[$key] ?? $default);
    }
}

if (!function_exists('mock_data')) {
    function mock_data($key = null, $default = [])
    {
        $data = $GLOBALS['mock_data'] ?? [];
        return $key === null ? $data : ($data[$key] ?? $default);
    }
}

if (!function_exists('safe')) {
    function safe($value)
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('base_url')) {
    function base_url()
    {
        static $base = null;

        if ($base !== null) {
            return $base;
        }

        $projectRoot = realpath(dirname(__DIR__));
        $documentRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath((string) $_SERVER['DOCUMENT_ROOT']) : false;

        if ($projectRoot && $documentRoot) {
            $normalizedProject = str_replace('\\', '/', $projectRoot);
            $normalizedDocument = str_replace('\\', '/', $documentRoot);

            if (stripos($normalizedProject, $normalizedDocument) === 0) {
                $relative = trim(substr($normalizedProject, strlen($normalizedDocument)), '/');
                $base = $relative === '' ? '' : '/' . $relative;
                return $base;
            }
        }

        $directory = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
        $base = ($directory === '/' || $directory === '.') ? '' : rtrim($directory, '/');

        return $base;
    }
}

if (!function_exists('asset_url')) {
    function asset_url($path)
    {
        return base_url() . '/' . ltrim($path, '/');
    }
}

if (!function_exists('route_url')) {
    function route_url($page = 'home', array $query = [])
    {
        return base_url() . '/index.php?' . http_build_query(array_merge(['page' => $page], $query));
    }
}

if (!function_exists('nav_items')) {
    function nav_items()
    {
        return app_config('navigation', []);
    }
}

if (!function_exists('current_page')) {
    function current_page()
    {
        $page = $_GET['page'] ?? 'home';
        $pages = app_config('pages', []);
        return array_key_exists($page, $pages) ? $page : 'not-found';
    }
}

if (!function_exists('page_meta')) {
    function page_meta($page = null)
    {
        $pages = app_config('pages', []);
        $page = $page ?: current_page();
        return $pages[$page] ?? [];
    }
}

if (!function_exists('page_actions')) {
    function page_actions($page = null)
    {
        $meta = page_meta($page);
        return $meta['actions'] ?? [];
    }
}

if (!function_exists('page_body_class')) {
    function page_body_class()
    {
        return 'page-' . current_page();
    }
}

if (!function_exists('is_immersive_layout')) {
    function is_immersive_layout($page = null)
    {
        $meta = page_meta($page);
        return ($meta['layout'] ?? 'app') === 'immersive';
    }
}

if (!function_exists('is_active_page')) {
    function is_active_page($key)
    {
        return current_page() === $key;
    }
}

if (!function_exists('format_date_br')) {
    function format_date_br($date, $withTime = false)
    {
        if (empty($date)) {
            return 'Sem data';
        }

        try {
            $dateTime = new DateTimeImmutable($date);
        } catch (Exception $exception) {
            return (string) $date;
        }

        return $dateTime->format($withTime ? 'd/m/Y H:i' : 'd/m/Y');
    }
}

if (!function_exists('tone_class')) {
    function tone_class($tone)
    {
        return 'is-' . strtolower(preg_replace('/[^a-z0-9_-]/i', '', (string) $tone));
    }
}

if (!function_exists('status_meta')) {
    function status_meta($key)
    {
        $map = mock_data('status_map', []);
        return $map[$key] ?? ['label' => ucwords(str_replace('_', ' ', (string) $key)), 'tone' => 'info'];
    }
}

if (!function_exists('priority_meta')) {
    function priority_meta($key)
    {
        $map = mock_data('priority_map', []);
        return $map[$key] ?? ['label' => ucwords(str_replace('_', ' ', (string) $key)), 'tone' => 'neutral'];
    }
}

if (!function_exists('db')) {
    function db()
    {
        static $connection = false;

        if ($connection !== false) {
            return $connection;
        }

        $config = database_config();

        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                $config['host'] ?? '127.0.0.1',
                $config['port'] ?? 3306,
                $config['database'] ?? '',
                $config['charset'] ?? 'utf8mb4'
            );

            $connection = new PDO(
                $dsn,
                $config['username'] ?? 'root',
                $config['password'] ?? '',
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (Throwable $throwable) {
            $connection = null;
        }

        return $connection;
    }
}

if (!function_exists('database_status')) {
    function database_status()
    {
        $connected = db() instanceof PDO;

        return [
            'connected' => $connected,
            'label' => $connected ? 'Banco conectado' : 'Modo demonstracao',
            'database' => database_config('database', 'comunicacao_hub'),
        ];
    }
}

if (!function_exists('calendar_matrix')) {
    function calendar_matrix($year, $month, array $items)
    {
        $firstDay = new DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month));
        $start = $firstDay;

        while ((int) $start->format('N') !== 1) {
            $start = $start->modify('-1 day');
        }

        $lastDay = $firstDay->modify('last day of this month');
        $end = $lastDay;

        while ((int) $end->format('N') !== 7) {
            $end = $end->modify('+1 day');
        }

        $itemsByDate = [];

        foreach ($items as $item) {
            $itemsByDate[$item['date']][] = $item;
        }

        $weeks = [];
        $current = $start;
        $week = [];

        while ($current <= $end) {
            $dateKey = $current->format('Y-m-d');
            $week[] = [
                'date' => $dateKey,
                'day' => $current->format('d'),
                'current_month' => (int) $current->format('n') === (int) $month,
                'is_today' => $dateKey === date('Y-m-d'),
                'items' => $itemsByDate[$dateKey] ?? [],
            ];

            if ((int) $current->format('N') === 7) {
                $weeks[] = $week;
                $week = [];
            }

            $current = $current->modify('+1 day');
        }

        return $weeks;
    }
}

if (!function_exists('briefings_by_status')) {
    function briefings_by_status(array $briefings)
    {
        $grouped = [];

        foreach ($briefings as $briefing) {
            $grouped[$briefing['status']][] = $briefing;
        }

        return $grouped;
    }
}
