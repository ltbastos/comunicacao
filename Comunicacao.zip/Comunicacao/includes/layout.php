<?php $databaseState = database_status(); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo safe(($pageMeta['title'] ?? app_config('name')) . ' | ' . app_config('name')); ?></title>
    <meta name="description" content="<?php echo safe(app_config('tagline')); ?>">
    <script>
        (function () {
            try {
                var savedTheme = localStorage.getItem('comunicacao_theme');
                if (savedTheme === 'light') {
                    document.documentElement.classList.add('theme-light');
                }
            } catch (error) {}
        })();
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Poppins:wght@400;500;600;700;800&family=Sora:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?php echo safe(asset_url('assets/css/app.css')); ?>">
</head>
<body class="<?php echo safe(page_body_class()); ?>">
    <?php if (is_immersive_layout($page)): ?>
        <main class="immersive-page">
            <?php require $viewFile; ?>
        </main>
    <?php else: ?>
        <button class="theme-toggle" id="themeToggle" type="button" aria-pressed="false" title="Alternar tema">
            <i class="bi bi-moon-stars-fill theme-toggle__icon theme-toggle__icon--dark"></i>
            <i class="bi bi-sun-fill theme-toggle__icon theme-toggle__icon--light"></i>
            <span class="theme-toggle__label">Modo claro</span>
        </button>

        <div class="app-shell">
            <?php require __DIR__ . '/sidebar.php'; ?>

            <div class="app-main">
                <?php require __DIR__ . '/header.php'; ?>
                <main class="page-content">
                    <?php require $viewFile; ?>
                </main>
            </div>
        </div>
    <?php endif; ?>

    <div class="toast-stack" id="toastStack" aria-live="polite" aria-atomic="true"></div>

    <div class="send-celebration" id="sendCelebration" aria-hidden="true">
        <div class="send-celebration__backdrop"></div>
        <div class="send-celebration__card">
            <div class="send-celebration__halo"></div>
            <div class="send-celebration__scene">
                <svg class="send-celebration__plane" viewBox="0 0 150 150" aria-hidden="true">
                    <path class="send-celebration__plane-trail" d="M12 92L34 78"></path>
                    <path class="send-celebration__plane-trail" d="M14 110L42 90"></path>
                    <path class="send-celebration__plane-trail" d="M24 126L46 110"></path>
                    <path class="send-celebration__plane-line" d="M24 72L120 38L82 126L68 86L24 72Z"></path>
                    <path class="send-celebration__plane-line" d="M24 72L68 86"></path>
                    <path class="send-celebration__plane-line" d="M68 86L120 38"></path>
                    <path class="send-celebration__plane-line" d="M68 86L82 126"></path>
                </svg>
            </div>
            <strong>Enviado</strong>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
    <script src="<?php echo safe(asset_url('assets/js/app.js')); ?>"></script>
</body>
</html>
