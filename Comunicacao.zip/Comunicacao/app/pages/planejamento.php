<?php
require __DIR__ . '/_direct-access.php';

$grade = mock_data('grade', []);
$period = $grade['period'];
$calendar = calendar_matrix($period['year'], $period['month'], $grade['items']);
$outsideItems = [];

foreach ($grade['items'] as $item) {
    if (empty($item['in_plan'])) {
        $outsideItems[] = $item;
    }
}
?>

<section class="section-stack">
    <div class="planner-overview">
        <article class="surface-card planner-highlight">
            <span class="eyebrow">Competencia ativa</span>
            <h2><?php echo safe($period['label']); ?></h2>
            <p>Agenda editorial com leitura mensal, pressao por canal e sinalizacao imediata do que esta fora da grade.</p>
        </article>
        <article class="surface-card planner-stat"><strong>8</strong><span>itens planejados</span></article>
        <article class="surface-card planner-stat"><strong>2</strong><span>dias com ocupacao critica</span></article>
        <article class="surface-card planner-stat"><strong>1</strong><span>item fora da grade</span></article>
    </div>

    <div class="surface-card filter-panel">
        <div class="filter-row">
            <button class="filter-chip is-active" type="button">Abril</button>
            <button class="filter-chip" type="button">Todos os canais</button>
            <button class="filter-chip" type="button">Dentro da grade</button>
            <button class="filter-chip" type="button">Alta prioridade</button>
            <button class="filter-chip" type="button">Com atrasos</button>
        </div>
    </div>
</section>

<section class="planner-layout">
    <article class="surface-card calendar-shell">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Visual mensal</span>
                <h3>Grade editorial</h3>
            </div>
            <span class="meta-chip is-neutral">Planner</span>
        </div>

        <div class="calendar-weekdays">
            <span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sab</span><span>Dom</span>
        </div>

        <div class="calendar-grid">
            <?php foreach ($calendar as $week): ?>
                <?php foreach ($week as $day): ?>
                    <div class="calendar-day <?php echo !$day['current_month'] ? 'is-muted' : ''; ?> <?php echo $day['is_today'] ? 'is-today' : ''; ?>">
                        <div class="calendar-day-header">
                            <span><?php echo safe($day['day']); ?></span>
                            <?php if (!empty($day['items'])): ?>
                                <span class="mini-badge <?php echo safe(tone_class(count($day['items']) > 1 ? 'warning' : 'info')); ?>">
                                    <?php echo safe(count($day['items'])); ?> item(ns)
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="calendar-items">
                            <?php foreach (array_slice($day['items'], 0, 2) as $item): ?>
                                <?php $priority = priority_meta($item['priority']); ?>
                                <article class="calendar-item">
                                    <span class="calendar-item-channel" style="background: <?php echo safe($item['channel_color']); ?>"></span>
                                    <div>
                                        <strong><?php echo safe($item['title']); ?></strong>
                                        <p><?php echo safe($item['channel']); ?> • <?php echo safe($item['area']); ?></p>
                                    </div>
                                    <span class="mini-badge <?php echo safe(tone_class($priority['tone'])); ?>"><?php echo safe($priority['label']); ?></span>
                                </article>
                            <?php endforeach; ?>

                            <?php if (count($day['items']) > 2): ?>
                                <span class="calendar-more">+<?php echo safe(count($day['items']) - 2); ?> itens</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
    </article>

    <aside class="planner-side">
        <article class="surface-card">
            <div class="section-heading">
                <div>
                    <span class="eyebrow">Capacidade</span>
                    <h3>Uso por canal</h3>
                </div>
            </div>

            <div class="capacity-list">
                <?php foreach ($grade['capacity'] as $capacity): ?>
                    <?php $percentage = (int) round(($capacity['used'] / $capacity['limit']) * 100); ?>
                    <div class="capacity-row">
                        <div class="capacity-copy">
                            <strong><?php echo safe($capacity['channel']); ?></strong>
                            <span><?php echo safe($capacity['used']); ?>/<?php echo safe($capacity['limit']); ?> slots</span>
                        </div>
                        <div class="capacity-bar"><span style="width: <?php echo safe($percentage); ?>%"></span></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>

        <article class="surface-card">
            <div class="section-heading">
                <div>
                    <span class="eyebrow">Fora da grade</span>
                    <h3>Itens para triagem</h3>
                </div>
            </div>

            <div class="stack-list">
                <?php foreach ($outsideItems as $item): ?>
                    <?php $priority = priority_meta($item['priority']); ?>
                    <article class="list-row compact">
                        <div>
                            <strong><?php echo safe($item['title']); ?></strong>
                            <p><?php echo safe($item['area']); ?> • <?php echo safe(format_date_br($item['date'])); ?></p>
                        </div>
                        <span class="status-badge <?php echo safe(tone_class($priority['tone'])); ?>"><?php echo safe($priority['label']); ?></span>
                    </article>
                <?php endforeach; ?>
            </div>
        </article>

        <article class="surface-card" id="grade-form">
            <div class="section-heading">
                <div>
                    <span class="eyebrow">Acao rapida</span>
                    <h3>Novo item de grade</h3>
                </div>
            </div>

            <form class="compact-form" data-demo-form="grade">
                <label>
                    <span>Titulo</span>
                    <input type="text" placeholder="Ex.: Campanha de beneficios">
                </label>
                <label>
                    <span>Canal</span>
                    <select><option>Intranet</option><option>E-mail Marketing</option><option>Portal</option></select>
                </label>
                <label>
                    <span>Data prevista</span>
                    <input type="date" value="2026-04-24">
                </label>
                <button class="action-button primary full" type="submit">
                    <i class="bi bi-plus-circle"></i>
                    <span>Salvar item</span>
                </button>
            </form>
        </article>
    </aside>
</section>
