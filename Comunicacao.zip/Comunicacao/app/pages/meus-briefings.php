<?php
require __DIR__ . '/_direct-access.php';

$briefings = mock_data('briefings', []);
$steps = ['Identificacao', 'Objetivo', 'Canal e publico', 'Conteudo', 'Datas e links', 'Revisao'];
?>

<section class="content-grid-two">
    <article class="surface-card identity-panel">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Identificacao funcional</span>
                <h3>Informe seu e-mail para continuar</h3>
            </div>
        </div>

        <form class="identity-form" id="identityForm">
            <label>
                <span>Nome</span>
                <input type="text" id="identityName" placeholder="Seu nome">
            </label>
            <label>
                <span>E-mail</span>
                <input type="email" id="identityEmail" placeholder="voce@empresa.com.br">
            </label>
            <button class="action-button primary full" type="submit">
                <i class="bi bi-person-check"></i>
                <span>Usar este identificador</span>
            </button>
        </form>

        <div class="info-banner">
            <i class="bi bi-info-circle"></i>
            <p>Sem autenticacao real: o e-mail informado serve apenas para associar e consultar os briefings.</p>
        </div>
    </article>

    <article class="surface-card wizard-summary">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Fluxo guiado</span>
                <h3>Formulario em etapas</h3>
            </div>
        </div>

        <div class="wizard-mini-steps">
            <?php foreach ($steps as $index => $step): ?>
                <div class="mini-step <?php echo $index === 0 ? 'is-active' : ''; ?>">
                    <span><?php echo safe($index + 1); ?></span>
                    <strong><?php echo safe($step); ?></strong>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="decision-list">
            <div class="decision-item">
                <i class="bi bi-save"></i>
                <div>
                    <strong>Salvar rascunho</strong>
                    <p>Permite continuar depois sem perder o contexto preenchido.</p>
                </div>
            </div>
            <div class="decision-item">
                <i class="bi bi-eye"></i>
                <div>
                    <strong>Revisar antes de enviar</strong>
                    <p>Evita retrabalho e melhora a qualidade de entrada para Comunicacao.</p>
                </div>
            </div>
        </div>
    </article>
</section>

<section class="surface-card">
    <div class="section-heading">
        <div>
            <span class="eyebrow">Consulta pessoal</span>
            <h3>Meus briefings</h3>
        </div>
        <span class="meta-chip is-neutral" id="identityPill">Exibindo demonstracao geral</span>
    </div>

    <div class="briefing-card-grid" id="briefingCards">
        <?php foreach ($briefings as $briefing): ?>
            <?php $status = status_meta($briefing['status']); ?>
            <?php $priority = priority_meta($briefing['priority']); ?>
            <article class="briefing-card" data-briefing-email="<?php echo safe(strtolower($briefing['email'])); ?>">
                <div class="briefing-card-head">
                    <span class="briefing-code"><?php echo safe($briefing['code']); ?></span>
                    <span class="status-badge <?php echo safe(tone_class($status['tone'])); ?>"><?php echo safe($status['label']); ?></span>
                </div>
                <h4><?php echo safe($briefing['title']); ?></h4>
                <p><?php echo safe($briefing['summary']); ?></p>
                <div class="briefing-meta">
                    <span><i class="bi bi-building"></i> <?php echo safe($briefing['area']); ?></span>
                    <span><i class="bi bi-broadcast"></i> <?php echo safe($briefing['channel']); ?></span>
                    <span><i class="bi bi-calendar-event"></i> <?php echo safe(format_date_br($briefing['publish'])); ?></span>
                </div>
                <div class="briefing-card-footer">
                    <span class="mini-badge <?php echo safe(tone_class($priority['tone'])); ?>"><?php echo safe($priority['label']); ?></span>
                    <small>Atualizado em <?php echo safe(format_date_br($briefing['updated_at'], true)); ?></small>
                </div>
            </article>
        <?php endforeach; ?>
    </div>

    <div class="empty-state" id="briefingEmptyState" hidden>
        <i class="bi bi-search"></i>
        <strong>Nenhum briefing encontrado para este e-mail.</strong>
        <p>Use o wizard abaixo para abrir uma nova solicitacao ou altere a identificacao informada.</p>
    </div>
</section>

<section class="surface-card wizard-shell" id="novo-briefing">
    <div class="wizard-header">
        <div>
            <span class="eyebrow">Novo briefing</span>
            <h3>Solicitacao guiada em seis etapas</h3>
        </div>
        <div class="wizard-progress">
            <span id="wizardProgressLabel">Etapa 1 de 6</span>
            <div class="progress-bar"><span id="wizardProgressBar" style="width: 16.67%;"></span></div>
        </div>
    </div>

    <div class="wizard-stepper" id="wizardStepper">
        <?php foreach ($steps as $index => $step): ?>
            <button class="wizard-step <?php echo $index === 0 ? 'is-active' : ''; ?>" type="button" data-step-trigger="<?php echo safe($index + 1); ?>">
                <span><?php echo safe($index + 1); ?></span>
                <strong><?php echo safe($step); ?></strong>
            </button>
        <?php endforeach; ?>
    </div>

    <form id="briefingWizard" class="wizard-form">
        <section class="wizard-panel is-active" data-step-panel="1">
            <div class="form-grid two-columns">
                <label>
                    <span>Titulo da demanda</span>
                    <input type="text" placeholder="Ex.: Campanha de reconhecimento interno">
                </label>
                <label>
                    <span>Area solicitante</span>
                    <select><option>RH</option><option>Comercial</option><option>TI</option><option>Juridico</option></select>
                </label>
                <label>
                    <span>Nome do solicitante</span>
                    <input type="text" id="wizardName" placeholder="Seu nome">
                </label>
                <label>
                    <span>E-mail do solicitante</span>
                    <input type="email" id="wizardEmail" placeholder="voce@empresa.com.br">
                </label>
                <label class="full-span">
                    <span>Descricao resumida</span>
                    <textarea rows="4" placeholder="Explique rapidamente o que precisa ser comunicado e o contexto imediato."></textarea>
                </label>
            </div>
        </section>

        <section class="wizard-panel" data-step-panel="2">
            <div class="form-grid two-columns">
                <label class="full-span">
                    <span>Objetivo da comunicacao</span>
                    <textarea rows="4" placeholder="Qual comportamento, acao ou entendimento voce quer gerar?"></textarea>
                </label>
                <label class="full-span">
                    <span>Contexto / historico</span>
                    <textarea rows="5" placeholder="Traga dados, antecedentes e o que ja aconteceu ate aqui."></textarea>
                </label>
            </div>
        </section>

        <section class="wizard-panel" data-step-panel="3">
            <div class="form-grid three-columns">
                <label>
                    <span>Canal desejado</span>
                    <select><option>Intranet</option><option>E-mail Marketing</option><option>LinkedIn</option><option>Portal</option></select>
                </label>
                <label>
                    <span>Publico-alvo</span>
                    <input type="text" placeholder="Ex.: liderancas e gestores">
                </label>
                <label>
                    <span>Segmento</span>
                    <input type="text" placeholder="Ex.: colaboradores administrativos">
                </label>
                <label>
                    <span>Produto / tema</span>
                    <input type="text" placeholder="Ex.: mentoria executiva">
                </label>
                <label>
                    <span>Prioridade percebida</span>
                    <select><option>Media</option><option>Alta</option><option>Critica</option></select>
                </label>
                <label>
                    <span>Esta na grade?</span>
                    <select><option>Sim</option><option>Nao</option><option>Nao sei</option></select>
                </label>
            </div>
        </section>

        <section class="wizard-panel" data-step-panel="4">
            <div class="form-grid two-columns">
                <label class="full-span">
                    <span>Mensagem principal</span>
                    <textarea rows="4" placeholder="Qual e a mensagem-chave que nao pode se perder?"></textarea>
                </label>
                <label class="full-span">
                    <span>CTA / acao desejada</span>
                    <textarea rows="3" placeholder="O que a pessoa precisa fazer depois da comunicacao?"></textarea>
                </label>
                <label class="full-span">
                    <span>Referencias e observacoes</span>
                    <textarea rows="4" placeholder="Ex.: links de benchmark, pecas anteriores, tom desejado, restricoes."></textarea>
                </label>
            </div>
        </section>

        <section class="wizard-panel" data-step-panel="5">
            <div class="form-grid three-columns">
                <label>
                    <span>Data ideal de publicacao</span>
                    <input type="date" value="2026-04-25">
                </label>
                <label>
                    <span>Prazo limite</span>
                    <input type="date" value="2026-04-21">
                </label>
                <label>
                    <span>Links de apoio</span>
                    <input type="url" placeholder="https://...">
                </label>
                <label class="full-span">
                    <span>Observacoes adicionais</span>
                    <textarea rows="4" placeholder="Anexos ficam preparados para uma evolucao futura do fluxo."></textarea>
                </label>
            </div>
        </section>

        <section class="wizard-panel" data-step-panel="6">
            <div class="review-grid">
                <article class="review-card">
                    <span class="eyebrow">Checklist</span>
                    <ul>
                        <li>Identificacao funcional preenchida</li>
                        <li>Objetivo e contexto descritos</li>
                        <li>Canal, publico e prioridade informados</li>
                        <li>Mensagem principal e CTA definidos</li>
                        <li>Datas e referencias revisadas</li>
                    </ul>
                </article>
                <article class="review-card">
                    <span class="eyebrow">Proxima etapa</span>
                    <p>Ao enviar, o briefing entra na esteira da Comunicacao com historico e status rastreaveis.</p>
                </article>
            </div>
        </section>

        <div class="wizard-actions">
            <button class="action-button secondary" type="button" data-step-prev>
                <i class="bi bi-arrow-left"></i>
                <span>Voltar</span>
            </button>
            <div class="wizard-actions-right">
                <button class="action-button ghost" type="button" data-demo-submit="draft">
                    <i class="bi bi-save"></i>
                    <span>Salvar rascunho</span>
                </button>
                <button class="action-button primary" type="button" data-step-next>
                    <i class="bi bi-arrow-right"></i>
                    <span>Avancar</span>
                </button>
                <button class="action-button primary is-hidden" type="button" id="submitBriefing" data-demo-submit="send">
                    <i class="bi bi-send-check"></i>
                    <span>Enviar briefing</span>
                </button>
            </div>
        </div>
    </form>
</section>
