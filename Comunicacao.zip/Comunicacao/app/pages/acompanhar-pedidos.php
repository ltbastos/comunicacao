<?php
require __DIR__ . '/_direct-access.php';
?>

<section class="immersive-placeholder">
    <div class="immersive-placeholder__card">
        <span class="immersive-placeholder__eyebrow">Nova tela em seguida</span>
        <h1>Acompanhe seus pedidos</h1>
        <p>O acompanhamento em tempo real sera a proxima camada desta nova experiencia.</p>
        <a class="immersive-placeholder__back" href="<?php echo safe(route_url('home')); ?>">
            <i class="bi bi-arrow-left"></i>
            <span>Voltar</span>
        </a>
    </div>
</section>
