<?php
require __DIR__ . '/_direct-access.php';

$dashboard = mock_data('dashboard', []);
?>

<section class="hero-card">
    <div class="hero-copy">
        <span class="eyebrow">Central operacional</span>
        <h2>Um painel unico para visualizar demanda, capacidade e risco operacional.</h2>
        <p>
            Esta base inicial ja nasce com linguagem visual premium, estrutura pronta para dados reais e
            foco em navegacao rapida para times de Comunicacao que precisam decidir com clareza.
        </p>
        <div class="hero-actions">
            <a class="action-button primary" href="<?php echo safe(route_url('operacao')); ?>">
                <i class="bi bi-kanban"></i>
                <span>Entrar na operacao</span>
            </a>
            <a class="action-button ghost" href="<?php echo safe(route_url('meus-briefings')); ?>">
                <i class="bi bi-journal-richtext"></i>
                <span>Ver meus briefings</span>
            </a>
        </div>
    </div>

    <div class="hero-panel">
        <div class="hero-panel-card">
            <span class="panel-kicker">Panorama do mes</span>
            <strong>82%</strong>
            <p>da capacidade editorial esta ocupada para abril, com maior pressao em E-mail Marketing.</p>
        </div>
        <div class="hero-panel-card">
            <span class="panel-kicker">Janela critica</span>
            <strong>3 itens</strong>
            <p>precisam de decisao hoje para evitar atraso ou reagendamento da grade.</p>
        </div>
    </div>
</section>

<section class="kpi-grid" id="dashboard-kpis">
    <?php foreach ($dashboard['kpis'] as $kpi): ?>
        <article class="surface-card kpi-card">
            <div class="kpi-icon <?php echo safe(tone_class($kpi['tone'])); ?>">
                <i class="bi <?php echo safe($kpi['icon']); ?>"></i>
            </div>
            <div class="kpi-content">
                <span><?php echo safe($kpi['label']); ?></span>
                <strong><?php echo safe($kpi['value']); ?></strong>
                <small><?php echo safe($kpi['delta']); ?></small>
            </div>
        </article>
    <?php endforeach; ?>
</section>

<section class="analytics-grid">
    <article class="surface-card chart-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Distribuicao</span>
                <h3>Status da esteira</h3>
            </div>
            <span class="meta-chip is-neutral">Operacao atual</span>
        </div>
        <canvas class="chart-canvas" data-chart-config="<?php echo safe(json_encode($dashboard['status_chart'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?>"></canvas>
    </article>

    <article class="surface-card chart-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Volume</span>
                <h3>Demandas por canal</h3>
            </div>
            <span class="meta-chip is-neutral">Abril 2026</span>
        </div>
        <canvas class="chart-canvas" data-chart-config="<?php echo safe(json_encode($dashboard['channel_chart'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?>"></canvas>
    </article>
</section>

<section class="content-grid-two">
    <article class="surface-card list-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Atencao imediata</span>
                <h3>Itens criticos</h3>
            </div>
        </div>

        <div class="stack-list">
            <?php foreach ($dashboard['critical_items'] as $item): ?>
                <?php $status = status_meta($item['status']); ?>
                <article class="list-row">
                    <div>
                        <strong><?php echo safe($item['title']); ?></strong>
                        <p><?php echo safe($item['code']); ?> • <?php echo safe($item['owner']); ?></p>
                    </div>
                    <div class="row-meta">
                        <span class="status-badge <?php echo safe(tone_class($status['tone'])); ?>"><?php echo safe($status['label']); ?></span>
                        <small><?php echo safe(format_date_br($item['due'])); ?></small>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </article>

    <article class="surface-card list-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Agenda</span>
                <h3>Proximas publicacoes</h3>
            </div>
        </div>

        <div class="stack-list">
            <?php foreach ($dashboard['upcoming'] as $item): ?>
                <article class="list-row">
                    <div>
                        <strong><?php echo safe($item['title']); ?></strong>
                        <p><?php echo safe($item['channel']); ?> • <?php echo safe($item['area']); ?></p>
                    </div>
                    <div class="row-meta">
                        <small><?php echo safe(format_date_br($item['date'])); ?></small>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </article>
</section>

<section class="content-grid-two">
    <article class="surface-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Distribuicao por pessoa</span>
                <h3>Carga por responsavel</h3>
            </div>
        </div>

        <div class="owner-grid">
            <?php foreach ($dashboard['owners'] as $owner): ?>
                <div class="owner-card">
                    <strong><?php echo safe($owner['name']); ?></strong>
                    <div class="owner-metrics">
                        <span><?php echo safe($owner['active']); ?> ativos</span>
                        <span><?php echo safe($owner['published']); ?> publicados</span>
                    </div>
                    <span class="mini-badge <?php echo safe(tone_class($owner['risk'] === 'alto' ? 'danger' : ($owner['risk'] === 'moderado' ? 'warning' : 'success'))); ?>">
                        Risco <?php echo safe($owner['risk']); ?>
                    </span>
                </div>
            <?php endforeach; ?>
        </div>
    </article>

    <article class="surface-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Leitura rapida</span>
                <h3>Proximos passos recomendados</h3>
            </div>
        </div>

        <div class="decision-list">
            <div class="decision-item">
                <i class="bi bi-arrow-up-right-circle"></i>
                <div>
                    <strong>Redistribuir E-mail Marketing</strong>
                    <p>Canal no limite da capacidade. Priorizar town hall e seguranca da informacao.</p>
                </div>
            </div>
            <div class="decision-item">
                <i class="bi bi-hourglass-split"></i>
                <div>
                    <strong>Validar pendencias em aberto</strong>
                    <p>Seis itens dependem de retorno externo. Tratar com SLA visivel para o solicitante.</p>
                </div>
            </div>
            <div class="decision-item">
                <i class="bi bi-check2-square"></i>
                <div>
                    <strong>Fechar pauta da semana 3</strong>
                    <p>A grade de 15 a 22/04 pode ser travada apos aprovacao de duas campanhas-chave.</p>
                </div>
            </div>
        </div>
    </article>
</section>
