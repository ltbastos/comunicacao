<?php
require __DIR__ . '/_direct-access.php';

$pdo = db();

$areas = [];
$canais = [];
$prioridades = [];
$attachments = [];
$briefing = null;
$formData = [];
$selectedChannelIds = [];

$prefillEmail = trim((string) ($_GET['email'] ?? ''));
$briefingId = (int) ($_GET['briefing_id'] ?? 0);

if ($pdo instanceof PDO) {
    try {
        $areas = $pdo->query('SELECT id, nome FROM areas_solicitantes WHERE ativo = 1 ORDER BY nome')->fetchAll();
        $canais = $pdo->query('SELECT id, nome, descricao FROM canais_comunicacao WHERE ativo = 1 ORDER BY nome')->fetchAll();
        $prioridades = $pdo->query('SELECT id, chave, nome FROM prioridades WHERE ativo = 1 ORDER BY ordem, nome')->fetchAll();

        if ($briefingId > 0) {
            $briefingStatement = $pdo->prepare(
                'SELECT
                    b.*,
                    cs.chave AS status_key,
                    cs.nome AS status_nome
                 FROM briefings b
                 LEFT JOIN configuracoes_status cs ON cs.id = b.status_id
                 WHERE b.id = :id
                 LIMIT 1'
            );
            $briefingStatement->execute(['id' => $briefingId]);
            $briefing = $briefingStatement->fetch();

            if ($briefing) {
                $formData = json_decode((string) ($briefing['dados_formulario_json'] ?? ''), true);
                $formData = is_array($formData) ? $formData : [];

                $channelsStatement = $pdo->prepare(
                    'SELECT canal_id
                     FROM briefing_canais
                     WHERE briefing_id = :briefing_id
                     ORDER BY ordem, id'
                );
                $channelsStatement->execute(['briefing_id' => $briefingId]);
                $selectedChannelIds = array_map('intval', array_column($channelsStatement->fetchAll(), 'canal_id'));

                $attachmentsStatement = $pdo->prepare(
                    'SELECT id, nome_arquivo, nome_original, caminho_arquivo
                     FROM briefing_anexos
                     WHERE briefing_id = :briefing_id
                     ORDER BY id DESC'
                );
                $attachmentsStatement->execute(['briefing_id' => $briefingId]);
                $attachments = $attachmentsStatement->fetchAll();
            }
        }
    } catch (Throwable $throwable) {
        $areas = [];
        $canais = [];
        $prioridades = [];
        $attachments = [];
        $briefing = null;
        $formData = [];
        $selectedChannelIds = [];
    }
}

if ($briefing && ($briefing['email_solicitante'] ?? '') !== '') {
    $prefillEmail = (string) $briefing['email_solicitante'];
}

$somosOptions = [
    '#SomosPelasPessoas',
    '#OrientadosADesafios',
    '#UmTimeEmpoderado',
    '#UnidosEvoluímos',
    '#ObstinadosPorResultados',
    '#SomosPelosClientes',
];

$classificacaoOptions = [
    'Interna',
    'Pública',
    'Confidencial',
];

$tipoComunicacaoOptions = [
    'Lançamento',
    'Sustentação',
    'Alteração de regras',
    'Regulatório',
    'Outro',
];

$publicoOptions = [
    'Empresas',
    'Plataforma PJ',
    'MEI',
    'Negócios',
];

$isEditing = is_array($briefing);
$isDraft = $isEditing && (($briefing['status_key'] ?? '') === 'rascunho');
$heroEyebrow = $isDraft ? 'Continuar rascunho' : ($isEditing ? 'Editar briefing' : 'Novo briefing');
$heroTitle = $isDraft ? 'Bora retomar esse rascunho?' : ($isEditing ? 'Vamos ajustar esse briefing.' : 'Vamos montar isso juntos.');
$heroCopy = $isDraft
    ? 'Seu rascunho está aberto para continuar quando quiser. Ajuste, anexe o que faltar e envie quando estiver redondo.'
    : ($isEditing
        ? 'Ajuste as respostas, complemente os materiais e siga em frente sem começar tudo de novo.'
        : 'Agora o formulário já está mais perto do modelo real do solicitante. A ideia é reduzir retrabalho e já sair com as perguntas certas desde o começo.');

function briefing_field_value(string $key, $default = '')
{
    global $briefing, $formData, $prefillEmail;

    if (array_key_exists($key, $formData)) {
        return $formData[$key];
    }

    if (is_array($briefing) && array_key_exists($key, $briefing) && $briefing[$key] !== null && $briefing[$key] !== '') {
        return $briefing[$key];
    }

    if ($key === 'email_solicitante' && $prefillEmail !== '') {
        return $prefillEmail;
    }

    return $default;
}

function briefing_field_array(string $key): array
{
    global $formData, $selectedChannelIds;

    if ($key === 'canais_ids') {
        return $selectedChannelIds;
    }

    $value = $formData[$key] ?? [];
    return is_array($value) ? $value : [];
}

function briefing_selected(string $key, $value): string
{
    return (string) briefing_field_value($key) === (string) $value ? 'selected' : '';
}

function briefing_checked(string $key, $value): string
{
    return (string) briefing_field_value($key) === (string) $value ? 'checked' : '';
}

function briefing_checked_in_array(string $key, $value): string
{
    return in_array((string) $value, array_map('strval', briefing_field_array($key)), true) ? 'checked' : '';
}
?>

<section
    class="briefing-wizard"
    id="briefingWizardPage"
    data-submit-url="<?php echo safe(base_url() . '/api/briefings/create.php'); ?>"
    data-back-url="<?php echo safe(route_url('envio-briefing')); ?>"
    data-prefill-email="<?php echo safe($prefillEmail); ?>"
>
    <div class="briefing-wizard__overlay"></div>

    <div class="briefing-wizard__inner">
        <div class="immersive-toolbar">
            <a class="briefing-wizard__back" href="<?php echo safe(route_url('envio-briefing', $prefillEmail ? ['email' => $prefillEmail] : [])); ?>">
                <i class="bi bi-arrow-left"></i>
                <span>Voltar</span>
            </a>

            <button class="theme-toggle theme-toggle--inline" id="themeToggle" type="button" aria-pressed="false" title="Alternar tema">
                <i class="bi bi-moon-stars-fill theme-toggle__icon theme-toggle__icon--dark"></i>
                <i class="bi bi-sun-fill theme-toggle__icon theme-toggle__icon--light"></i>
                <span class="theme-toggle__label">Modo claro</span>
            </button>
        </div>

        <div class="briefing-wizard__hero">
            <span class="briefing-wizard__eyebrow"><?php echo safe($heroEyebrow); ?></span>
            <h1><?php echo safe($heroTitle); ?></h1>
            <p><?php echo safe($heroCopy); ?></p>
            <?php if ($isEditing): ?>
                <div class="briefing-wizard__hero-meta">
                    <span><?php echo safe($briefing['codigo'] ?? ''); ?></span>
                    <span><?php echo safe($briefing['status_nome'] ?? ''); ?></span>
                </div>
            <?php endif; ?>
        </div>

        <div class="briefing-wizard__progress">
            <div class="briefing-wizard__progress-copy">
                <strong id="briefingWizardStepLabel">Etapa 1 de 6</strong>
                <span id="briefingWizardStepTitle">Agendamento e identificação</span>
            </div>
            <div class="briefing-wizard__progress-bar">
                <span id="briefingWizardProgressBar" style="width: 16.67%;"></span>
            </div>
        </div>

        <div class="briefing-wizard__steps" id="briefingWizardSteps">
            <button class="briefing-wizard__step is-active" type="button" data-briefing-step-trigger="1">
                <span>1</span>
                <strong>Planejamento</strong>
            </button>
            <button class="briefing-wizard__step" type="button" data-briefing-step-trigger="2">
                <span>2</span>
                <strong>Canais</strong>
            </button>
            <button class="briefing-wizard__step" type="button" data-briefing-step-trigger="3">
                <span>3</span>
                <strong>Contexto</strong>
            </button>
            <button class="briefing-wizard__step" type="button" data-briefing-step-trigger="4">
                <span>4</span>
                <strong>Direção</strong>
            </button>
            <button class="briefing-wizard__step" type="button" data-briefing-step-trigger="5">
                <span>5</span>
                <strong>Complementos</strong>
            </button>
            <button class="briefing-wizard__step" type="button" data-briefing-step-trigger="6">
                <span>6</span>
                <strong>Revisão</strong>
            </button>
        </div>

        <form class="briefing-wizard__form" id="briefingWizardForm" enctype="multipart/form-data">
            <input type="hidden" name="mode" id="briefingWizardMode" value="send">
            <input type="hidden" name="briefing_id" value="<?php echo safe($briefing['id'] ?? ''); ?>">

            <section class="briefing-wizard__panel is-active" data-briefing-step-panel="1" data-briefing-step-title="Agendamento e identificação">
                <div class="briefing-wizard__panel-head">
                    <h2>Primeiro, vamos situar a demanda.</h2>
                    <p>Essa etapa junta o que já é programado, a data desejada e quem está puxando a comunicação.</p>
                </div>

                <div class="briefing-wizard__grid two-columns is-compact">
                    <fieldset class="briefing-wizard__field-group full-span">
                        <div class="briefing-wizard__group-head">
                            <span>Esta comunicação é programada?</span>
                            <small>Se ela já nasce planejada, a triagem fica mais rápida.</small>
                        </div>
                        <div class="briefing-wizard__inline-toggle">
                            <label class="briefing-wizard__radio-card">
                                <input type="radio" name="esta_na_grade" value="1" <?php echo briefing_checked('esta_na_grade', '1') ?: (!$isEditing ? 'checked' : ''); ?>>
                                <span>Sim</span>
                            </label>
                            <label class="briefing-wizard__radio-card">
                                <input type="radio" name="esta_na_grade" value="0" <?php echo briefing_checked('esta_na_grade', '0'); ?>>
                                <span>Não</span>
                            </label>
                        </div>
                    </fieldset>

                    <label>
                        <span>Qual é a data da publicação?</span>
                        <input type="date" name="data_desejada_publicacao" value="<?php echo safe((string) briefing_field_value('data_desejada_publicacao')); ?>" required>
                    </label>

                    <label class="briefing-wizard__select-label">
                        <span>Área solicitante</span>
                        <select name="area_id" required>
                            <option value="">Selecione</option>
                            <?php foreach ($areas as $area): ?>
                                <option value="<?php echo safe($area['id']); ?>" <?php echo briefing_selected('area_id', $area['id']); ?>>
                                    <?php echo safe($area['nome']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <label>
                        <span>Seu nome</span>
                        <input type="text" name="nome_solicitante" id="briefingWizardName" value="<?php echo safe((string) briefing_field_value('nome_solicitante')); ?>" placeholder="Seu nome">
                    </label>

                    <label>
                        <span>Seu e-mail</span>
                        <input type="email" name="email_solicitante" id="briefingWizardEmail" value="<?php echo safe((string) briefing_field_value('email_solicitante')); ?>" placeholder="voce@empresa.com.br" required>
                    </label>

                    <label class="full-span">
                        <span>Qual é o assunto / tema / ação?</span>
                        <input type="text" name="produto_tema" value="<?php echo safe((string) briefing_field_value('produto_tema')); ?>" placeholder="Ex.: Atualização da jornada de benefícios PJ" required>
                    </label>

                    <label class="full-span">
                        <span>Título da demanda</span>
                        <input type="text" name="titulo" value="<?php echo safe((string) briefing_field_value('titulo')); ?>" placeholder="Ex.: Campanha de reforço para atualização cadastral" required>
                    </label>
                </div>
            </section>

            <section class="briefing-wizard__panel" data-briefing-step-panel="2" data-briefing-step-title="Canais, público e recortes">
                <div class="briefing-wizard__panel-head">
                    <h2>Agora vamos definir onde e para quem isso vai.</h2>
                    <p>Marque mais de uma opção quando fizer sentido. Essa etapa já foi pensada para evitar retrabalho na triagem.</p>
                </div>

                <div class="briefing-wizard__grid two-columns is-compact">
                    <fieldset class="briefing-wizard__field-group full-span" data-required-group="canais[]" data-required-label="ao menos um canal desejado">
                        <div class="briefing-wizard__group-head">
                            <span>Onde você quer divulgar?</span>
                            <small>Marque todos os canais desejados.</small>
                        </div>
                        <div class="briefing-wizard__choice-grid is-channel-grid">
                            <?php foreach ($canais as $canal): ?>
                                <label class="briefing-wizard__choice-card">
                                    <input type="checkbox" name="canais[]" value="<?php echo safe($canal['id']); ?>" <?php echo briefing_checked_in_array('canais_ids', $canal['id']); ?>>
                                    <span><?php echo safe($canal['nome']); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>

                    <fieldset class="briefing-wizard__field-group" data-required-group="publicos_alvo[]" data-required-label="ao menos um público-alvo">
                        <div class="briefing-wizard__group-head">
                            <span>Quem é o público-alvo?</span>
                            <small>Marque todas as opções aplicáveis.</small>
                        </div>
                        <div class="briefing-wizard__choice-grid">
                            <?php foreach ($publicoOptions as $option): ?>
                                <label class="briefing-wizard__choice-card">
                                    <input type="checkbox" name="publicos_alvo[]" value="<?php echo safe($option); ?>" <?php echo briefing_checked_in_array('publicos_alvo', $option); ?>>
                                    <span><?php echo safe($option); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>

                    <fieldset class="briefing-wizard__field-group">
                        <div class="briefing-wizard__group-head">
                            <span>Essa comunicação é:</span>
                            <small>Marque todas as opções aplicáveis.</small>
                        </div>
                        <div class="briefing-wizard__choice-grid">
                            <?php foreach ($classificacaoOptions as $option): ?>
                                <label class="briefing-wizard__choice-card">
                                    <input type="checkbox" name="classificacao_comunicacao[]" value="<?php echo safe($option); ?>" <?php echo briefing_checked_in_array('classificacao_comunicacao', $option); ?>>
                                    <span><?php echo safe($option); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>

                    <fieldset class="briefing-wizard__field-group">
                        <div class="briefing-wizard__group-head">
                            <span>#Somos? Se sim, qual?</span>
                            <small>Deixe marcado se essa peça conversa com algum pilar.</small>
                        </div>
                        <div class="briefing-wizard__choice-grid">
                            <?php foreach ($somosOptions as $option): ?>
                                <label class="briefing-wizard__choice-card">
                                    <input type="checkbox" name="somos_tags[]" value="<?php echo safe($option); ?>" <?php echo briefing_checked_in_array('somos_tags', $option); ?>>
                                    <span><?php echo safe($option); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>
                </div>
            </section>

            <section class="briefing-wizard__panel" data-briefing-step-panel="3" data-briefing-step-title="Contexto e direcionamento">
                <div class="briefing-wizard__panel-head">
                    <h2>Vamos organizar o pano de fundo.</h2>
                    <p>Essa é a parte que ajuda o time a entender histórico, status atual e o que a comunicação precisa resolver de verdade.</p>
                </div>

                <div class="briefing-wizard__grid two-columns is-compact">
                    <label class="full-span">
                        <span>Você poderia nos atualizar sobre o histórico deste assunto?</span>
                        <textarea name="contexto" rows="4" placeholder="Já houve conversas anteriores? Qual é o status atual? Existe alguma lacuna ou reforço necessário?" required><?php echo safe((string) briefing_field_value('contexto')); ?></textarea>
                    </label>

                    <label class="full-span">
                        <span>Objetivo da comunicação</span>
                        <textarea name="objetivo" rows="4" placeholder="O que esta comunicação precisa gerar ou resolver?" required><?php echo safe((string) briefing_field_value('objetivo')); ?></textarea>
                    </label>

                    <fieldset class="briefing-wizard__field-group">
                        <div class="briefing-wizard__group-head">
                            <span>Isso faz parte do Change?</span>
                            <small>Se sim, já deixe o contexto amarrado.</small>
                        </div>
                        <div class="briefing-wizard__inline-toggle">
                            <label class="briefing-wizard__radio-card">
                                <input type="radio" name="change_flag" value="Sim" <?php echo briefing_checked('change_flag', 'Sim'); ?>>
                                <span>Sim</span>
                            </label>
                            <label class="briefing-wizard__radio-card">
                                <input type="radio" name="change_flag" value="Não" <?php echo briefing_checked('change_flag', 'Não') ?: (!$isEditing ? 'checked' : ''); ?>>
                                <span>Não</span>
                            </label>
                        </div>
                    </fieldset>

                    <label>
                        <span>Se sim, qual número da iniciativa e descritivo?</span>
                        <input type="text" name="change_iniciativa" value="<?php echo safe((string) briefing_field_value('change_iniciativa')); ?>" placeholder="Ex.: CHG-142 | Jornada de atendimento">
                    </label>

                    <fieldset class="briefing-wizard__field-group">
                        <div class="briefing-wizard__group-head">
                            <span>Já tem identidade visual desse assunto?</span>
                            <small>Isso ajuda a reaproveitar o que já existe.</small>
                        </div>
                        <div class="briefing-wizard__inline-toggle">
                            <label class="briefing-wizard__radio-card">
                                <input type="radio" name="identidade_visual_existente" value="Sim" <?php echo briefing_checked('identidade_visual_existente', 'Sim'); ?>>
                                <span>Sim</span>
                            </label>
                            <label class="briefing-wizard__radio-card">
                                <input type="radio" name="identidade_visual_existente" value="Não" <?php echo briefing_checked('identidade_visual_existente', 'Não') ?: (!$isEditing ? 'checked' : ''); ?>>
                                <span>Não</span>
                            </label>
                        </div>
                    </fieldset>

                    <fieldset class="briefing-wizard__field-group full-span">
                        <div class="briefing-wizard__group-head">
                            <span>Tipo de comunicação</span>
                            <small>Marque as opções aplicáveis.</small>
                        </div>
                        <div class="briefing-wizard__choice-grid">
                            <?php foreach ($tipoComunicacaoOptions as $option): ?>
                                <label class="briefing-wizard__choice-card">
                                    <input type="checkbox" name="tipos_comunicacao[]" value="<?php echo safe($option); ?>" <?php echo briefing_checked_in_array('tipos_comunicacao', $option); ?>>
                                    <span><?php echo safe($option); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>

                    <fieldset class="briefing-wizard__field-group">
                        <div class="briefing-wizard__group-head">
                            <span>Prioridade percebida</span>
                            <small>Escolha o nível que melhor representa a urgência dessa demanda.</small>
                        </div>
                        <div class="briefing-wizard__choice-grid">
                            <?php foreach ($prioridades as $prioridade): ?>
                                <label class="briefing-wizard__radio-card">
                                    <input type="radio" name="prioridade_id" value="<?php echo safe($prioridade['id']); ?>" <?php echo briefing_checked('prioridade_id', (string) $prioridade['id']); ?>>
                                    <span><?php echo safe($prioridade['nome']); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>

                    <label>
                        <span>CTA / ação desejada</span>
                        <input type="text" name="cta" value="<?php echo safe((string) briefing_field_value('cta')); ?>" placeholder="Ex.: Clique, adesão, leitura, atualização">
                    </label>
                </div>
            </section>

            <section class="briefing-wizard__panel" data-briefing-step-panel="4" data-briefing-step-title="Mensagem e peça">
                <div class="briefing-wizard__panel-head">
                    <h2>Hora de lapidar o conteúdo.</h2>
                    <p>Aqui entram a mensagem principal, a orientação da peça e a sugestão de texto que o solicitante já imagina.</p>
                </div>

                <div class="briefing-wizard__grid two-columns is-compact">
                    <label class="full-span">
                        <span>Qual é a mensagem principal?</span>
                        <textarea name="mensagem_principal" rows="4" placeholder="Qual é a ideia-chave que não pode se perder?" required><?php echo safe((string) briefing_field_value('mensagem_principal')); ?></textarea>
                    </label>

                    <label class="full-span">
                        <span>Existirá alguma ação do gerente?</span>
                        <textarea name="acao_gerente" rows="3" placeholder="Se houver papel do gerente, descreva aqui."><?php echo safe((string) briefing_field_value('acao_gerente')); ?></textarea>
                    </label>

                    <label class="full-span">
                        <span>Sugestão de texto</span>
                        <textarea name="sugestao_texto" rows="5" placeholder="Pode ser em tópicos ou um resumo da comunicação esperada." required><?php echo safe((string) briefing_field_value('sugestao_texto')); ?></textarea>
                    </label>

                    <label class="full-span">
                        <span>Descrição resumida do briefing</span>
                        <textarea name="descricao_resumida" rows="3" placeholder="Explique em poucas linhas o que precisa acontecer." required><?php echo safe((string) briefing_field_value('descricao_resumida')); ?></textarea>
                    </label>
                </div>
            </section>

            <section class="briefing-wizard__panel" data-briefing-step-panel="5" data-briefing-step-title="Links, apoio e validade">
                <div class="briefing-wizard__panel-head">
                    <h2>Fechando os complementos.</h2>
                    <p>Esses campos ajudam a peça sair com menos ruído: links, canal de dúvidas, validade e anexos para apoiar a produção.</p>
                </div>

                <div class="briefing-wizard__grid two-columns is-compact">
                    <label>
                        <span>Vai ter link na peça? Onde ele entra?</span>
                        <input type="text" name="link_local" value="<?php echo safe((string) briefing_field_value('link_local')); ?>" placeholder="Ex.: botão principal, banner, rodapé">
                    </label>

                    <label>
                        <span>Link destino</span>
                        <input type="url" name="link_destino" value="<?php echo safe((string) briefing_field_value('link_destino')); ?>" placeholder="https://">
                    </label>

                    <label class="full-span">
                        <span>Em caso de dúvidas, onde o leitor pode saber mais?</span>
                        <textarea name="onde_saber_mais" rows="3" placeholder="Ex.: página interna, FAQ, atendimento, equipe responsável"><?php echo safe((string) briefing_field_value('onde_saber_mais')); ?></textarea>
                    </label>

                    <label>
                        <span>Até quando essa comunicação é válida?</span>
                        <input type="date" name="validade_ate" value="<?php echo safe((string) briefing_field_value('validade_ate')); ?>">
                    </label>

                    <label>
                        <span>Observações finais</span>
                        <input type="text" name="observacoes_solicitante" value="<?php echo safe((string) briefing_field_value('observacoes_solicitante')); ?>" placeholder="Qualquer observação extra que ajude a execução">
                    </label>

                    <label class="full-span">
                        <span>Links de apoio</span>
                        <textarea name="links_apoio" rows="3" placeholder="Cole aqui documentos, peças anteriores ou referências. Se quiser, coloque um por linha."><?php echo safe((string) briefing_field_value('links_apoio')); ?></textarea>
                    </label>

                    <div class="briefing-wizard__upload-block full-span">
                        <div class="briefing-wizard__upload-head">
                            <span>Mandar anexos</span>
                            <small>PDF, imagens, planilhas e documentos. Você pode enviar mais de um arquivo.</small>
                        </div>

                        <label class="briefing-wizard__upload-dropzone" for="briefingWizardFiles">
                            <input id="briefingWizardFiles" type="file" name="anexos[]" multiple accept=".pdf,.jpg,.jpeg,.png,.webp,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.csv,.txt">
                            <i class="bi bi-cloud-arrow-up"></i>
                            <strong>Arraste arquivos aqui ou clique para selecionar</strong>
                            <span>Até 10 MB por arquivo.</span>
                        </label>

                        <div class="briefing-wizard__file-list is-hidden" id="briefingWizardFilesList"></div>

                        <?php if (!empty($attachments)): ?>
                            <div class="briefing-wizard__existing-files">
                                <strong>Anexos já enviados</strong>
                                <div class="briefing-wizard__existing-files-list">
                                    <?php foreach ($attachments as $attachment): ?>
                                        <a class="briefing-wizard__existing-file" href="<?php echo safe(base_url() . '/' . ltrim($attachment['caminho_arquivo'], '/')); ?>" target="_blank" rel="noopener">
                                            <i class="bi bi-paperclip"></i>
                                            <span><?php echo safe($attachment['nome_original'] ?: $attachment['nome_arquivo']); ?></span>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </section>

            <section class="briefing-wizard__panel" data-briefing-step-panel="6" data-briefing-step-title="Revisão e envio">
                <div class="briefing-wizard__panel-head">
                    <h2>Revisão final.</h2>
                    <p>Dá uma última olhada. Se estiver redondo, envia. Se ainda estiver amadurecendo, salva em rascunho e volta depois.</p>
                </div>

                <div class="briefing-wizard__review" id="briefingWizardReview"></div>
            </section>

            <div class="briefing-wizard__footer">
                <button class="briefing-wizard__ghost" type="button" data-briefing-prev>Voltar etapa</button>

                <div class="briefing-wizard__footer-actions">
                    <button class="briefing-wizard__secondary" type="button" data-briefing-save><?php echo $isDraft ? 'Atualizar rascunho' : 'Salvar em rascunho'; ?></button>
                    <button class="briefing-wizard__primary" type="button" data-briefing-next>Próxima etapa</button>
                    <button class="briefing-wizard__primary is-hidden" type="button" data-briefing-send><?php echo $isDraft ? 'Enviar rascunho' : 'Enviar briefing'; ?></button>
                </div>
            </div>
        </form>
    </div>
</section>
