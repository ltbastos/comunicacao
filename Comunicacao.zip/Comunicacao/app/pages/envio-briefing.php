<?php
require __DIR__ . '/_direct-access.php';
?>

<section
    class="briefing-entry"
    id="briefingEntry"
    data-lookup-url="<?php echo safe(base_url() . '/api/briefings/by-email.php'); ?>"
    data-create-url="<?php echo safe(route_url('novo-briefing')); ?>"
>
    <div class="briefing-entry__overlay"></div>

    <div class="briefing-entry__inner">
        <div class="immersive-toolbar">
            <a class="briefing-entry__back" href="<?php echo safe(route_url('home')); ?>">
                <i class="bi bi-arrow-left"></i>
                <span>Voltar</span>
            </a>

            <button class="theme-toggle theme-toggle--inline" id="themeToggle" type="button" aria-pressed="false" title="Alternar tema">
                <i class="bi bi-moon-stars-fill theme-toggle__icon theme-toggle__icon--dark"></i>
                <i class="bi bi-sun-fill theme-toggle__icon theme-toggle__icon--light"></i>
                <span class="theme-toggle__label">Modo claro</span>
            </button>
        </div>

        <section class="briefing-entry__intro" id="briefingIntro">
            <span class="briefing-entry__eyebrow">Envio de briefing</span>
            <h1>Legal, vamos te ajudar com isso.</h1>
            <p>Mas antes me diga seu e-mail. Eu vou puxar suas demandas, conferir os prazos e te mostrar tudo por aqui.</p>

            <form class="briefing-entry__form" id="briefingLookupForm">
                <label class="briefing-entry__label" for="briefingLookupEmail">Seu e-mail</label>
                <div class="briefing-entry__field">
                    <i class="bi bi-at"></i>
                    <input
                        id="briefingLookupEmail"
                        name="email"
                        type="email"
                        placeholder="voce@empresa.com.br"
                        autocomplete="email"
                        required
                    >
                </div>

                <button class="briefing-entry__submit" type="submit">
                    <span>Buscar meus briefings</span>
                    <i class="bi bi-arrow-right-circle"></i>
                </button>
            </form>
        </section>

        <section class="briefing-entry__loading is-hidden" id="briefingLookupLoading" aria-live="polite">
            <div class="briefing-entry__loader">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <strong>Boa. Estou buscando suas informações.</strong>
            <p id="briefingLookupLoadingMessage">Conferindo seus pedidos, prazos e atendimentos...</p>
        </section>

        <section class="briefing-entry__results is-hidden" id="briefingLookupResults">
            <div class="briefing-entry__results-head">
                <div>
                    <span class="briefing-entry__eyebrow">Demandas encontradas</span>
                    <h2 id="briefingLookupHeading">Seus briefings</h2>
                    <p class="briefing-entry__results-copy" id="briefingLookupCopy">Aqui estão as suas demandas em andamento.</p>
                </div>
            </div>

            <div class="briefing-entry__summary-row">
                <div class="briefing-entry__summary-card">
                    <span class="briefing-entry__summary-label">Consulta atual</span>
                    <div class="briefing-entry__email-pill" id="briefingLookupEmailPill"></div>
                </div>

                <button class="briefing-entry__change-email" type="button" id="briefingLookupChangeEmail">
                    <i class="bi bi-arrow-repeat"></i>
                    <span>Trocar e-mail</span>
                </button>
            </div>

            <div class="briefing-entry__list" id="briefingLookupList"></div>

            <div class="briefing-entry__empty is-hidden" id="briefingLookupEmpty">
                <i class="bi bi-chat-heart"></i>
                <strong>Você ainda não tem briefings por aqui.</strong>
                <p>Sem problema. A gente pode começar um novo agora e deixar tudo redondinho para você.</p>
            </div>

            <div class="briefing-entry__actions">
                <button class="briefing-entry__primary" type="button" id="briefingLookupCreate">
                    <span>Enviar novo briefing</span>
                    <i class="bi bi-send"></i>
                </button>
                <a class="briefing-entry__secondary" href="<?php echo safe(route_url('home')); ?>">
                    <span>Voltar ao início</span>
                </a>
            </div>
        </section>
    </div>
</section>
