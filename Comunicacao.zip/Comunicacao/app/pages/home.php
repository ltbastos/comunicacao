<?php
require __DIR__ . '/_direct-access.php';

$homeOptions = [
    [
        'href' => route_url('envio-briefing'),
        'icon' => 'bi-pencil-square',
        'title' => 'Envie seu briefing',
        'subtitle' => 'É aqui que tudo começa',
        'accent' => 'briefing',
    ],
    [
        'href' => route_url('solicitacao-grade'),
        'icon' => 'bi-calendar2-week',
        'title' => 'Solicitação de grade',
        'subtitle' => 'Monte a grade perfeita',
        'accent' => 'grade',
    ],
    [
        'href' => route_url('encaixe'),
        'icon' => 'bi-lightning-charge',
        'title' => 'Precisa de um encaixe?',
        'subtitle' => 'A gente vê',
        'accent' => 'encaixe',
    ],
    [
        'href' => route_url('acompanhar-pedidos'),
        'icon' => 'bi-broadcast-pin',
        'title' => 'Acompanhe seus pedidos',
        'subtitle' => 'Em tempo real',
        'accent' => 'acompanhar',
    ],
];
?>

<section class="home-screen" id="homeScreen">
    <div class="home-screen__overlay"></div>

    <div class="home-screen__inner">
        <div class="immersive-toolbar immersive-toolbar--end">
            <button class="theme-toggle theme-toggle--inline" id="themeToggle" type="button" aria-pressed="false" title="Alternar tema">
                <i class="bi bi-moon-stars-fill theme-toggle__icon theme-toggle__icon--dark"></i>
                <i class="bi bi-sun-fill theme-toggle__icon theme-toggle__icon--light"></i>
                <span class="theme-toggle__label">Modo claro</span>
            </button>
        </div>

        <div class="home-hero">
            <span class="home-hero__eyebrow">Escolha seu ponto de partida</span>
            <h1>Como podemos ajudar hoje?</h1>
        </div>

        <div class="home-grid">
            <?php foreach ($homeOptions as $index => $option): ?>
                <a
                    class="home-tile home-tile--<?php echo safe($option['accent']); ?>"
                    href="<?php echo safe($option['href']); ?>"
                    style="--tile-index: <?php echo safe($index); ?>;"
                >
                    <div class="home-tile__content">
                        <span class="home-tile__icon">
                            <i class="bi <?php echo safe($option['icon']); ?>"></i>
                        </span>
                        <div class="home-tile__copy">
                            <strong><?php echo safe($option['title']); ?></strong>
                            <span class="home-tile__subtitle"><?php echo safe($option['subtitle']); ?></span>
                        </div>
                    </div>

                    <span class="home-tile__arrow">
                        <i class="bi bi-arrow-up-right"></i>
                    </span>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
