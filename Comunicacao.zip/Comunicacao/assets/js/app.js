document.addEventListener('DOMContentLoaded', () => {
    initThemeToggle();
    initHomeScreen();
    initBriefingLookup();
    initBriefingWizardPage();
    initSidebar();
    initCharts();
    initIdentity();
    initWizard();
    initViewSwitch();
    initDemoForms();
});

function initThemeToggle() {
    const toggle = document.getElementById('themeToggle');
    if (!toggle) return;

    const label = toggle.querySelector('.theme-toggle__label');

    const syncThemeUi = () => {
        const isLight = document.documentElement.classList.contains('theme-light');
        toggle.setAttribute('aria-pressed', isLight ? 'true' : 'false');

        if (label) {
            label.textContent = isLight ? 'Modo escuro' : 'Modo claro';
        }
    };

    toggle.addEventListener('click', () => {
        document.documentElement.classList.toggle('theme-light');

        try {
            const isLight = document.documentElement.classList.contains('theme-light');
            localStorage.setItem('comunicacao_theme', isLight ? 'light' : 'dark');
        } catch (error) {}

        syncThemeUi();
    });

    syncThemeUi();
}

function initSidebar() {
    const toggle = document.getElementById('sidebarToggle');
    if (!toggle) return;

    toggle.addEventListener('click', () => {
        document.body.classList.toggle('sidebar-open');
    });
}

function initHomeScreen() {
    const homeScreen = document.getElementById('homeScreen');
    if (!homeScreen) return;

    homeScreen.addEventListener('pointermove', (event) => {
        const rect = homeScreen.getBoundingClientRect();
        const x = ((event.clientX - rect.left) / rect.width) * 100;
        const y = ((event.clientY - rect.top) / rect.height) * 100;

        homeScreen.style.setProperty('--pointer-x', `${x}%`);
        homeScreen.style.setProperty('--pointer-y', `${y}%`);
    });
}

function initBriefingLookup() {
    const root = document.getElementById('briefingEntry');
    if (!root) return;

    const lookupUrl = root.dataset.lookupUrl;
    const createUrl = root.dataset.createUrl;
    const form = document.getElementById('briefingLookupForm');
    const emailInput = document.getElementById('briefingLookupEmail');
    const intro = document.getElementById('briefingIntro');
    const loading = document.getElementById('briefingLookupLoading');
    const loadingMessage = document.getElementById('briefingLookupLoadingMessage');
    const results = document.getElementById('briefingLookupResults');
    const heading = document.getElementById('briefingLookupHeading');
    const copy = document.getElementById('briefingLookupCopy');
    const emailPill = document.getElementById('briefingLookupEmailPill');
    const list = document.getElementById('briefingLookupList');
    const empty = document.getElementById('briefingLookupEmpty');
    const changeEmail = document.getElementById('briefingLookupChangeEmail');
    const createButton = document.getElementById('briefingLookupCreate');
    const query = new URLSearchParams(window.location.search);
    let currentLookupEmail = '';

    const loadingMessages = [
        'Conferindo seus pedidos, prazos e atendimentos...',
        'Organizando a sua vitrine de briefings...',
        'Quase lá. Só mais um instante...',
    ];

    let loadingMessageIndex = 0;
    let loadingInterval = null;

    const startLoading = () => {
        intro?.classList.add('is-hidden');
        results?.classList.add('is-hidden');
        loading?.classList.remove('is-hidden');

        if (loadingMessage) {
            loadingMessage.textContent = loadingMessages[0];
        }

        loadingInterval = window.setInterval(() => {
            loadingMessageIndex = (loadingMessageIndex + 1) % loadingMessages.length;
            if (loadingMessage) {
                loadingMessage.textContent = loadingMessages[loadingMessageIndex];
            }
        }, 850);
    };

    const stopLoading = () => {
        if (loadingInterval) {
            window.clearInterval(loadingInterval);
            loadingInterval = null;
        }
        loading?.classList.add('is-hidden');
        loadingMessageIndex = 0;
    };

    const resetToIntro = () => {
        stopLoading();
        results?.classList.remove('is-empty');
        results?.classList.add('is-hidden');
        intro?.classList.remove('is-hidden');
        currentLookupEmail = '';
        emailInput?.focus();
    };

    const renderResults = (payload) => {
        const briefings = payload.briefings || [];
        const hasBriefings = briefings.length > 0;
        currentLookupEmail = payload.email || '';

        if (heading) {
            heading.textContent = hasBriefings
                ? 'Pronto. Estes são os seus briefings.'
                : 'Ainda não encontrei briefings por aqui.';
        }

        if (copy) {
            copy.textContent = hasBriefings
                ? 'Aqui estão as suas demandas com publicação, prazo, tema e atendimento.'
                : 'Sem estresse. Você pode começar um novo agora ou voltar para a página inicial.';
        }

        if (emailPill) {
            emailPill.innerHTML = `
                <i class="bi bi-envelope-paper"></i>
                <span>E-mail consultado: ${escapeHtml(payload.email)}</span>
            `;
        }

        if (list) {
            list.innerHTML = briefings.map((briefing) => `
                <article class="briefing-entry__item">
                    <div class="briefing-entry__item-head">
                        <div>
                            <span class="briefing-entry__item-code">${escapeHtml(briefing.codigo)}</span>
                            <strong>${escapeHtml(briefing.tema)}</strong>
                        </div>
                        <span class="briefing-entry__status" style="background:${hexToRgba(briefing.status.cor, 0.18)}; color:${escapeHtml(briefing.status.cor)};">
                            ${escapeHtml(briefing.status.nome)}
                        </span>
                    </div>

                    <div class="briefing-entry__meta">
                        <div class="briefing-entry__meta-card">
                            <span>Publicação</span>
                            <strong>${escapeHtml(briefing.data_publicacao || 'A definir')}</strong>
                        </div>
                        <div class="briefing-entry__meta-card">
                            <span>Prazo limite</span>
                            <strong>${escapeHtml(briefing.prazo_limite || 'A definir')}</strong>
                        </div>
                        <div class="briefing-entry__meta-card">
                            <span>Tema</span>
                            <strong>${escapeHtml(briefing.titulo || briefing.tema)}</strong>
                        </div>
                        <div class="briefing-entry__meta-card">
                            <span>Atendimento</span>
                            <strong>${escapeHtml(briefing.atendimento || 'A definir')}</strong>
                        </div>
                    </div>

                    ${briefing.canais ? `
                        <div class="briefing-entry__item-aux">
                            <span>Canais</span>
                            <strong>${escapeHtml(briefing.canais)}</strong>
                        </div>
                    ` : ''}

                    ${briefing.can_edit ? `
                        <div class="briefing-entry__item-footer">
                            <a class="briefing-entry__item-action" href="${escapeHtml(briefing.edit_url || '#')}">
                                <span>Continuar rascunho</span>
                                <i class="bi bi-pencil-square"></i>
                            </a>
                        </div>
                    ` : ''}
                </article>
            `).join('');
        }

        if (empty) {
            empty.classList.toggle('is-hidden', hasBriefings);
        }

        results?.classList.toggle('is-empty', !hasBriefings);
        results?.classList.remove('is-hidden');
    };

    const performLookup = async (email) => {
        if (!email) {
            showToast('Me diga seu e-mail para eu buscar suas demandas.', 'warning');
            return;
        }

        localStorage.setItem('comunicacao_email', email);
        startLoading();

        try {
            const response = await fetch(lookupUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                },
                body: new URLSearchParams({ email }).toString(),
            });

            const payload = await response.json();
            stopLoading();

            if (!response.ok || !payload.ok) {
                showToast(payload.message || 'Não consegui buscar seus briefings agora.', 'warning');
                resetToIntro();
                return;
            }

            renderResults(payload);
        } catch (error) {
            stopLoading();
            resetToIntro();
            showToast('Tive um problema ao buscar seus briefings. Tente novamente.', 'warning');
        }
    };

    form?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const email = (emailInput?.value || '').trim().toLowerCase();
        await performLookup(email);
    });

    changeEmail?.addEventListener('click', () => {
        resetToIntro();
    });

    createButton?.addEventListener('click', () => {
        const email = currentLookupEmail || (emailInput?.value || '').trim().toLowerCase();
        const target = new URL(createUrl, window.location.origin);

        if (email) {
            target.searchParams.set('email', email);
        }

        window.location.href = `${target.pathname}${target.search}`;
    });

    const prefillEmail = (query.get('email') || localStorage.getItem('comunicacao_email') || '').trim().toLowerCase();
    if (emailInput && prefillEmail) {
        emailInput.value = prefillEmail;
    }

    const submitted = query.get('submitted') || '';
    if (submitted === 'draft') {
        showToast('Rascunho salvo direitinho.', 'success');
    } else if (submitted === 'send') {
        showToast('Briefing enviado. Agora ele já aparece na sua lista.', 'success');
    }

    if (submitted) {
        const nextUrl = new URL(window.location.href);
        nextUrl.searchParams.delete('submitted');
        nextUrl.searchParams.delete('codigo');
        window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
    }

    if (query.get('email')) {
        performLookup(prefillEmail);
    }
}

function initBriefingWizardPage() {
    const root = document.getElementById('briefingWizardPage');
    if (!root) return;

    const submitUrl = root.dataset.submitUrl;
    const form = document.getElementById('briefingWizardForm');
    const panels = [...root.querySelectorAll('[data-briefing-step-panel]')];
    const triggers = [...root.querySelectorAll('[data-briefing-step-trigger]')];
    const prevButton = root.querySelector('[data-briefing-prev]');
    const nextButton = root.querySelector('[data-briefing-next]');
    const saveButton = root.querySelector('[data-briefing-save]');
    const sendButton = root.querySelector('[data-briefing-send]');
    const stepLabel = document.getElementById('briefingWizardStepLabel');
    const stepTitle = document.getElementById('briefingWizardStepTitle');
    const progressBar = document.getElementById('briefingWizardProgressBar');
    const review = document.getElementById('briefingWizardReview');
    const emailField = document.getElementById('briefingWizardEmail');
    const nameField = document.getElementById('briefingWizardName');
    const modeField = document.getElementById('briefingWizardMode');
    const filesInput = document.getElementById('briefingWizardFiles');
    const filesList = document.getElementById('briefingWizardFilesList');

    if (!form || !panels.length || !modeField) return;

    const prefillEmail = (root.dataset.prefillEmail || localStorage.getItem('comunicacao_email') || '').trim().toLowerCase();
    const prefillName = (localStorage.getItem('comunicacao_nome') || '').trim();

    if (emailField && prefillEmail && !emailField.value) {
        emailField.value = prefillEmail;
    }

    if (nameField && prefillName && !nameField.value) {
        nameField.value = prefillName;
    }

    const stepFieldMap = {
        titulo: 1,
        email_solicitante: 1,
        area_id: 1,
        data_desejada_publicacao: 1,
        produto_tema: 1,
        'canais[]': 2,
        'publicos_alvo[]': 2,
        objetivo: 3,
        contexto: 3,
        prioridade_id: 3,
        mensagem_principal: 4,
        sugestao_texto: 4,
        descricao_resumida: 4,
    };

    const reviewSections = [
        {
            title: 'Planejamento e identificação',
            fields: ['esta_na_grade', 'data_desejada_publicacao', 'area_id', 'nome_solicitante', 'email_solicitante', 'produto_tema', 'titulo'],
        },
        {
            title: 'Canais e público',
            fields: ['canais[]', 'publicos_alvo[]', 'classificacao_comunicacao[]', 'somos_tags[]'],
        },
        {
            title: 'Contexto e direcionamento',
            fields: ['contexto', 'objetivo', 'change_flag', 'change_iniciativa', 'identidade_visual_existente', 'tipos_comunicacao[]', 'prioridade_id', 'cta'],
        },
        {
            title: 'Conteúdo da peça',
            fields: ['mensagem_principal', 'acao_gerente', 'sugestao_texto', 'descricao_resumida'],
        },
        {
            title: 'Complementos',
            fields: ['link_local', 'link_destino', 'onde_saber_mais', 'validade_ate', 'observacoes_solicitante', 'links_apoio'],
        },
    ];

    let currentStep = 1;

    const renderSelectedFiles = () => {
        if (!filesInput || !filesList) return;

        const files = [...(filesInput.files || [])];
        filesList.innerHTML = files.map((file) => `
            <div class="briefing-wizard__file-item">
                <i class="bi bi-paperclip"></i>
                <span>${escapeHtml(file.name)}</span>
                <small>${formatFileSize(file.size)}</small>
            </div>
        `).join('');

        filesList.classList.toggle('is-hidden', files.length === 0);
    };

    const syncWizard = () => {
        panels.forEach((panel) => {
            panel.classList.toggle('is-active', Number(panel.dataset.briefingStepPanel) === currentStep);
        });

        triggers.forEach((trigger) => {
            trigger.classList.toggle('is-active', Number(trigger.dataset.briefingStepTrigger) === currentStep);
        });

        if (prevButton) {
            prevButton.disabled = currentStep === 1;
        }

        if (nextButton) {
            nextButton.classList.toggle('is-hidden', currentStep === panels.length);
        }

        if (sendButton) {
            sendButton.classList.toggle('is-hidden', currentStep !== panels.length);
        }

        const activePanel = panels[currentStep - 1];

        if (stepLabel) {
            stepLabel.textContent = `Etapa ${currentStep} de ${panels.length}`;
        }

        if (stepTitle && activePanel) {
            stepTitle.textContent = activePanel.dataset.briefingStepTitle || '';
        }

        if (progressBar) {
            progressBar.style.width = `${(currentStep / panels.length) * 100}%`;
        }

        if (currentStep === panels.length) {
            buildReview();
        }
    };

    const validatePanel = (step) => {
        const panel = panels[step - 1];
        if (!panel) return true;

        const requiredFields = [...panel.querySelectorAll('[required]')];
        for (const field of requiredFields) {
            const value = getFieldValue(form, field.name);
            const isEmpty = Array.isArray(value) ? value.length === 0 : !value;
            if (isEmpty) {
                field.reportValidity();
                return false;
            }
        }

        const requiredGroups = [...panel.querySelectorAll('[data-required-group]')];
        for (const group of requiredGroups) {
            const fieldName = group.dataset.requiredGroup;
            const label = group.dataset.requiredLabel || 'este grupo';
            const value = getFieldValue(form, fieldName);
            const isEmpty = Array.isArray(value) ? value.length === 0 : !value;

            if (isEmpty) {
                showToast(`Faltou marcar ${label}.`, 'warning');
                return false;
            }
        }

        return true;
    };

    const validateForSend = () => {
        const requiredFields = [
            ['titulo', 'título da demanda'],
            ['email_solicitante', 'e-mail do solicitante'],
            ['area_id', 'área solicitante'],
            ['data_desejada_publicacao', 'data da publicação'],
            ['produto_tema', 'assunto / tema / ação'],
            ['objetivo', 'objetivo da comunicação'],
            ['contexto', 'histórico do assunto'],
            ['prioridade_id', 'prioridade'],
            ['mensagem_principal', 'mensagem principal'],
            ['sugestao_texto', 'sugestão de texto'],
            ['descricao_resumida', 'descrição resumida'],
            ['canais[]', 'ao menos um canal desejado'],
            ['publicos_alvo[]', 'ao menos um público-alvo'],
        ];

        for (const [name, label] of requiredFields) {
            const value = getFieldValue(form, name);
            const isEmpty = Array.isArray(value) ? value.length === 0 : !value;
            if (isEmpty) {
                currentStep = stepFieldMap[name] || 1;
                syncWizard();
                const field = form.elements.namedItem(name);
                if (field && typeof field.reportValidity === 'function') {
                    field.reportValidity();
                }
                showToast(`Faltou preencher ${label}.`, 'warning');
                return false;
            }
        }

        const email = getFieldValue(form, 'email_solicitante');
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            currentStep = 1;
            syncWizard();
            const field = form.elements.namedItem('email_solicitante');
            if (field && typeof field.reportValidity === 'function') {
                field.reportValidity();
            }
            showToast('Me passa um e-mail válido para continuar.', 'warning');
            return false;
        }

        return true;
    };

    const buildReview = () => {
        if (!review) return;

        review.innerHTML = reviewSections.map((section) => `
            <article class="briefing-wizard__review-card">
                <strong>${escapeHtml(section.title)}</strong>
                <div class="briefing-wizard__review-list">
                    ${section.fields.map((fieldName) => `
                        <div class="briefing-wizard__review-item">
                            <span>${escapeHtml(getFieldLabel(form, fieldName))}</span>
                            <p>${formatReviewValue(getFieldDisplayValue(form, fieldName))}</p>
                        </div>
                    `).join('')}
                </div>
            </article>
        `).join('');
    };

    const submitWizard = async (mode) => {
        modeField.value = mode;

        if (mode === 'send' && !validateForSend()) {
            return;
        }

        const email = getFieldValue(form, 'email_solicitante');
        const name = getFieldValue(form, 'nome_solicitante');

        if (email) {
            localStorage.setItem('comunicacao_email', email.toLowerCase());
        }

        if (name) {
            localStorage.setItem('comunicacao_nome', name);
        }

        const buttons = [prevButton, nextButton, saveButton, sendButton].filter(Boolean);
        buttons.forEach((button) => {
            button.disabled = true;
        });

        try {
            const formData = new FormData(form);
            const response = await fetch(submitUrl, {
                method: 'POST',
                body: formData,
            });

            const payload = await response.json();

            if (!response.ok || !payload.ok) {
                showToast(payload.message || 'Não consegui salvar o briefing agora.', 'warning');
                return;
            }

            if (mode === 'send') {
                await playBriefingSentCelebration();
            }

            window.location.href = payload.redirect_url || root.dataset.backUrl;
        } catch (error) {
            showToast('Tive um problema ao salvar. Vamos tentar de novo?', 'warning');
        } finally {
            buttons.forEach((button) => {
                button.disabled = false;
            });
        }
    };

    triggers.forEach((trigger) => {
        trigger.addEventListener('click', () => {
            const targetStep = Number(trigger.dataset.briefingStepTrigger);
            if (targetStep > currentStep && !validatePanel(currentStep)) {
                return;
            }

            currentStep = targetStep;
            syncWizard();
        });
    });

    nextButton?.addEventListener('click', () => {
        if (!validatePanel(currentStep)) {
            return;
        }

        currentStep = Math.min(currentStep + 1, panels.length);
        syncWizard();
    });

    prevButton?.addEventListener('click', () => {
        currentStep = Math.max(currentStep - 1, 1);
        syncWizard();
    });

    saveButton?.addEventListener('click', () => {
        submitWizard('draft');
    });

    sendButton?.addEventListener('click', () => {
        buildReview();
        submitWizard('send');
    });

    form.addEventListener('input', () => {
        if (currentStep === panels.length) {
            buildReview();
        }
    });

    filesInput?.addEventListener('change', renderSelectedFiles);

    syncWizard();
    renderSelectedFiles();
}

function initCharts() {
    if (typeof Chart === 'undefined') return;

    document.querySelectorAll('[data-chart-config]').forEach((canvas) => {
        const rawConfig = canvas.getAttribute('data-chart-config');
        if (!rawConfig) return;

        try {
            const config = JSON.parse(rawConfig);
            new Chart(canvas, {
                ...config,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'bottom',
                            labels: {
                                usePointStyle: true,
                                boxWidth: 10,
                                color: '#64748B',
                                padding: 18,
                                font: { family: 'Manrope', size: 12, weight: '600' },
                            },
                        },
                    },
                    scales: config.type === 'bar' ? {
                        y: { grid: { color: 'rgba(217, 228, 236, 0.9)' }, ticks: { color: '#64748B' } },
                        x: { grid: { display: false }, ticks: { color: '#64748B' } },
                    } : {},
                },
            });
        } catch (error) {
            console.error('Falha ao carregar chart:', error);
        }
    });
}

function initIdentity() {
    const form = document.getElementById('identityForm');
    const nameInput = document.getElementById('identityName');
    const emailInput = document.getElementById('identityEmail');
    const wizardName = document.getElementById('wizardName');
    const wizardEmail = document.getElementById('wizardEmail');
    const identityPill = document.getElementById('identityPill');

    const savedName = localStorage.getItem('comunicacao_nome') || '';
    const savedEmail = localStorage.getItem('comunicacao_email') || '';

    if (nameInput) nameInput.value = savedName;
    if (emailInput) emailInput.value = savedEmail;
    if (wizardName) wizardName.value = savedName;
    if (wizardEmail) wizardEmail.value = savedEmail;

    if (savedEmail) {
        applyIdentity(savedEmail, identityPill);
    }

    if (!form) return;

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        const name = (nameInput?.value || '').trim();
        const email = (emailInput?.value || '').trim().toLowerCase();

        if (!email) {
            showToast('Informe um e-mail para continuar.', 'warning');
            return;
        }

        localStorage.setItem('comunicacao_nome', name);
        localStorage.setItem('comunicacao_email', email);

        if (wizardName) wizardName.value = name;
        if (wizardEmail) wizardEmail.value = email;

        applyIdentity(email, identityPill);
        showToast('Identificação funcional atualizada.', 'success');
    });
}

function applyIdentity(email, identityPill) {
    const cards = document.querySelectorAll('[data-briefing-email]');
    const emptyState = document.getElementById('briefingEmptyState');
    let visibleCount = 0;

    cards.forEach((card) => {
        const shouldShow = !email || card.getAttribute('data-briefing-email') === email;
        card.hidden = !shouldShow;
        if (shouldShow) visibleCount += 1;
    });

    if (identityPill) {
        identityPill.textContent = email ? `Exibindo registros de ${email}` : 'Exibindo demonstracao geral';
    }

    if (emptyState) {
        emptyState.hidden = visibleCount > 0;
    }
}

function initWizard() {
    const wizard = document.getElementById('briefingWizard');
    if (!wizard) return;

    const panels = [...wizard.querySelectorAll('[data-step-panel]')];
    const triggers = [...document.querySelectorAll('[data-step-trigger]')];
    const nextButton = wizard.querySelector('[data-step-next]');
    const prevButton = wizard.querySelector('[data-step-prev]');
    const submitButton = document.getElementById('submitBriefing');
    const progressBar = document.getElementById('wizardProgressBar');
    const progressLabel = document.getElementById('wizardProgressLabel');
    let currentStep = 1;

    const syncWizard = () => {
        panels.forEach((panel) => panel.classList.toggle('is-active', Number(panel.dataset.stepPanel) === currentStep));
        triggers.forEach((trigger) => trigger.classList.toggle('is-active', Number(trigger.dataset.stepTrigger) === currentStep));

        if (prevButton) prevButton.disabled = currentStep === 1;
        if (nextButton) nextButton.classList.toggle('is-hidden', currentStep === panels.length);
        if (submitButton) submitButton.classList.toggle('is-hidden', currentStep !== panels.length);
        if (progressBar) progressBar.style.width = `${(currentStep / panels.length) * 100}%`;
        if (progressLabel) progressLabel.textContent = `Etapa ${currentStep} de ${panels.length}`;
    };

    triggers.forEach((trigger) => {
        trigger.addEventListener('click', () => {
            currentStep = Number(trigger.dataset.stepTrigger);
            syncWizard();
        });
    });

    if (nextButton) {
        nextButton.addEventListener('click', () => {
            currentStep = Math.min(currentStep + 1, panels.length);
            syncWizard();
        });
    }

    if (prevButton) {
        prevButton.addEventListener('click', () => {
            currentStep = Math.max(currentStep - 1, 1);
            syncWizard();
        });
    }

    syncWizard();
}

function initViewSwitch() {
    const buttons = document.querySelectorAll('[data-view-target]');
    const panels = document.querySelectorAll('[data-view-panel]');
    if (!buttons.length || !panels.length) return;

    buttons.forEach((button) => {
        button.addEventListener('click', () => {
            const target = button.dataset.viewTarget;
            buttons.forEach((item) => item.classList.toggle('is-active', item === button));
            panels.forEach((panel) => panel.classList.toggle('is-active', panel.dataset.viewPanel === target));
        });
    });
}

function initDemoForms() {
    document.querySelectorAll('[data-demo-submit]').forEach((button) => {
        button.addEventListener('click', () => {
            const action = button.dataset.demoSubmit;
            const message = action === 'send'
                ? 'Briefing enviado na demonstracao. Na proxima fase, esta acao gravara no banco.'
                : 'Rascunho salvo localmente na demonstracao.';
            showToast(message, action === 'send' ? 'success' : 'info');
        });
    });

    document.querySelectorAll('[data-demo-form]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            event.preventDefault();
            showToast('Acao preparada para integracao backend.', 'info');
        });
    });
}

function getFieldValue(form, name) {
    const field = form.elements.namedItem(name);
    if (!field) return '';

    if (field instanceof RadioNodeList) {
        const nodes = [...field].filter(Boolean);
        if (!nodes.length) return '';

        if (nodes.every((node) => node.type === 'checkbox')) {
            return nodes
                .filter((node) => node.checked)
                .map((node) => (node.value || '').trim())
                .filter(Boolean);
        }

        return (field.value || '').trim();
    }

    if (field.type === 'checkbox') {
        return field.checked ? field.value || '1' : '';
    }

    return (field.value || '').trim();
}

function getFieldLabel(form, name) {
    const field = form.elements.namedItem(name);
    const element = field instanceof RadioNodeList ? field[0] : field;
    const groupLabel = element?.closest('fieldset')?.querySelector('.briefing-wizard__group-head span');
    if (groupLabel) {
        return groupLabel.textContent.trim();
    }

    const label = element?.closest('label')?.querySelector('span');
    return label?.textContent?.trim() || name;
}

function getFieldDisplayValue(form, name) {
    const field = form.elements.namedItem(name);
    if (!field) return '';

    if (field instanceof RadioNodeList) {
        const nodes = [...field].filter(Boolean);
        if (!nodes.length) return '';

        if (nodes.every((node) => node.type === 'checkbox')) {
            return nodes
                .filter((node) => node.checked)
                .map((node) => getChoiceLabel(node));
        }

        const selected = nodes.find((node) => node.checked);
        return selected ? getChoiceLabel(selected) : '';
    }

    const element = field;

    if (element?.tagName === 'SELECT') {
        const option = element.options[element.selectedIndex];
        return option && option.value !== '' ? option.textContent.trim() : '';
    }

    return getFieldValue(form, name);
}

function formatReviewValue(value) {
    if (Array.isArray(value)) {
        if (!value.length) {
            return '<em>Não informado ainda.</em>';
        }

        return value.map((item) => escapeHtml(String(item))).join('<br>');
    }

    const normalized = String(value || '').trim();
    if (!normalized) {
        return '<em>Não informado ainda.</em>';
    }

    return escapeHtml(normalized).replace(/\n/g, '<br>');
}

function getChoiceLabel(node) {
    return node.closest('label')?.querySelector('span')?.textContent?.trim() || (node.value || '').trim();
}

function showToast(message, tone = 'info') {
    const stack = document.getElementById('toastStack');
    if (!stack) return;

    const toast = document.createElement('div');
    toast.className = `toast-item ${tone}`;
    toast.textContent = message;
    stack.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('is-visible'));

    window.setTimeout(() => {
        toast.classList.remove('is-visible');
        window.setTimeout(() => toast.remove(), 240);
    }, 2800);
}

function formatFileSize(bytes) {
    const size = Number(bytes || 0);

    if (size <= 0) {
        return '0 KB';
    }

    if (size < 1024 * 1024) {
        return `${Math.max(1, Math.round(size / 1024))} KB`;
    }

    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function playBriefingSentCelebration() {
    const celebration = document.getElementById('sendCelebration');
    if (!celebration) {
        return Promise.resolve();
    }

    celebration.classList.add('is-visible');
    celebration.setAttribute('aria-hidden', 'false');

    return new Promise((resolve) => {
        window.setTimeout(() => {
            celebration.classList.remove('is-visible');
            celebration.setAttribute('aria-hidden', 'true');
            resolve();
        }, 2200);
    });
}

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function hexToRgba(hex, alpha = 1) {
    const normalized = String(hex || '').replace('#', '');
    if (normalized.length !== 6) {
        return `rgba(255, 255, 255, ${alpha})`;
    }

    const red = parseInt(normalized.slice(0, 2), 16);
    const green = parseInt(normalized.slice(2, 4), 16);
    const blue = parseInt(normalized.slice(4, 6), 16);
    return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
}
