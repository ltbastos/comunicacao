<?php $databaseState = database_status(); ?>
<aside class="app-sidebar" id="appSidebar">
    <div class="brand-block">
        <div>
            <h1><?php echo safe(app_config('name')); ?></h1>
        </div>
    </div>

    <nav class="sidebar-nav" aria-label="Principal">
        <?php foreach (nav_items() as $item): ?>
            <a class="nav-link <?php echo is_active_page($item['key']) ? 'is-active' : ''; ?>" href="<?php echo safe(route_url($item['key'])); ?>">
                <i class="bi <?php echo safe($item['icon']); ?>"></i>
                <span><?php echo safe($item['label']); ?></span>
            </a>
        <?php endforeach; ?>
    </nav>

    <div class="sidebar-card">
        <span class="eyebrow">Implantacao simples</span>
        <h2>PHP + MySQL + CDN</h2>
        <p>Estrutura leve, sem build, pronta para evoluir por fases em ambiente corporativo restrito.</p>
        <div class="sidebar-card-footer">
            <span class="status-dot <?php echo $databaseState['connected'] ? 'is-online' : 'is-demo'; ?>"></span>
            <span><?php echo safe($databaseState['label']); ?></span>
        </div>
    </div>
</aside>
