<?php $databaseState = database_status(); ?>
<header class="topbar">
    <div class="topbar-main">
        <button class="sidebar-toggle" type="button" id="sidebarToggle" aria-label="Abrir menu">
            <i class="bi bi-list"></i>
        </button>
        <div class="topbar-copy">
            <div class="topbar-brand">
                <span class="topbar-brand__name"><?php echo safe(app_config('name')); ?></span>
            </div>
            <span class="eyebrow"><?php echo safe($pageMeta['eyebrow'] ?? 'Sistema'); ?></span>
            <h1><?php echo safe($pageMeta['title'] ?? app_config('name')); ?></h1>
            <p><?php echo safe($pageMeta['description'] ?? app_config('tagline')); ?></p>
        </div>
    </div>

    <div class="topbar-actions">
        <div class="topbar-utility">
            <?php require __DIR__ . '/requester-chip.php'; ?>

            <div class="topbar-shortcuts">
                <a
                    class="topbar-icon-button <?php echo is_active_page('dashboard') ? 'is-active' : ''; ?>"
                    href="<?php echo safe(route_url('dashboard')); ?>"
                    aria-label="Abrir dashboard"
                    title="Dashboard"
                >
                    <i class="bi bi-grid-1x2-fill"></i>
                </a>

                <?php require __DIR__ . '/theme-toggle.php'; ?>
            </div>
        </div>

        <div class="topbar-meta">
            <span class="meta-chip <?php echo $databaseState['connected'] ? 'is-success' : 'is-warning'; ?>">
                <i class="bi bi-database-check"></i>
                <?php echo safe($databaseState['database']); ?>
            </span>
            <span class="meta-chip is-neutral">
                <i class="bi bi-calendar-event"></i>
                <?php echo safe(date('d/m/Y')); ?>
            </span>
        </div>

        <div class="action-group">
            <?php foreach (page_actions() as $action): ?>
                <a class="action-button <?php echo safe($action['variant'] ?? 'secondary'); ?>" href="<?php echo safe($action['href']); ?>">
                    <i class="bi <?php echo safe($action['icon'] ?? 'bi-arrow-up-right'); ?>"></i>
                    <span><?php echo safe($action['label']); ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</header>
