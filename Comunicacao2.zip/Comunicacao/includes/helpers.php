<?php

if (!function_exists('app_config')) {
    function app_config($key = null, $default = null)
    {
        $config = $GLOBALS['app_config'] ?? [];
        return $key === null ? $config : ($config[$key] ?? $default);
    }
}

if (!function_exists('database_config')) {
    function database_config($key = null, $default = null)
    {
        $config = $GLOBALS['database_config'] ?? [];
        return $key === null ? $config : ($config[$key] ?? $default);
    }
}

if (!function_exists('mock_data')) {
    function mock_data($key = null, $default = [])
    {
        $data = $GLOBALS['mock_data'] ?? [];
        return $key === null ? $data : ($data[$key] ?? $default);
    }
}

if (!function_exists('safe')) {
    function safe($value)
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('base_url')) {
    function base_url()
    {
        static $base = null;

        if ($base !== null) {
            return $base;
        }

        $projectRoot = realpath(dirname(__DIR__));
        $documentRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath((string) $_SERVER['DOCUMENT_ROOT']) : false;

        if ($projectRoot && $documentRoot) {
            $normalizedProject = str_replace('\\', '/', $projectRoot);
            $normalizedDocument = str_replace('\\', '/', $documentRoot);

            if (stripos($normalizedProject, $normalizedDocument) === 0) {
                $relative = trim(substr($normalizedProject, strlen($normalizedDocument)), '/');
                $base = $relative === '' ? '' : '/' . $relative;
                return $base;
            }
        }

        $directory = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
        $base = ($directory === '/' || $directory === '.') ? '' : rtrim($directory, '/');

        return $base;
    }
}

if (!function_exists('asset_url')) {
    function asset_url($path)
    {
        return base_url() . '/' . ltrim($path, '/');
    }
}

if (!function_exists('route_url')) {
    function route_url($page = 'home', array $query = [])
    {
        return base_url() . '/index.php?' . http_build_query(array_merge(['page' => $page], $query));
    }
}

if (!function_exists('nav_items')) {
    function nav_items()
    {
        $items = [];

        foreach ((array) app_config('navigation', []) as $item) {
            if (!is_array($item) || item_is_visible_for_operator($item)) {
                $items[] = $item;
            }
        }

        return $items;
    }
}

if (!function_exists('current_page')) {
    function current_page()
    {
        $page = $_GET['page'] ?? 'home';
        $pages = app_config('pages', []);
        return array_key_exists($page, $pages) ? $page : 'not-found';
    }
}

if (!function_exists('page_meta')) {
    function page_meta($page = null)
    {
        $pages = app_config('pages', []);
        $page = $page ?: current_page();
        return $pages[$page] ?? [];
    }
}

if (!function_exists('page_actions')) {
    function page_actions($page = null)
    {
        $meta = page_meta($page);
        $actions = [];

        foreach ((array) ($meta['actions'] ?? []) as $action) {
            if (!is_array($action) || item_is_visible_for_operator($action)) {
                $actions[] = $action;
            }
        }

        return $actions;
    }
}

if (!function_exists('page_allowed_roles')) {
    function page_allowed_roles($page = null)
    {
        $meta = page_meta($page);
        return (array) ($meta['roles'] ?? []);
    }
}

if (!function_exists('page_body_class')) {
    function page_body_class()
    {
        return 'page-' . current_page();
    }
}

if (!function_exists('is_immersive_layout')) {
    function is_immersive_layout($page = null)
    {
        $meta = page_meta($page);
        return ($meta['layout'] ?? 'app') === 'immersive';
    }
}

if (!function_exists('is_active_page')) {
    function is_active_page($key)
    {
        return current_page() === $key;
    }
}

if (!function_exists('format_date_br')) {
    function format_date_br($date, $withTime = false)
    {
        if (empty($date)) {
            return 'Sem data';
        }

        try {
            $dateTime = new DateTimeImmutable($date);
        } catch (Exception $exception) {
            return (string) $date;
        }

        return $dateTime->format($withTime ? 'd/m/Y H:i' : 'd/m/Y');
    }
}

if (!function_exists('tone_class')) {
    function tone_class($tone)
    {
        return 'is-' . strtolower(preg_replace('/[^a-z0-9_-]/i', '', (string) $tone));
    }
}

if (!function_exists('status_meta')) {
    function status_meta($key)
    {
        $map = mock_data('status_map', []);
        return $map[$key] ?? ['label' => ucwords(str_replace('_', ' ', (string) $key)), 'tone' => 'info'];
    }
}

if (!function_exists('solicitation_status_catalog')) {
    function solicitation_status_catalog(): array
    {
        return [
            'aberto' => [
                'key' => 'aberto',
                'label' => 'Aberto',
                'nome' => 'Aberto',
                'color' => '#0EA5E9',
                'cor' => '#0EA5E9',
                'tone' => 'info',
                'icon' => 'bi-inbox',
            ],
            'analisando' => [
                'key' => 'analisando',
                'label' => 'Analisando',
                'nome' => 'Analisando',
                'color' => '#F59E0B',
                'cor' => '#F59E0B',
                'tone' => 'warning',
                'icon' => 'bi-search',
            ],
            'aprovado' => [
                'key' => 'aprovado',
                'label' => 'Aprovado',
                'nome' => 'Aprovado',
                'color' => '#16A34A',
                'cor' => '#16A34A',
                'tone' => 'success',
                'icon' => 'bi-check2-circle',
            ],
            'rejeitado' => [
                'key' => 'rejeitado',
                'label' => 'Rejeitado',
                'nome' => 'Rejeitado',
                'color' => '#DC2626',
                'cor' => '#DC2626',
                'tone' => 'danger',
                'icon' => 'bi-x-circle',
            ],
        ];
    }
}

if (!function_exists('solicitation_status_key_from_workflow')) {
    function solicitation_status_key_from_workflow(string $workflowKey): string
    {
        $workflowKey = strtolower(trim($workflowKey));

        if (in_array($workflowKey, ['em_analise', 'em_producao', 'em_aprovacao', 'com_pendencia', 'aguardando_ajuste', 'reagendado'], true)) {
            return 'analisando';
        }

        if (in_array($workflowKey, ['aprovado', 'publicado'], true)) {
            return 'aprovado';
        }

        if (in_array($workflowKey, ['cancelado', 'atrasado', 'rejeitado'], true)) {
            return 'rejeitado';
        }

        return 'aberto';
    }
}

if (!function_exists('solicitation_status_meta')) {
    function solicitation_status_meta(string $key): array
    {
        $catalog = solicitation_status_catalog();
        $normalizedKey = strtolower(trim($key));

        return $catalog[$normalizedKey] ?? $catalog['aberto'];
    }
}

if (!function_exists('solicitation_status_from_record')) {
    function solicitation_status_from_record(array $record): array
    {
        $statusKey = strtolower(trim((string) ($record['status_solicitacao_chave'] ?? $record['solicitacao_status_chave'] ?? '')));

        if ($statusKey === '') {
            $statusKey = solicitation_status_key_from_workflow((string) ($record['status_key'] ?? $record['status_chave'] ?? ''));
        }

        $meta = solicitation_status_meta($statusKey);
        $name = trim((string) ($record['status_solicitacao_nome'] ?? $record['solicitacao_status_nome'] ?? ''));
        $color = trim((string) ($record['status_solicitacao_cor'] ?? $record['solicitacao_status_cor'] ?? ''));

        if ($name !== '') {
            $meta['label'] = $name;
            $meta['nome'] = $name;
        }

        if ($color !== '') {
            $meta['color'] = $color;
            $meta['cor'] = $color;
        }

        return $meta;
    }
}

if (!function_exists('solicitation_status_id')) {
    function solicitation_status_id(PDO $pdo, string $key): ?int
    {
        $statement = $pdo->prepare('SELECT id FROM status_solicitacoes WHERE chave = :chave AND ativo = 1 LIMIT 1');
        $statement->execute(['chave' => strtolower(trim($key))]);
        $row = $statement->fetch();

        return $row ? (int) $row['id'] : null;
    }
}

if (!function_exists('priority_meta')) {
    function priority_meta($key)
    {
        $map = mock_data('priority_map', []);
        return $map[$key] ?? ['label' => ucwords(str_replace('_', ' ', (string) $key)), 'tone' => 'neutral'];
    }
}

if (!function_exists('db')) {
    function db()
    {
        static $connection = false;

        if ($connection !== false) {
            return $connection;
        }

        $config = database_config();

        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                $config['host'] ?? '127.0.0.1',
                $config['port'] ?? 3306,
                $config['database'] ?? '',
                $config['charset'] ?? 'utf8mb4'
            );

            $connection = new PDO(
                $dsn,
                $config['username'] ?? 'root',
                $config['password'] ?? '',
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (Throwable $throwable) {
            $connection = null;
        }

        return $connection;
    }
}

if (!function_exists('database_status')) {
    function database_status()
    {
        $connected = db() instanceof PDO;

        return [
            'connected' => $connected,
            'label' => $connected ? 'Banco conectado' : 'Modo demonstracao',
            'database' => database_config('database', 'comunicacao_hub'),
        ];
    }
}

if (!function_exists('set_current_operator')) {
    function set_current_operator(array $operator): void
    {
        $_SESSION['comunicacao_operador'] = [
            'nome' => trim((string) ($operator['nome'] ?? '')),
            'email' => strtolower(trim((string) ($operator['email'] ?? ''))),
            'role' => trim((string) ($operator['role'] ?? '')),
        ];
    }
}

if (!function_exists('format_identity_name')) {
    function format_identity_name(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        $normalizedSource = function_exists('mb_strtolower')
            ? mb_strtolower($value, 'UTF-8')
            : strtolower($value);
        $words = preg_split('/\s+/', $normalizedSource) ?: [];
        $normalized = [];

        foreach ($words as $word) {
            $word = trim((string) $word);

            if ($word === '') {
                continue;
            }

            if (function_exists('mb_convert_case')) {
                $normalized[] = mb_convert_case($word, MB_CASE_TITLE, 'UTF-8');
                continue;
            }

            $normalized[] = ucfirst($word);
        }

        return implode(' ', $normalized);
    }
}

if (!function_exists('guess_requester_name_from_email')) {
    function guess_requester_name_from_email(string $email): string
    {
        $email = strtolower(trim($email));

        if ($email === '' || strpos($email, '@') === false) {
            return '';
        }

        $localPart = substr($email, 0, strpos($email, '@'));
        $localPart = preg_replace('/[^a-z0-9._-]+/i', ' ', $localPart);
        $words = preg_split('/[\s._-]+/', (string) $localPart) ?: [];
        $words = array_values(array_filter($words, static function ($word) {
            return trim((string) $word) !== '';
        }));

        return format_identity_name(implode(' ', $words));
    }
}

if (!function_exists('requester_initials')) {
    function requester_initials(string $name, string $email = ''): string
    {
        $source = trim($name) !== '' ? format_identity_name($name) : guess_requester_name_from_email($email);
        $parts = preg_split('/\s+/', trim($source)) ?: [];
        $parts = array_values(array_filter($parts, static function ($part) {
            return trim((string) $part) !== '';
        }));

        if (!$parts) {
            return 'U';
        }

        if (count($parts) === 1) {
            $token = $parts[0];
            $slice = function_exists('mb_substr')
                ? mb_substr($token, 0, 2, 'UTF-8')
                : substr($token, 0, 2);

            return strtoupper($slice ?: 'U');
        }

        $first = function_exists('mb_substr')
            ? mb_substr($parts[0], 0, 1, 'UTF-8')
            : substr($parts[0], 0, 1);
        $last = function_exists('mb_substr')
            ? mb_substr($parts[count($parts) - 1], 0, 1, 'UTF-8')
            : substr($parts[count($parts) - 1], 0, 1);

        return strtoupper($first . $last);
    }
}

if (!function_exists('find_internal_operator_by_email')) {
    function find_internal_operator_by_email(string $email): ?array
    {
        $email = strtolower(trim($email));

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return null;
        }

        $pdo = db();

        if (!$pdo instanceof PDO) {
            return null;
        }

        try {
            $statement = $pdo->prepare(
                'SELECT nome, email, role, ativo
                 FROM usuarios_informados
                 WHERE email = :email
                    OR LOWER(email) = :email_lower
                 LIMIT 1'
            );
            $statement->execute([
                'email' => $email,
                'email_lower' => $email,
            ]);
            $user = $statement->fetch();

            if (!$user || empty($user['role']) || (int) ($user['ativo'] ?? 1) !== 1) {
                return null;
            }

            return [
                'nome' => trim((string) ($user['nome'] ?? '')),
                'email' => strtolower(trim((string) ($user['email'] ?? $email))),
                'role' => trim((string) ($user['role'] ?? '')),
            ];
        } catch (Throwable $throwable) {
            return null;
        }
    }
}

if (!function_exists('resolve_requester_identity')) {
    function resolve_requester_identity(string $email, string $preferredName = ''): array
    {
        $email = strtolower(trim($email));
        $name = format_identity_name($preferredName);

        if ($name === '') {
            $operator = find_internal_operator_by_email($email);

            if ($operator && trim((string) ($operator['nome'] ?? '')) !== '') {
                $name = format_identity_name((string) $operator['nome']);
            }
        }

        if ($name === '') {
            $pdo = db();

            if ($pdo instanceof PDO) {
                try {
                    $statement = $pdo->prepare(
                        'SELECT nome_solicitante
                         FROM briefings
                         WHERE (email_solicitante = :email OR LOWER(email_solicitante) = :email_lower)
                           AND nome_solicitante IS NOT NULL
                           AND nome_solicitante <> ""
                         ORDER BY atualizado_em DESC, id DESC
                         LIMIT 1'
                    );
                    $statement->execute([
                        'email' => $email,
                        'email_lower' => $email,
                    ]);
                    $row = $statement->fetch();

                    if ($row && !empty($row['nome_solicitante'])) {
                        $name = format_identity_name((string) $row['nome_solicitante']);
                    }
                } catch (Throwable $throwable) {
                    $name = $name;
                }
            }
        }

        if ($name === '') {
            $name = guess_requester_name_from_email($email);
        }

        return [
            'nome' => $name,
            'email' => $email,
            'iniciais' => requester_initials($name, $email),
        ];
    }
}

if (!function_exists('set_current_requester')) {
    function set_current_requester(array $requester): void
    {
        $email = strtolower(trim((string) ($requester['email'] ?? '')));
        $resolved = resolve_requester_identity($email, (string) ($requester['nome'] ?? ''));

        $_SESSION['comunicacao_requester'] = [
            'nome' => $resolved['nome'],
            'email' => $resolved['email'],
        ];
        $_SESSION['comunicacao_nome'] = $resolved['nome'];
        $_SESSION['comunicacao_email'] = $resolved['email'];
    }
}

if (!function_exists('current_requester')) {
    function current_requester(): ?array
    {
        $requester = $_SESSION['comunicacao_requester'] ?? null;

        if (!is_array($requester)) {
            $legacyEmail = strtolower(trim((string) ($_SESSION['comunicacao_email'] ?? '')));

            if ($legacyEmail === '' || !filter_var($legacyEmail, FILTER_VALIDATE_EMAIL)) {
                return null;
            }

            $resolved = resolve_requester_identity($legacyEmail, (string) ($_SESSION['comunicacao_nome'] ?? ''));
            set_current_requester($resolved);
            return $resolved;
        }

        $email = strtolower(trim((string) ($requester['email'] ?? '')));

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return null;
        }

        $resolved = resolve_requester_identity($email, (string) ($requester['nome'] ?? ''));

        if (($requester['nome'] ?? '') !== $resolved['nome']) {
            set_current_requester($resolved);
        }

        return $resolved;
    }
}

if (!function_exists('clear_current_requester')) {
    function clear_current_requester(): void
    {
        unset($_SESSION['comunicacao_requester'], $_SESSION['comunicacao_email'], $_SESSION['comunicacao_nome']);
    }
}

if (!function_exists('requester_identity_error')) {
    function requester_identity_error(): ?string
    {
        $message = $_SESSION['comunicacao_requester_error'] ?? null;
        unset($_SESSION['comunicacao_requester_error']);

        return is_string($message) && trim($message) !== '' ? $message : null;
    }
}

if (!function_exists('set_requester_identity_error')) {
    function set_requester_identity_error(string $message): void
    {
        $_SESSION['comunicacao_requester_error'] = trim($message);
    }
}

if (!function_exists('safe_redirect_target')) {
    function safe_redirect_target($target, $fallback = null): string
    {
        $fallback = $fallback ? (string) $fallback : route_url('home');
        $target = trim((string) $target);

        if ($target === '' || preg_match('/^(?:[a-z]+:)?\/\//i', $target) || preg_match('/[\r\n]/', $target)) {
            return $fallback;
        }

        if ($target[0] !== '/') {
            $target = base_url() . '/' . ltrim($target, '/');
        }

        $base = base_url();

        if ($base !== '' && strpos($target, $base) !== 0) {
            return $fallback;
        }

        return $target;
    }
}

if (!function_exists('current_request_url')) {
    function current_request_url(): string
    {
        return safe_redirect_target($_SERVER['REQUEST_URI'] ?? '', route_url(current_page()));
    }
}

if (!function_exists('current_operator')) {
    function current_operator(): ?array
    {
        static $resolvedFromRequester = false;

        $operator = $_SESSION['comunicacao_operador'] ?? null;

        if (!is_array($operator)) {
            $operator = null;
        }

        $email = strtolower(trim((string) ($operator['email'] ?? '')));
        $role = trim((string) ($operator['role'] ?? ''));

        if ($operator && $email !== '' && in_array($role, ['adm', 'analista'], true)) {
            return [
                'nome' => trim((string) ($operator['nome'] ?? '')),
                'email' => $email,
                'role' => $role,
            ];
        }

        if ($resolvedFromRequester) {
            return null;
        }

        $resolvedFromRequester = true;
        $requester = current_requester();

        if (!$requester) {
            return null;
        }

        $resolvedOperator = find_internal_operator_by_email($requester['email']);

        if (!$resolvedOperator) {
            clear_current_operator();
            return null;
        }

        set_current_operator($resolvedOperator);

        return [
            'nome' => trim((string) ($resolvedOperator['nome'] ?? '')),
            'email' => strtolower(trim((string) ($resolvedOperator['email'] ?? ''))),
            'role' => trim((string) ($resolvedOperator['role'] ?? '')),
        ];
    }
}

if (!function_exists('current_operator_role')) {
    function current_operator_role(): ?string
    {
        $operator = current_operator();
        return $operator['role'] ?? null;
    }
}

if (!function_exists('operator_has_role')) {
    function operator_has_role(array $allowedRoles)
    {
        $role = current_operator_role();

        return $role !== null && in_array($role, $allowedRoles, true);
    }
}

if (!function_exists('item_is_visible_for_operator')) {
    function item_is_visible_for_operator(array $item)
    {
        $roles = $item['roles'] ?? [];

        if (!$roles) {
            return true;
        }

        return operator_has_role((array) $roles);
    }
}

if (!function_exists('is_operator_admin')) {
    function is_operator_admin(): bool
    {
        return current_operator_role() === 'adm';
    }
}

if (!function_exists('clear_current_operator')) {
    function clear_current_operator(): void
    {
        unset($_SESSION['comunicacao_operador']);
    }
}

if (!function_exists('require_internal_operator')) {
    function require_internal_operator(array $allowedRoles = ['adm', 'analista'], string $redirectPage = 'solicitacao-grade'): void
    {
        $operator = current_operator();

        if (!$operator || !in_array($operator['role'], $allowedRoles, true)) {
            header('Location: ' . route_url($redirectPage));
            exit;
        }
    }
}

if (!function_exists('ensure_page_access')) {
    function ensure_page_access($page = null, $loginRedirectPage = 'solicitacao-grade', $unauthorizedRedirectPage = 'dashboard')
    {
        $allowedRoles = page_allowed_roles($page);

        if (!$allowedRoles) {
            return;
        }

        $operator = current_operator();

        if (!$operator) {
            header('Location: ' . route_url($loginRedirectPage));
            exit;
        }

        if (in_array($operator['role'], $allowedRoles, true)) {
            return;
        }

        $targetPage = $unauthorizedRedirectPage;

        if ((string) $page === (string) $unauthorizedRedirectPage) {
            $targetPage = $loginRedirectPage;
        }

        header('Location: ' . route_url($targetPage));
        exit;
    }
}

if (!function_exists('grade_channel_limit_rules')) {
    function grade_channel_limit_rules()
    {
        return [
            'Mensagem da Diretoria' => ['name' => 'Mensagem da Diretoria', 'limit' => 1, 'limit_label' => '1 por dia'],
            'WhatsApp - Comunica PJ' => ['name' => 'WhatsApp - Comunica PJ', 'limit' => 3, 'limit_label' => 'até 3 por dia'],
            'Post Viva Engage - Comunica PJ' => ['name' => 'Post Viva Engage - Comunica PJ', 'limit' => 1, 'limit_label' => '1 por dia'],
            'E-mail MKT - Comunica PJ' => ['name' => 'E-mail MKT - Comunica PJ', 'limit' => 3, 'limit_label' => 'até 3 por dia'],
            'Banner Portal PJ' => ['name' => 'Banner Portal PJ', 'limit' => 1, 'limit_label' => '1 por dia'],
            'Bom Dia PJ' => ['name' => 'Bom Dia PJ', 'limit' => 3, 'limit_label' => 'até 3 por dia'],
            'Banner Home' => ['name' => 'Banner Home', 'limit' => 1, 'limit_label' => '1 por dia'],
            'Banner Subhome MEI' => ['name' => 'Banner Subhome MEI', 'limit' => 1, 'limit_label' => '1 por dia'],
            'Banner Subhome Plataforma PJ' => ['name' => 'Banner Subhome Plataforma PJ', 'limit' => 1, 'limit_label' => '1 por dia'],
            'Banner Subhome Negócios' => ['name' => 'Banner Subhome Negócios', 'limit' => 1, 'limit_label' => '1 por dia'],
            'Banner Subhome Empresas' => ['name' => 'Banner Subhome Empresas', 'limit' => 1, 'limit_label' => '1 por dia'],
            'Banner Corporativo' => ['name' => 'Banner Corporativo', 'limit' => 1, 'limit_label' => '1 por dia'],
            'Comunica PJ - Teams' => ['name' => 'Comunica PJ - Teams', 'limit' => 3, 'limit_label' => 'até 3 por dia'],
            'Conexão' => ['name' => 'Conexão', 'limit' => 1, 'limit_label' => '1 por dia'],
            'PODC' => ['name' => 'PODC', 'limit' => 1, 'limit_label' => '1 por dia'],
            'Vídeo' => ['name' => 'Vídeo', 'limit' => 1, 'limit_label' => '1 por dia'],
            'Outros' => ['name' => 'Outros', 'limit' => 1, 'limit_label' => '1 por dia'],
        ];
    }
}

if (!function_exists('grade_channel_limit_rule')) {
    function grade_channel_limit_rule($channelName)
    {
        $channelName = trim((string) $channelName);
        $rules = grade_channel_limit_rules();

        return $rules[$channelName] ?? [
            'name' => $channelName !== '' ? $channelName : 'Canal não informado',
            'limit' => 1,
            'limit_label' => '1 por dia',
        ];
    }
}

if (!function_exists('grade_channel_used_slots')) {
    function grade_channel_used_slots(PDO $pdo, int $periodId, int $channelId, string $date, ?int $excludeItemId = null): int
    {
        $sql = 'SELECT COALESCE(SUM(capacidade_slot), 0)
                FROM grade_editorial
                WHERE periodo_id = :periodo_id
                  AND canal_id = :canal_id
                  AND data_prevista_publicacao = :data_publicacao';
        $params = [
            'periodo_id' => $periodId,
            'canal_id' => $channelId,
            'data_publicacao' => $date,
        ];

        if ($excludeItemId !== null && $excludeItemId > 0) {
            $sql .= ' AND id <> :exclude_id';
            $params['exclude_id'] = $excludeItemId;
        }

        $statement = $pdo->prepare($sql);
        $statement->execute($params);

        return (int) $statement->fetchColumn();
    }
}

if (!function_exists('grade_channel_next_free_date')) {
    function grade_channel_next_free_date(PDO $pdo, int $periodId, int $channelId, string $channelName, string $startDate, array $period, ?int $excludeItemId = null): ?string
    {
        $rule = grade_channel_limit_rule($channelName);
        $cursorDate = max($startDate, (new DateTimeImmutable('today'))->format('Y-m-d'), (string) ($period['data_inicio'] ?? $startDate));
        $cursor = new DateTimeImmutable($cursorDate);
        $end = new DateTimeImmutable((string) ($period['data_fim'] ?? $startDate));

        while ($cursor <= $end) {
            $dayOfWeek = (int) $cursor->format('N');
            $dateKey = $cursor->format('Y-m-d');

            if ($dayOfWeek <= 5 && grade_channel_used_slots($pdo, $periodId, $channelId, $dateKey, $excludeItemId) < (int) $rule['limit']) {
                return $dateKey;
            }

            $cursor = $cursor->modify('+1 day');
        }

        return null;
    }
}

if (!function_exists('grade_channel_capacity_state')) {
    function grade_channel_capacity_state(PDO $pdo, int $periodId, int $channelId, string $channelName, string $date, array $period, ?int $excludeItemId = null): array
    {
        $rule = grade_channel_limit_rule($channelName);
        $used = grade_channel_used_slots($pdo, $periodId, $channelId, $date, $excludeItemId);

        return [
            'available' => $used < (int) $rule['limit'],
            'used' => $used,
            'limit' => (int) $rule['limit'],
            'limit_label' => (string) ($rule['limit_label'] ?? ((int) $rule['limit'] . ' por dia')),
            'next_free_date' => grade_channel_next_free_date($pdo, $periodId, $channelId, $channelName, $date, $period, $excludeItemId),
        ];
    }
}

if (!function_exists('grade_capacity_validation_for_channels')) {
    function grade_capacity_validation_for_channels(PDO $pdo, array $channels, ?string $date): array
    {
        $date = trim((string) $date);

        if ($date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            return ['ok' => true];
        }

        $period = grade_find_period_for_date($date);

        if (!$period || grade_period_is_closed($period)) {
            return ['ok' => true];
        }

        foreach ($channels as $channel) {
            $channelId = (int) ($channel['id'] ?? 0);
            $channelName = (string) ($channel['nome'] ?? 'Canal nao informado');

            if ($channelId <= 0) {
                continue;
            }

            $capacity = grade_channel_capacity_state($pdo, (int) $period['id'], $channelId, $channelName, $date, $period);

            if (!$capacity['available']) {
                return [
                    'ok' => false,
                    'channel' => $channelName,
                    'limit_label' => $capacity['limit_label'],
                    'date' => $date,
                    'next_free_date' => $capacity['next_free_date'],
                    'message' => $capacity['next_free_date']
                        ? sprintf('%s ja atingiu o limite de %s em %s. Proxima data livre: %s.', $channelName, $capacity['limit_label'], format_date_br($date), format_date_br($capacity['next_free_date']))
                        : sprintf('%s ja atingiu o limite de %s em %s e nao ha data livre nesta grade.', $channelName, $capacity['limit_label'], format_date_br($date)),
                ];
            }
        }

        return ['ok' => true];
    }
}

if (!function_exists('grade_period_is_closed')) {
    function grade_period_is_closed($period): bool
    {
        $status = is_array($period) ? ($period['status'] ?? '') : $period;
        $status = strtolower(trim((string) $status));

        return in_array($status, ['finalizado', 'finalizada', 'fechado', 'fechada'], true);
    }
}

if (!function_exists('grade_status_label')) {
    function grade_status_label($status): string
    {
        $status = strtolower(trim((string) $status));

        if (grade_period_is_closed($status)) {
            return 'Fechada';
        }

        if ($status === 'cancelado') {
            return 'Cancelada';
        }

        return 'Aberta';
    }
}

if (!function_exists('grade_find_period_for_date')) {
    function grade_find_period_for_date(?string $date): ?array
    {
        $date = trim((string) $date);

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            return null;
        }

        $pdo = db();

        if (!$pdo instanceof PDO) {
            return null;
        }

        try {
            $statement = $pdo->prepare(
                'SELECT id, nome, ano, mes, data_inicio, data_fim, status
                 FROM periodos_grade
                 WHERE status <> "cancelado"
                   AND :data_referencia BETWEEN data_inicio AND data_fim
                 ORDER BY data_inicio DESC, id DESC
                 LIMIT 1'
            );
            $statement->execute(['data_referencia' => $date]);
            $row = $statement->fetch();
        } catch (Throwable $throwable) {
            return null;
        }

        return is_array($row) ? grade_map_period_record($row) : null;
    }
}

if (!function_exists('grade_resolve_request_type')) {
    function grade_resolve_request_type(?string $scheduledDate): array
    {
        $scheduledDate = trim((string) $scheduledDate);
        $period = grade_find_period_for_date($scheduledDate);
        $isPerfect = $period && !grade_period_is_closed($period);

        return [
            'type' => $isPerfect ? 'Perfeita' : 'Encaixe',
            'period' => $period,
            'period_id' => $period ? (int) $period['id'] : null,
            'is_perfect' => $isPerfect,
        ];
    }
}

if (!function_exists('grade_map_period_record')) {
    function grade_map_period_record(array $row)
    {
        $year = (int) ($row['ano'] ?? 0);
        $month = (int) ($row['mes'] ?? 0);
        $label = trim((string) ($row['nome'] ?? ''));

        if ($label === '' && $year > 0 && $month > 0) {
            $label = sprintf('%02d/%04d', $month, $year);
        }

        return [
            'id' => (int) ($row['id'] ?? 0),
            'nome' => $label,
            'label' => $label,
            'year' => $year,
            'month' => $month,
            'data_inicio' => (string) ($row['data_inicio'] ?? ''),
            'data_fim' => (string) ($row['data_fim'] ?? ''),
            'status' => trim((string) ($row['status'] ?? 'aberto')),
            'status_label' => grade_status_label($row['status'] ?? 'aberto'),
            'is_closed' => grade_period_is_closed($row['status'] ?? 'aberto'),
            'is_mock' => false,
        ];
    }
}

if (!function_exists('grade_fetch_period_record')) {
    function grade_fetch_period_record($requestedPeriodId = 0)
    {
        $pdo = db();

        if (!$pdo instanceof PDO) {
            return null;
        }

        try {
            if ((int) $requestedPeriodId > 0) {
                $statement = $pdo->prepare(
                    'SELECT id, nome, ano, mes, data_inicio, data_fim, status
                     FROM periodos_grade
                     WHERE id = :id
                     LIMIT 1'
                );
                $statement->execute(['id' => (int) $requestedPeriodId]);
                $row = $statement->fetch();
            } else {
                $statement = $pdo->query(
                    'SELECT id, nome, ano, mes, data_inicio, data_fim, status
                     FROM periodos_grade
                     WHERE status <> "cancelado"
                     ORDER BY
                        CASE
                            WHEN CURDATE() BETWEEN data_inicio AND data_fim THEN 0
                            WHEN data_inicio >= CURDATE() THEN 1
                            ELSE 2
                        END,
                        CASE
                            WHEN data_inicio >= CURDATE() THEN DATEDIFF(data_inicio, CURDATE())
                            ELSE ABS(DATEDIFF(data_inicio, CURDATE()))
                        END,
                        data_inicio,
                        id
                     LIMIT 1'
                );
                $row = $statement->fetch();
            }
        } catch (Throwable $throwable) {
            return null;
        }

        return is_array($row) ? grade_map_period_record($row) : null;
    }
}

if (!function_exists('grade_fetch_editorial_items_for_period')) {
    function grade_fetch_editorial_items_for_period($periodId)
    {
        $pdo = db();

        if (!$pdo instanceof PDO || (int) $periodId <= 0) {
            return [];
        }

        try {
            $statement = $pdo->prepare(
                'SELECT
                    ge.id,
                    ge.titulo,
                    ge.tipo_demanda,
                    ge.data_prevista_publicacao,
                    ge.status,
                    ge.capacidade_slot,
                    ge.ordem_dia,
                    ge.dentro_capacidade,
                    ge.observacoes,
                    b.id AS briefing_id,
                    b.email_solicitante AS briefing_email,
                    COALESCE(NULLIF(a.nome, ""), "A definir") AS area_nome,
                    COALESCE(NULLIF(cc.nome, ""), "Canal não informado") AS canal_nome,
                    COALESCE(NULLIF(cc.cor_badge, ""), "#1E5B8F") AS canal_cor
                 FROM grade_editorial ge
                 LEFT JOIN areas_solicitantes a ON a.id = ge.area_id
                 LEFT JOIN canais_comunicacao cc ON cc.id = ge.canal_id
                 LEFT JOIN briefings b ON b.grade_id = ge.id
                 WHERE ge.periodo_id = :periodo_id
                 ORDER BY ge.data_prevista_publicacao, ge.ordem_dia, ge.id'
            );
            $statement->execute(['periodo_id' => (int) $periodId]);
            $rows = $statement->fetchAll();
        } catch (Throwable $throwable) {
            return [];
        }

        $items = [];

        foreach ($rows as $row) {
            $items[] = [
                'id' => (int) ($row['id'] ?? 0),
                'title' => trim((string) ($row['titulo'] ?? 'Sem título')),
                'type' => trim((string) ($row['tipo_demanda'] ?? 'Demanda editorial')),
                'date' => (string) ($row['data_prevista_publicacao'] ?? ''),
                'channel' => trim((string) ($row['canal_nome'] ?? 'Canal não informado')),
                'channel_color' => trim((string) ($row['canal_cor'] ?? '#1E5B8F')),
                'area' => trim((string) ($row['area_nome'] ?? 'A definir')),
                'status' => trim((string) ($row['status'] ?? 'planejado')),
                'slot' => max(1, (int) ($row['ordem_dia'] ?? 1)),
                'capacity_units' => max(1, (int) ($row['capacidade_slot'] ?? 1)),
                'in_plan' => (bool) ($row['dentro_capacidade'] ?? true),
                'notes' => trim((string) ($row['observacoes'] ?? '')),
                'briefing_id' => (int) ($row['briefing_id'] ?? 0),
                'briefing_email' => strtolower(trim((string) ($row['briefing_email'] ?? ''))),
            ];
        }

        return $items;
    }
}

if (!function_exists('grade_resolve_planning_context')) {
    function grade_resolve_planning_context($requestedPeriodId = 0)
    {
        $period = grade_fetch_period_record((int) $requestedPeriodId);

        if ($period) {
            return [
                'period' => $period,
                'items' => grade_fetch_editorial_items_for_period($period['id']),
                'source' => 'database',
            ];
        }

        $mock = mock_data('grade', []);
        $mockPeriod = $mock['period'] ?? [];
        $year = (int) ($mockPeriod['year'] ?? 0);
        $month = (int) ($mockPeriod['month'] ?? 0);

        if ($year <= 0 || $month <= 0) {
            return [
                'period' => null,
                'items' => [],
                'source' => 'empty',
            ];
        }

        $firstDay = new DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month));

        return [
            'period' => [
                'id' => 0,
                'nome' => trim((string) ($mockPeriod['label'] ?? $firstDay->format('m/Y'))),
                'label' => trim((string) ($mockPeriod['label'] ?? $firstDay->format('m/Y'))),
                'year' => $year,
                'month' => $month,
                'data_inicio' => $firstDay->format('Y-m-d'),
                'data_fim' => $firstDay->modify('last day of this month')->format('Y-m-d'),
                'status' => 'mock',
                'is_mock' => true,
            ],
            'items' => (array) ($mock['items'] ?? []),
            'source' => 'mock',
        ];
    }
}

if (!function_exists('calendar_matrix')) {
    function calendar_matrix($year, $month, array $items)
    {
        $firstDay = new DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month));
        $start = $firstDay;

        while ((int) $start->format('N') !== 1) {
            $start = $start->modify('-1 day');
        }

        $lastDay = $firstDay->modify('last day of this month');
        $end = $lastDay;

        while ((int) $end->format('N') !== 7) {
            $end = $end->modify('+1 day');
        }

        $itemsByDate = [];

        foreach ($items as $item) {
            $itemsByDate[$item['date']][] = $item;
        }

        $weeks = [];
        $current = $start;
        $week = [];

        while ($current <= $end) {
            $dateKey = $current->format('Y-m-d');
            $week[] = [
                'date' => $dateKey,
                'day' => $current->format('d'),
                'current_month' => (int) $current->format('n') === (int) $month,
                'is_today' => $dateKey === date('Y-m-d'),
                'items' => $itemsByDate[$dateKey] ?? [],
            ];

            if ((int) $current->format('N') === 7) {
                $weeks[] = $week;
                $week = [];
            }

            $current = $current->modify('+1 day');
        }

        return $weeks;
    }
}

if (!function_exists('briefings_by_status')) {
    function briefings_by_status(array $briefings)
    {
        $grouped = [];

        foreach ($briefings as $briefing) {
            $grouped[$briefing['status']][] = $briefing;
        }

        return $grouped;
    }
}
