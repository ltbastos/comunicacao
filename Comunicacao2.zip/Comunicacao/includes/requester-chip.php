<?php
$currentRequester = current_requester();

if (!$currentRequester) {
    return;
}
?>
<div class="requester-chip" data-requester-switch>
    <span class="requester-chip__avatar" aria-hidden="true"><?php echo safe($currentRequester['iniciais']); ?></span>

    <div class="requester-chip__copy">
        <strong><?php echo safe($currentRequester['nome'] ?: $currentRequester['email']); ?></strong>
        <span><?php echo safe($currentRequester['email']); ?></span>
    </div>

    <button class="requester-chip__switch" type="button" data-requester-switch-open aria-haspopup="dialog">Trocar</button>

    <div class="requester-switch-modal" data-requester-switch-modal aria-hidden="true">
        <div class="requester-switch-modal__backdrop" data-requester-switch-close></div>

        <section class="requester-switch-modal__card" role="dialog" aria-modal="true" aria-label="Confirmar troca de e-mail">
            <button class="requester-switch-modal__close" type="button" data-requester-switch-close aria-label="Fechar popup de troca de e-mail">
                <i class="bi bi-x-lg"></i>
            </button>

            <span class="eyebrow">Trocar acesso</span>
            <h2>Trocar e-mail?</h2>
            <p>Voce permanecera com <strong><?php echo safe($currentRequester['email']); ?></strong> se fechar ou cancelar esta troca.</p>

            <div class="requester-switch-modal__actions">
                <button class="requester-switch-modal__secondary" type="button" data-requester-switch-close>Cancelar troca</button>

                <form class="requester-switch-modal__form" method="post" action="<?php echo safe(base_url() . '/api/session/requester.php'); ?>">
                    <input type="hidden" name="action" value="clear">
                    <input type="hidden" name="redirect" value="<?php echo safe(current_request_url()); ?>">
                    <button class="requester-switch-modal__primary" type="submit">Trocar e-mail</button>
                </form>
            </div>
        </section>
    </div>
</div>
