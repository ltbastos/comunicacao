<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$GLOBALS['app_config'] = require __DIR__ . '/../config/app.php';
$GLOBALS['database_config'] = require __DIR__ . '/../config/database.php';
$GLOBALS['mock_data'] = require __DIR__ . '/../config/mock-data.php';

date_default_timezone_set($GLOBALS['app_config']['timezone'] ?? 'America/Sao_Paulo');

require_once __DIR__ . '/helpers.php';
