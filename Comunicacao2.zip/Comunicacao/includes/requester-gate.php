<?php
$currentRequester = current_requester();

if ($currentRequester) {
    return;
}

$requesterError = requester_identity_error();
?>
<div class="requester-gate" role="dialog" aria-modal="true" aria-labelledby="requesterGateTitle">
    <div class="requester-gate__backdrop"></div>

    <section class="requester-gate__card">
        <span class="eyebrow">Entrada da ferramenta</span>
        <h2 id="requesterGateTitle">Qual é o seu e-mail?</h2>
        <p>Vou usar esse usuário em toda a Comunicação 360 enquanto esta sessão do navegador estiver aberta.</p>

        <?php if ($requesterError): ?>
            <div class="requester-gate__error">
                <i class="bi bi-exclamation-circle"></i>
                <span><?php echo safe($requesterError); ?></span>
            </div>
        <?php endif; ?>

        <form class="requester-gate__form" method="post" action="<?php echo safe(base_url() . '/api/session/requester.php'); ?>">
            <input type="hidden" name="redirect" value="<?php echo safe(current_request_url()); ?>">

            <label class="requester-gate__label" for="requesterGateEmail">Seu e-mail</label>
            <div class="requester-gate__field">
                <i class="bi bi-at"></i>
                <input
                    id="requesterGateEmail"
                    name="email"
                    type="email"
                    placeholder="voce@empresa.com.br"
                    autocomplete="email"
                    required
                    autofocus
                >
            </div>

            <button class="requester-gate__submit" type="submit">
                <span>Entrar na ferramenta</span>
                <i class="bi bi-arrow-right-circle"></i>
            </button>
        </form>
    </section>
</div>