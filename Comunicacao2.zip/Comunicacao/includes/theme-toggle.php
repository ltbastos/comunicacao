<button class="theme-toggle theme-toggle--compact" id="themeToggle" type="button" aria-pressed="false" aria-label="Ativar modo claro" title="Alternar tema">
    <span class="theme-toggle__slider" aria-hidden="true">
        <span class="theme-toggle__track-icon theme-toggle__track-icon--light">
            <i class="bi bi-sun-fill"></i>
        </span>
        <span class="theme-toggle__track-icon theme-toggle__track-icon--dark">
            <i class="bi bi-moon-stars-fill"></i>
        </span>
        <span class="theme-toggle__thumb"></span>
    </span>
    <span class="theme-toggle__label sr-only">Modo claro</span>
</button>