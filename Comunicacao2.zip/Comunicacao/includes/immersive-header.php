<header class="immersive-topbar">
    <a class="immersive-brand" href="<?php echo safe(route_url('home')); ?>" aria-label="<?php echo safe(app_config('name')); ?>">
        <strong><?php echo safe(app_config('name')); ?></strong>
    </a>

    <div class="immersive-topbar__actions">
        <?php require __DIR__ . '/requester-chip.php'; ?>

        <div class="topbar-shortcuts">
            <a
                class="topbar-icon-button <?php echo is_active_page('dashboard') ? 'is-active' : ''; ?>"
                href="<?php echo safe(route_url('dashboard')); ?>"
                aria-label="Abrir dashboard"
                title="Dashboard"
            >
                <i class="bi bi-grid-1x2-fill"></i>
            </a>

            <?php require __DIR__ . '/theme-toggle.php'; ?>
        </div>
    </div>
</header>
