<?php

require __DIR__ . '/../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Método não permitido.');
}

$redirectTarget = safe_redirect_target($_POST['redirect'] ?? '', route_url('home'));
$action = trim((string) ($_POST['action'] ?? 'set'));

if ($action === 'clear') {
    clear_current_requester();
    clear_current_operator();
    header('Location: ' . $redirectTarget);
    exit;
}

$email = strtolower(trim((string) ($_POST['email'] ?? '')));

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    set_requester_identity_error('Informe um e-mail válido para continuar.');
    header('Location: ' . $redirectTarget);
    exit;
}

$requester = resolve_requester_identity($email, (string) ($_POST['nome'] ?? ''));
set_current_requester($requester);

$operator = find_internal_operator_by_email($requester['email']);

if ($operator) {
    set_current_operator($operator);
} else {
    clear_current_operator();
}

header('Location: ' . $redirectTarget);
exit;