<?php

require __DIR__ . '/../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'ok' => false,
        'message' => 'Método não permitido.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$email = strtolower(trim((string) ($_POST['email'] ?? '')));

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode([
        'ok' => false,
        'message' => 'Informe um e-mail válido para continuar.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$pdo = db();

if (!$pdo instanceof PDO) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Não foi possível conectar ao banco de dados.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $statement = $pdo->prepare(
        'SELECT nome, email, role, ativo
         FROM usuarios_informados
         WHERE email = :email
            OR LOWER(email) = :email_lower
         LIMIT 1'
    );
    $statement->execute([
        'email' => $email,
        'email_lower' => $email,
    ]);
    $user = $statement->fetch();

    if (!$user || empty($user['role']) || (int) ($user['ativo'] ?? 1) !== 1) {
        clear_current_operator();
        http_response_code(403);
        echo json_encode([
            'ok' => false,
            'message' => 'Esse e-mail não está liberado para a operação interna da Comunicação.',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $operator = [
        'nome' => trim((string) ($user['nome'] ?? '')),
        'email' => strtolower(trim((string) ($user['email'] ?? $email))),
        'role' => trim((string) ($user['role'] ?? '')),
    ];

    set_current_operator($operator);

    echo json_encode([
        'ok' => true,
        'user' => $operator,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    clear_current_operator();
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Não consegui validar este e-mail agora.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}