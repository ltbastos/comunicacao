<?php
require __DIR__ . '/../../includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'ok' => false,
        'message' => 'Metodo nao permitido.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!is_operator_admin()) {
    http_response_code(403);
    echo json_encode([
        'ok' => false,
        'message' => 'Somente administradores podem encaixar pedidos na grade.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$pdo = db();

if (!$pdo instanceof PDO) {
    http_response_code(503);
    echo json_encode([
        'ok' => false,
        'message' => 'Banco indisponivel no momento.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$briefingId = (int) ($_POST['briefing_id'] ?? 0);
$periodId = (int) ($_POST['periodo_id'] ?? 0);
$publishDate = trim((string) ($_POST['data_publicacao'] ?? ''));
$requestedSlot = (int) ($_POST['slot'] ?? 0);

if ($requestedSlot < 1 || $requestedSlot > 26) {
    $requestedSlot = 0;
}

if ($briefingId <= 0 || $periodId <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $publishDate)) {
    respond_schedule_error(422, 'Dados invalidos para encaixar o pedido.');
}

if ($publishDate < (new DateTimeImmutable('today'))->format('Y-m-d')) {
    respond_schedule_error(422, 'A data escolhida precisa ser hoje ou uma data futura.');
}

if ((int) (new DateTimeImmutable($publishDate))->format('N') >= 6) {
    respond_schedule_error(422, 'Sabado e domingo nao ficam disponiveis para encaixe na grade.');
}

try {
    $periodStatement = $pdo->prepare(
        'SELECT id, nome, data_inicio, data_fim, status
         FROM periodos_grade
         WHERE id = :id
         LIMIT 1'
    );
    $periodStatement->execute(['id' => $periodId]);
    $period = $periodStatement->fetch();

    if (!$period) {
        respond_schedule_error(404, 'Periodo da grade nao encontrado.');
    }

    if (grade_period_is_closed($period) && !is_operator_admin()) {
        respond_schedule_error(423, 'Esta grade ja foi fechada e nao pode mais ser editada.');
    }

    if ($publishDate < $period['data_inicio'] || $publishDate > $period['data_fim']) {
        respond_schedule_error(422, 'A data precisa ficar dentro da janela da grade.');
    }

    $briefingStatement = $pdo->prepare(
        'SELECT
            b.id,
            b.codigo,
            b.titulo,
            b.descricao_resumida,
            b.tipo_demanda,
            b.email_solicitante,
            b.area_id,
            b.canal_id,
            b.grade_id,
            COALESCE(NULLIF(a.nome, ""), "A definir") AS area_nome,
            COALESCE(
                (
                    SELECT bc.canal_id
                    FROM briefing_canais bc
                    WHERE bc.briefing_id = b.id
                    ORDER BY bc.ordem, bc.id
                    LIMIT 1
                ),
                b.canal_id
            ) AS canal_grade_id
         FROM briefings b
         LEFT JOIN areas_solicitantes a ON a.id = b.area_id
         WHERE b.id = :id
         LIMIT 1'
    );
    $briefingStatement->execute(['id' => $briefingId]);
    $briefing = $briefingStatement->fetch();

    if (!$briefing) {
        respond_schedule_error(404, 'Pedido nao encontrado.');
    }

    if (!empty($briefing['grade_id'])) {
        respond_schedule_error(409, 'Esse pedido ja esta encaixado na grade.');
    }

    $channelId = (int) ($briefing['canal_grade_id'] ?? 0);

    if ($channelId <= 0) {
        respond_schedule_error(422, 'Esse pedido nao tem canal definido para encaixe.');
    }

    $channelStatement = $pdo->prepare(
        'SELECT id, nome, cor_badge
         FROM canais_comunicacao
         WHERE id = :id AND ativo = 1
         LIMIT 1'
    );
    $channelStatement->execute(['id' => $channelId]);
    $channel = $channelStatement->fetch();

    if (!$channel) {
        respond_schedule_error(422, 'Canal do pedido nao esta ativo.');
    }

    $capacity = grade_capacity_state($pdo, $periodId, $channelId, (string) $channel['nome'], $publishDate, null, $period);

    if (!$capacity['available']) {
        http_response_code(422);
        echo json_encode([
            'ok' => false,
            'message' => sprintf(
                '%s ja atingiu o limite de %s em %s.',
                $channel['nome'],
                $capacity['limit_label'],
                format_date_br($publishDate)
            ),
            'next_free_date' => $capacity['next_free_date'],
            'next_free_label' => $capacity['next_free_date'] ? format_date_br($capacity['next_free_date']) : null,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $requestType = nullable_schedule_value($briefing['tipo_demanda'] ?? '') ?: grade_resolve_request_type($publishDate)['type'];

    $pdo->beginTransaction();

    $orderStatement = $pdo->prepare(
        'SELECT COALESCE(MAX(ordem_dia), 0) + 1 AS next_order
         FROM grade_editorial
         WHERE periodo_id = :periodo_id
           AND data_prevista_publicacao = :data_publicacao'
    );
    $orderStatement->execute([
        'periodo_id' => $periodId,
        'data_publicacao' => $publishDate,
    ]);
    $nextOrder = max(1, (int) ($orderStatement->fetchColumn() ?: 1));
    $targetSlot = $requestedSlot > 0 ? $requestedSlot : $nextOrder;

    $insertStatement = $pdo->prepare(
        'INSERT INTO grade_editorial (
            periodo_id,
            titulo,
            descricao,
            area_id,
            canal_id,
            tipo_demanda,
            data_prevista_publicacao,
            status,
            capacidade_slot,
            ordem_dia,
            dentro_capacidade,
            observacoes
         ) VALUES (
            :periodo_id,
            :titulo,
            :descricao,
            :area_id,
            :canal_id,
            :tipo_demanda,
            :data_prevista_publicacao,
            "planejado",
            1,
            :ordem_dia,
            1,
            :observacoes
         )'
    );
    $insertStatement->execute([
        'periodo_id' => $periodId,
        'titulo' => $briefing['titulo'],
        'descricao' => nullable_schedule_value($briefing['descricao_resumida'] ?? ''),
        'area_id' => (int) ($briefing['area_id'] ?? 0) > 0 ? (int) $briefing['area_id'] : null,
        'canal_id' => $channelId,
        'tipo_demanda' => $requestType,
        'data_prevista_publicacao' => $publishDate,
        'ordem_dia' => $targetSlot,
        'observacoes' => 'Pedido encaixado a partir do briefing ' . $briefing['codigo'] . '.',
    ]);

    $gradeItemId = (int) $pdo->lastInsertId();

    $updateBriefing = $pdo->prepare(
        'UPDATE briefings
         SET grade_id = :grade_id,
             periodo_id = :periodo_id,
             esta_na_grade = 1,
             tipo_demanda = COALESCE(NULLIF(tipo_demanda, ""), :tipo_demanda),
             data_desejada_publicacao = :data_publicacao
         WHERE id = :id
         LIMIT 1'
    );
    $updateBriefing->execute([
        'grade_id' => $gradeItemId,
        'periodo_id' => $periodId,
        'tipo_demanda' => $requestType,
        'data_publicacao' => $publishDate,
        'id' => $briefingId,
    ]);

    $operator = current_operator() ?: [];
    $movementStatement = $pdo->prepare(
        'INSERT INTO briefing_movimentacoes (
            briefing_id,
            tipo_movimento,
            comentario_visivel,
            dados_adicionais,
            nome_autor,
            email_autor
        ) VALUES (
            :briefing_id,
            "encaixe_grade",
            :comentario_visivel,
            :dados_adicionais,
            :nome_autor,
            :email_autor
        )'
    );
    $movementStatement->execute([
        'briefing_id' => $briefingId,
        'comentario_visivel' => 'Pedido encaixado na grade para ' . format_date_br($publishDate) . '.',
        'dados_adicionais' => json_encode([
            'periodo_id' => $periodId,
            'grade_id' => $gradeItemId,
            'canal' => $channel['nome'],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'nome_autor' => nullable_schedule_value($operator['nome'] ?? ''),
        'email_autor' => strtolower(trim((string) ($operator['email'] ?? 'sistema@local'))),
    ]);

    $pdo->commit();

    $nextCapacity = grade_capacity_state($pdo, $periodId, $channelId, (string) $channel['nome'], $publishDate, $gradeItemId, $period);
    $gradeReturnUrl = route_url('solicitacao-grade', ['periodo_id' => $periodId]);

    echo json_encode([
        'ok' => true,
        'message' => 'Pedido encaixado na grade.',
        'item' => [
            'id' => $gradeItemId,
            'briefing_id' => $briefingId,
            'title' => $briefing['titulo'],
            'date' => $publishDate,
            'channel' => $channel['nome'],
            'channel_color' => $channel['cor_badge'] ?: '#1E5B8F',
            'area' => $briefing['area_nome'] ?: 'A definir',
            'status' => 'planejado',
            'type' => $requestType,
            'slot' => $targetSlot,
            'edit_url' => route_url('novo-briefing', [
                'briefing_id' => $briefingId,
                'email' => strtolower(trim((string) ($briefing['email_solicitante'] ?? ''))),
                'return_url' => $gradeReturnUrl,
            ]),
        ],
        'next_free_date' => $nextCapacity['next_free_date'],
        'next_free_label' => $nextCapacity['next_free_date'] ? format_date_br($nextCapacity['next_free_date']) : null,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Nao foi possivel encaixar o pedido agora.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function respond_schedule_error(int $statusCode, string $message): void
{
    http_response_code($statusCode);
    echo json_encode([
        'ok' => false,
        'message' => $message,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function nullable_schedule_value($value): ?string
{
    $trimmed = trim((string) $value);
    return $trimmed === '' ? null : $trimmed;
}

function grade_capacity_state(PDO $pdo, int $periodId, int $channelId, string $channelName, string $date, ?int $excludeItemId, array $period): array
{
    $rule = grade_channel_limit_rule($channelName);
    $used = grade_used_slots($pdo, $periodId, $channelId, $date, $excludeItemId);
    $nextFreeDate = grade_next_business_free_date($pdo, $periodId, $channelId, $channelName, $date, $excludeItemId, $period);

    return [
        'available' => $used < (int) $rule['limit'],
        'used' => $used,
        'limit' => (int) $rule['limit'],
        'limit_label' => (string) ($rule['limit_label'] ?? ((int) $rule['limit'] . ' por dia')),
        'next_free_date' => $nextFreeDate,
    ];
}

function grade_used_slots(PDO $pdo, int $periodId, int $channelId, string $date, ?int $excludeItemId = null): int
{
    $sql = 'SELECT COALESCE(SUM(capacidade_slot), 0)
            FROM grade_editorial
            WHERE periodo_id = :periodo_id
              AND canal_id = :canal_id
              AND data_prevista_publicacao = :data_publicacao';
    $params = [
        'periodo_id' => $periodId,
        'canal_id' => $channelId,
        'data_publicacao' => $date,
    ];

    if ($excludeItemId !== null && $excludeItemId > 0) {
        $sql .= ' AND id <> :exclude_id';
        $params['exclude_id'] = $excludeItemId;
    }

    $statement = $pdo->prepare($sql);
    $statement->execute($params);

    return (int) $statement->fetchColumn();
}

function grade_next_business_free_date(PDO $pdo, int $periodId, int $channelId, string $channelName, string $startDate, ?int $excludeItemId, array $period): ?string
{
    $rule = grade_channel_limit_rule($channelName);
    $cursorDate = max($startDate, (new DateTimeImmutable('today'))->format('Y-m-d'), (string) $period['data_inicio']);
    $cursor = new DateTimeImmutable($cursorDate);
    $end = new DateTimeImmutable((string) $period['data_fim']);

    while ($cursor <= $end) {
        $dayOfWeek = (int) $cursor->format('N');
        $dateKey = $cursor->format('Y-m-d');

        if ($dayOfWeek <= 5 && grade_used_slots($pdo, $periodId, $channelId, $dateKey, $excludeItemId) < (int) $rule['limit']) {
            return $dateKey;
        }

        $cursor = $cursor->modify('+1 day');
    }

    return null;
}
