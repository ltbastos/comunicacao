<?php

require __DIR__ . '/../../includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    grade_request_respond(405, [
        'ok' => false,
        'message' => 'Metodo nao permitido.',
    ]);
}

$pdo = db();

if (!$pdo instanceof PDO) {
    grade_request_respond(503, [
        'ok' => false,
        'message' => 'Banco indisponivel no momento.',
    ]);
}

$payload = [
    'nome_solicitante' => trim((string) ($_POST['nome_solicitante'] ?? '')),
    'email_solicitante' => strtolower(trim((string) ($_POST['email_solicitante'] ?? ''))),
    'tema_assunto' => trim((string) ($_POST['tema_assunto'] ?? '')),
    'justificativa_tema' => trim((string) ($_POST['justificativa_tema'] ?? '')),
    'data_publicacao_sugerida' => grade_request_normalize_date($_POST['data_publicacao_sugerida'] ?? null),
    'data_publicacao_final' => grade_request_normalize_date($_POST['data_publicacao_final'] ?? null),
    'classificacao_assunto' => trim((string) ($_POST['classificacao_assunto'] ?? '')),
    'responsavel_tema' => trim((string) ($_POST['responsavel_tema'] ?? '')),
    'area_responsavel_tema' => trim((string) ($_POST['area_responsavel_tema'] ?? '')),
    'classificacao_demanda' => trim((string) ($_POST['classificacao_demanda'] ?? '')),
    'grau_necessidade' => trim((string) ($_POST['grau_necessidade'] ?? '')),
    'status_analise' => trim((string) ($_POST['status_analise'] ?? '')),
    'canal_principal' => trim((string) ($_POST['canal_principal'] ?? '')),
    'responsavel_atendimento' => trim((string) ($_POST['responsavel_atendimento'] ?? '')),
    'parecer_analise' => trim((string) ($_POST['parecer_analise'] ?? '')),
];

$payload['publicos_alvo'] = grade_request_normalize_string_array($_POST['publicos_alvo'] ?? []);
$payload['canais'] = grade_request_normalize_string_array($_POST['canais'] ?? []);
$payload['canais_aprovados'] = grade_request_normalize_string_array($_POST['canais_aprovados'] ?? []);

$scheduledDate = $payload['data_publicacao_final'] ?: $payload['data_publicacao_sugerida'];
$scheduledDateField = $payload['data_publicacao_final'] ? 'data_publicacao_final' : 'data_publicacao_sugerida';
$classification = grade_resolve_request_type($scheduledDate);

if ($payload['email_solicitante'] === '' || !filter_var($payload['email_solicitante'], FILTER_VALIDATE_EMAIL)) {
    grade_request_validation('Informe um e-mail valido para continuar.', 'email_solicitante');
}

if ($payload['tema_assunto'] === '') {
    grade_request_validation('Faltou preencher o tema da solicitacao.', 'tema_assunto');
}

if ($payload['justificativa_tema'] === '') {
    grade_request_validation('Faltou preencher a justificativa do tema.', 'justificativa_tema');
}

if (!$scheduledDate) {
    grade_request_validation('Faltou informar a data sugerida de publicacao.', $scheduledDateField);
}

if ($scheduledDate < (new DateTimeImmutable('today'))->format('Y-m-d')) {
    grade_request_validation('A data da publicacao precisa ser hoje ou uma data futura.', $scheduledDateField);
}

if (!$payload['publicos_alvo']) {
    grade_request_validation('Marque ao menos um publico-alvo.', 'publicos_alvo');
}

if (!$payload['canais']) {
    grade_request_validation('Marque ao menos um canal desejado.', 'canais');
}

try {
    $statusId = grade_request_status_id($pdo, 'enviado');
    $solicitationStatusId = solicitation_status_id($pdo, 'aberto');
    $priorityId = grade_request_priority_id($pdo, $payload['grau_necessidade']);
    $areaId = grade_request_area_id($pdo, $payload['area_responsavel_tema']);
    $channels = grade_request_channels($pdo, $payload['canais']);

    if (!$statusId || !$solicitationStatusId || !$priorityId) {
        throw new RuntimeException('Status ou prioridade padrao nao encontrados.');
    }

    if (!$channels) {
        grade_request_validation('Escolha ao menos um canal valido.', 'canais');
    }

    $capacityValidation = grade_capacity_validation_for_channels($pdo, $channels, $scheduledDate);
    if (!($capacityValidation['ok'] ?? true)) {
        grade_request_validation($capacityValidation['message'] ?? 'A data escolhida nao tem capacidade para o canal selecionado.', $scheduledDateField);
    }

    $channelIds = array_map(static function ($channel) {
        return (int) $channel['id'];
    }, $channels);
    $channelNames = array_map(static function ($channel) {
        return (string) $channel['nome'];
    }, $channels);
    $mainChannelId = $channelIds[0] ?? null;

    $formData = [
        'origem' => 'solicitacao-grade',
        'tipo_grade' => $classification['type'],
        'periodo_id' => $classification['period_id'],
        'periodo_nome' => $classification['period']['nome'] ?? null,
        'data_publicacao_sugerida' => $payload['data_publicacao_sugerida'],
        'data_publicacao_final' => $payload['data_publicacao_final'],
        'publicos_alvo' => $payload['publicos_alvo'],
        'canais' => $channelNames,
        'canais_ids' => $channelIds,
        'canais_aprovados' => $payload['canais_aprovados'],
        'classificacao_assunto' => $payload['classificacao_assunto'],
        'classificacao_demanda' => $payload['classificacao_demanda'],
        'responsavel_tema' => $payload['responsavel_tema'],
        'area_responsavel_tema' => $payload['area_responsavel_tema'],
        'grau_necessidade' => $payload['grau_necessidade'],
        'status_analise' => $payload['status_analise'],
        'canal_principal' => $payload['canal_principal'],
        'responsavel_atendimento' => $payload['responsavel_atendimento'],
        'parecer_analise' => $payload['parecer_analise'],
    ];

    $pdo->beginTransaction();

    $upsertUser = $pdo->prepare(
        'INSERT INTO usuarios_informados (nome, email)
         VALUES (:nome, :email)
         ON DUPLICATE KEY UPDATE
            nome = COALESCE(NULLIF(VALUES(nome), ""), nome),
            atualizado_em = CURRENT_TIMESTAMP'
    );
    $upsertUser->execute([
        'nome' => $payload['nome_solicitante'] !== '' ? $payload['nome_solicitante'] : null,
        'email' => $payload['email_solicitante'],
    ]);

    $temporaryCode = 'TMP-' . strtoupper(bin2hex(random_bytes(4)));
    $insertBriefing = $pdo->prepare(
        'INSERT INTO briefings (
            codigo,
            titulo,
            descricao_resumida,
            objetivo,
            contexto,
            mensagem_principal,
            publico_alvo,
            segmento,
            produto_tema,
            tipo_demanda,
            canal_id,
            area_id,
            periodo_id,
            grade_id,
            esta_na_grade,
            prioridade_id,
            status_id,
            status_solicitacao_id,
            origem,
            nome_solicitante,
            email_solicitante,
            data_desejada_publicacao,
            observacoes_solicitante,
            dados_formulario_json,
            responsavel_atual_nome,
            responsavel_atual_email,
            data_envio
         ) VALUES (
            :codigo,
            :titulo,
            :descricao_resumida,
            :objetivo,
            :contexto,
            :mensagem_principal,
            :publico_alvo,
            :segmento,
            :produto_tema,
            :tipo_demanda,
            :canal_id,
            :area_id,
            :periodo_id,
            NULL,
            0,
            :prioridade_id,
            :status_id,
            :status_solicitacao_id,
            "solicitacao_grade",
            :nome_solicitante,
            :email_solicitante,
            :data_desejada_publicacao,
            :observacoes_solicitante,
            :dados_formulario_json,
            :responsavel_atual_nome,
            NULL,
            :data_envio
         )'
    );
    $insertBriefing->execute([
        'codigo' => $temporaryCode,
        'titulo' => $payload['tema_assunto'],
        'descricao_resumida' => grade_request_nullable($payload['justificativa_tema']),
        'objetivo' => grade_request_nullable($payload['classificacao_demanda']),
        'contexto' => grade_request_nullable(grade_request_context($payload)),
        'mensagem_principal' => grade_request_nullable($payload['justificativa_tema']),
        'publico_alvo' => grade_request_nullable(implode(', ', $payload['publicos_alvo'])),
        'segmento' => grade_request_nullable($payload['classificacao_assunto']),
        'produto_tema' => $payload['tema_assunto'],
        'tipo_demanda' => $classification['type'],
        'canal_id' => $mainChannelId,
        'area_id' => $areaId,
        'periodo_id' => $classification['period_id'],
        'prioridade_id' => $priorityId,
        'status_id' => $statusId,
        'status_solicitacao_id' => $solicitationStatusId,
        'nome_solicitante' => grade_request_nullable($payload['nome_solicitante']),
        'email_solicitante' => $payload['email_solicitante'],
        'data_desejada_publicacao' => $scheduledDate,
        'observacoes_solicitante' => grade_request_nullable($payload['parecer_analise']),
        'dados_formulario_json' => json_encode($formData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'responsavel_atual_nome' => grade_request_nullable($payload['responsavel_atendimento']),
        'data_envio' => date('Y-m-d H:i:s'),
    ]);

    $briefingId = (int) $pdo->lastInsertId();
    $codigo = sprintf('BRF-%s-%04d', date('Y'), $briefingId);

    $updateCode = $pdo->prepare('UPDATE briefings SET codigo = :codigo WHERE id = :id');
    $updateCode->execute([
        'codigo' => $codigo,
        'id' => $briefingId,
    ]);

    $insertChannel = $pdo->prepare(
        'INSERT INTO briefing_canais (briefing_id, canal_id, ordem)
         VALUES (:briefing_id, :canal_id, :ordem)'
    );

    foreach ($channelIds as $index => $channelId) {
        $insertChannel->execute([
            'briefing_id' => $briefingId,
            'canal_id' => $channelId,
            'ordem' => $index + 1,
        ]);
    }

    $movement = $pdo->prepare(
        'INSERT INTO briefing_movimentacoes (
            briefing_id,
            tipo_movimento,
            status_novo_id,
            comentario_visivel,
            dados_adicionais,
            nome_autor,
            email_autor
        ) VALUES (
            :briefing_id,
            "criacao_solicitacao_grade",
            :status_novo_id,
            :comentario_visivel,
            :dados_adicionais,
            :nome_autor,
            :email_autor
        )'
    );
    $movement->execute([
        'briefing_id' => $briefingId,
        'status_novo_id' => $statusId,
        'comentario_visivel' => 'Solicitacao de grade enviada como ' . $classification['type'] . '.',
        'dados_adicionais' => json_encode($formData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'nome_autor' => grade_request_nullable($payload['nome_solicitante']),
        'email_autor' => $payload['email_solicitante'],
    ]);

    $pdo->commit();

    set_current_requester([
        'nome' => $payload['nome_solicitante'],
        'email' => $payload['email_solicitante'],
    ]);

    echo json_encode([
        'ok' => true,
        'briefing_id' => $briefingId,
        'codigo' => $codigo,
        'tipo' => $classification['type'],
        'message' => 'Solicitacao enviada como ' . $classification['type'] . '.',
        'redirect_url' => route_url('acompanhar-pedidos', [
            'submitted' => 'grade',
            'codigo' => $codigo,
        ]),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    if ($pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    grade_request_respond(500, [
        'ok' => false,
        'message' => 'Nao consegui salvar a solicitacao de grade agora.',
    ]);
}

function grade_request_respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function grade_request_validation(string $message, string $field): void
{
    grade_request_respond(422, [
        'ok' => false,
        'message' => $message,
        'field' => $field,
    ]);
}

function grade_request_nullable(?string $value): ?string
{
    $value = trim((string) $value);
    return $value === '' ? null : $value;
}

function grade_request_normalize_date($value): ?string
{
    $value = trim((string) $value);

    if ($value === '') {
        return null;
    }

    try {
        return (new DateTimeImmutable($value))->format('Y-m-d');
    } catch (Throwable $throwable) {
        return null;
    }
}

function grade_request_normalize_string_array($values): array
{
    $values = is_array($values) ? $values : [$values];
    $normalized = [];

    foreach ($values as $value) {
        $value = trim((string) $value);

        if ($value !== '') {
            $normalized[] = $value;
        }
    }

    return array_values(array_unique($normalized));
}

function grade_request_status_id(PDO $pdo, string $key): ?int
{
    $statement = $pdo->prepare('SELECT id FROM configuracoes_status WHERE chave = :chave AND ativo = 1 LIMIT 1');
    $statement->execute(['chave' => $key]);
    $row = $statement->fetch();

    return $row ? (int) $row['id'] : null;
}

function grade_request_priority_id(PDO $pdo, string $label): ?int
{
    $normalized = strtolower(trim($label));
    $key = 'media';

    if ($normalized === 'muito urgente') {
        $key = 'critica';
    } elseif ($normalized === 'urgente') {
        $key = 'alta';
    } elseif ($normalized === 'informativo') {
        $key = 'baixa';
    }

    $statement = $pdo->prepare('SELECT id FROM prioridades WHERE chave = :chave AND ativo = 1 LIMIT 1');
    $statement->execute(['chave' => $key]);
    $row = $statement->fetch();

    return $row ? (int) $row['id'] : null;
}

function grade_request_area_id(PDO $pdo, string $name): ?int
{
    $name = trim($name);

    if ($name === '') {
        return null;
    }

    $statement = $pdo->prepare(
        'INSERT INTO areas_solicitantes (nome, ativo)
         VALUES (:nome, 1)
         ON DUPLICATE KEY UPDATE ativo = 1'
    );
    $statement->execute(['nome' => $name]);

    $select = $pdo->prepare('SELECT id FROM areas_solicitantes WHERE nome = :nome LIMIT 1');
    $select->execute(['nome' => $name]);
    $row = $select->fetch();

    return $row ? (int) $row['id'] : null;
}

function grade_request_channels(PDO $pdo, array $names): array
{
    $channels = [];
    $select = $pdo->prepare('SELECT id, nome FROM canais_comunicacao WHERE nome = :nome AND ativo = 1 LIMIT 1');
    $upsert = $pdo->prepare(
        'INSERT INTO canais_comunicacao (nome, descricao, cor_badge, icone, ativo)
         VALUES (:nome, "Canal usado na solicitacao de grade.", "#1E5B8F", "bi-megaphone", 1)
         ON DUPLICATE KEY UPDATE ativo = 1'
    );

    foreach ($names as $name) {
        $select->execute(['nome' => $name]);
        $row = $select->fetch();

        if (!$row) {
            $upsert->execute(['nome' => $name]);
            $select->execute(['nome' => $name]);
            $row = $select->fetch();
        }

        if ($row) {
            $channels[] = [
                'id' => (int) $row['id'],
                'nome' => (string) $row['nome'],
            ];
        }
    }

    return $channels;
}

function grade_request_context(array $payload): string
{
    $lines = [];
    $lines[] = 'Classificacao do assunto: ' . ($payload['classificacao_assunto'] ?: 'Nao informado');
    $lines[] = 'Responsavel pelo tema: ' . ($payload['responsavel_tema'] ?: 'Nao informado');
    $lines[] = 'Area responsavel: ' . ($payload['area_responsavel_tema'] ?: 'Nao informado');
    $lines[] = 'Classificacao da demanda: ' . ($payload['classificacao_demanda'] ?: 'Nao informado');
    $lines[] = 'Grau de necessidade: ' . ($payload['grau_necessidade'] ?: 'Nao informado');

    return implode("\n", $lines);
}
