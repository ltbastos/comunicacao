<?php

require __DIR__ . '/../../includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    grade_finalize_respond(405, [
        'ok' => false,
        'message' => 'Metodo nao permitido.',
    ]);
}

if (!is_operator_admin()) {
    grade_finalize_respond(403, [
        'ok' => false,
        'message' => 'Somente administradores podem fechar uma grade.',
    ]);
}

$pdo = db();

if (!$pdo instanceof PDO) {
    grade_finalize_respond(503, [
        'ok' => false,
        'message' => 'Banco indisponivel no momento.',
    ]);
}

$periodId = (int) ($_POST['periodo_id'] ?? 0);

if ($periodId <= 0) {
    grade_finalize_respond(422, [
        'ok' => false,
        'message' => 'Grade invalida para fechamento.',
    ]);
}

try {
    $statement = $pdo->prepare(
        'SELECT id, nome, status
         FROM periodos_grade
         WHERE id = :id
         LIMIT 1'
    );
    $statement->execute(['id' => $periodId]);
    $period = $statement->fetch();

    if (!$period) {
        grade_finalize_respond(404, [
            'ok' => false,
            'message' => 'Grade nao encontrada.',
        ]);
    }

    if (strtolower((string) $period['status']) === 'cancelado') {
        grade_finalize_respond(422, [
            'ok' => false,
            'message' => 'Uma grade cancelada nao pode ser fechada.',
        ]);
    }

    if (!grade_period_is_closed($period)) {
        $update = $pdo->prepare(
            'UPDATE periodos_grade
               SET status = "fechado"
             WHERE id = :id
             LIMIT 1'
        );
        $update->execute(['id' => $periodId]);
    }

    echo json_encode([
        'ok' => true,
        'message' => 'Grade fechada. Administradores ainda podem ajustar o calendario.',
        'period' => [
            'id' => $periodId,
            'status' => 'fechado',
            'status_label' => 'Fechada',
        ],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    grade_finalize_respond(500, [
        'ok' => false,
        'message' => 'Nao consegui fechar a grade agora.',
    ]);
}

function grade_finalize_respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
