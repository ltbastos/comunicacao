<?php
require __DIR__ . '/../../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    exit('Metodo nao permitido.');
}

if (!operator_has_role(['adm', 'analista'])) {
    http_response_code(403);
    exit('Acesso interno obrigatorio.');
}

$pdo = db();

if (!$pdo instanceof PDO) {
    http_response_code(503);
    exit('Banco indisponivel no momento.');
}

$periodId = (int) ($_GET['periodo_id'] ?? 0);

if ($periodId <= 0) {
    http_response_code(422);
    exit('Periodo da grade invalido.');
}

try {
    $periodStatement = $pdo->prepare(
        'SELECT id, nome, data_inicio, data_fim
         FROM periodos_grade
         WHERE id = :id
           AND status <> "cancelado"
         LIMIT 1'
    );
    $periodStatement->execute(['id' => $periodId]);
    $period = $periodStatement->fetch();

    if (!$period) {
        http_response_code(404);
        exit('Periodo da grade nao encontrado.');
    }

    $itemsStatement = $pdo->prepare(
        'SELECT
            ge.data_prevista_publicacao,
            ge.status AS status_grade,
            COALESCE(NULLIF(b.codigo, ""), CONCAT("GRADE-", ge.id)) AS codigo_solicitacao,
            COALESCE(NULLIF(b.produto_tema, ""), NULLIF(b.titulo, ""), NULLIF(ge.titulo, ""), "Solicitacao sem nome") AS nome_solicitacao,
            COALESCE(
                NULLIF(b.responsavel_atual_nome, ""),
                (
                    SELECT br.nome_responsavel
                    FROM briefing_responsaveis br
                    WHERE br.briefing_id = b.id
                      AND br.ativo = 1
                    ORDER BY br.iniciado_em DESC, br.id DESC
                    LIMIT 1
                ),
                "A definir"
            ) AS nome_analista,
            COALESCE(NULLIF(b.origem, ""), "solicitante") AS origem,
            COALESCE(NULLIF(ss.nome, ""), "") AS status_solicitacao,
            COALESCE(NULLIF(p.nome, ""), "A definir") AS prioridade_nome
         FROM grade_editorial ge
         LEFT JOIN briefings b ON b.grade_id = ge.id
         LEFT JOIN status_solicitacoes ss ON ss.id = b.status_solicitacao_id
         LEFT JOIN prioridades p ON p.id = b.prioridade_id
         WHERE ge.periodo_id = :periodo_id
           AND ge.data_prevista_publicacao BETWEEN :data_inicio AND :data_fim
           AND ge.status <> "cancelado"
         ORDER BY ge.data_prevista_publicacao, ge.ordem_dia, ge.id'
    );
    $itemsStatement->execute([
        'periodo_id' => $periodId,
        'data_inicio' => $period['data_inicio'],
        'data_fim' => $period['data_fim'],
    ]);
    $items = $itemsStatement->fetchAll();

    $filename = sprintf(
        'grade-%d-%s-%s.csv',
        (int) $period['id'],
        (string) $period['data_inicio'],
        (string) $period['data_fim']
    );

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'wb');

    if (!$output) {
        throw new RuntimeException('Nao foi possivel abrir a saida do CSV.');
    }

    fwrite($output, "\xEF\xBB\xBF");
    fputcsv($output, [
        'data',
        'cod_da_solicitacao',
        'nome_da_solicitacao',
        'nome_do_analista',
        'nome_da_grade',
        'tipo_da_solicitacao',
        'status',
        'prioridade',
    ]);

    foreach ($items as $item) {
        $origin = strtolower(trim((string) ($item['origem'] ?? '')));
        $requestType = in_array($origin, ['solicitacao_grade', 'solicitacao-grade'], true)
            ? 'Solicitacao de grade'
            : 'Briefing';

        $status = trim((string) ($item['status_solicitacao'] ?? ''));

        if ($status === '') {
            $status = grade_export_status_label((string) ($item['status_grade'] ?? ''));
        }

        fputcsv($output, [
            (string) ($item['data_prevista_publicacao'] ?? ''),
            (string) ($item['codigo_solicitacao'] ?? ''),
            (string) ($item['nome_solicitacao'] ?? ''),
            (string) ($item['nome_analista'] ?? 'A definir'),
            (string) ($period['nome'] ?? ''),
            $requestType,
            $status,
            (string) ($item['prioridade_nome'] ?? 'A definir'),
        ]);
    }

    fclose($output);
    exit;
} catch (Throwable $throwable) {
    http_response_code(500);
    exit('Nao foi possivel exportar o calendario agora.');
}

function grade_export_status_label(string $status): string
{
    $status = strtolower(trim($status));

    if ($status === '') {
        return 'A definir';
    }

    $labels = [
        'planejado' => 'Planejado',
        'publicado' => 'Publicado',
        'cancelado' => 'Cancelado',
        'finalizado' => 'Finalizado',
    ];

    if (isset($labels[$status])) {
        return $labels[$status];
    }

    return ucwords(str_replace(['_', '-'], ' ', $status));
}
