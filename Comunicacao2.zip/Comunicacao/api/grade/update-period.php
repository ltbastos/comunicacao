<?php

require __DIR__ . '/../../includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    grade_update_period_respond(405, [
        'ok' => false,
        'message' => 'Metodo nao permitido.',
    ]);
}

if (!is_operator_admin()) {
    grade_update_period_respond(403, [
        'ok' => false,
        'message' => 'Somente administradores podem editar uma grade.',
    ]);
}

$pdo = db();

if (!$pdo instanceof PDO) {
    grade_update_period_respond(503, [
        'ok' => false,
        'message' => 'Banco indisponivel no momento.',
    ]);
}

$periodId = (int) ($_POST['periodo_id'] ?? 0);
$name = trim((string) ($_POST['nome'] ?? ''));
$startDate = grade_update_period_normalize_date($_POST['data_inicio'] ?? null);
$endDate = grade_update_period_normalize_date($_POST['data_fim'] ?? null);

if ($periodId <= 0) {
    grade_update_period_validation('Grade invalida para edicao.', 'periodo_id');
}

if ($name === '') {
    grade_update_period_validation('Informe o nome da grade.', 'nome');
}

if ($startDate === null) {
    grade_update_period_validation('Informe a data de inicio da grade.', 'data_inicio');
}

if ($endDate === null) {
    grade_update_period_validation('Informe a data de fim da grade.', 'data_fim');
}

if ($startDate > $endDate) {
    grade_update_period_validation('A data de fim precisa ser maior ou igual a data de inicio.', 'data_fim');
}

try {
    $periodStatement = $pdo->prepare(
        'SELECT id, status
         FROM periodos_grade
         WHERE id = :id
         LIMIT 1'
    );
    $periodStatement->execute(['id' => $periodId]);
    $period = $periodStatement->fetch();

    if (!$period) {
        grade_update_period_respond(404, [
            'ok' => false,
            'message' => 'Grade nao encontrada.',
        ]);
    }

    if (grade_period_is_closed($period) && !is_operator_admin()) {
        grade_update_period_respond(423, [
            'ok' => false,
            'message' => 'Esta grade ja foi fechada e nao pode mais ser editada.',
        ]);
    }

    $outsideItems = $pdo->prepare(
        'SELECT COUNT(*)
         FROM grade_editorial
         WHERE periodo_id = :periodo_id
           AND (data_prevista_publicacao < :data_inicio OR data_prevista_publicacao > :data_fim)'
    );
    $outsideItems->execute([
        'periodo_id' => $periodId,
        'data_inicio' => $startDate,
        'data_fim' => $endDate,
    ]);

    if ((int) $outsideItems->fetchColumn() > 0) {
        grade_update_period_validation('A nova janela deixaria itens ja encaixados fora da grade.', 'data_inicio');
    }

    $start = new DateTimeImmutable($startDate);
    $update = $pdo->prepare(
        'UPDATE periodos_grade
         SET nome = :nome,
             ano = :ano,
             mes = :mes,
             data_inicio = :data_inicio,
             data_fim = :data_fim
         WHERE id = :id
         LIMIT 1'
    );
    $update->execute([
        'id' => $periodId,
        'nome' => $name,
        'ano' => (int) $start->format('Y'),
        'mes' => (int) $start->format('n'),
        'data_inicio' => $startDate,
        'data_fim' => $endDate,
    ]);

    echo json_encode([
        'ok' => true,
        'message' => 'Grade atualizada.',
        'period' => [
            'id' => $periodId,
            'nome' => $name,
            'data_inicio' => $startDate,
            'data_fim' => $endDate,
            'data_inicio_br' => format_date_br($startDate),
            'data_fim_br' => format_date_br($endDate),
            'status' => (string) ($period['status'] ?? 'aberto'),
            'status_label' => grade_status_label($period['status'] ?? 'aberto'),
        ],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    grade_update_period_respond(500, [
        'ok' => false,
        'message' => 'Nao consegui editar a grade agora.',
    ]);
}

function grade_update_period_normalize_date($value): ?string
{
    $value = trim((string) $value);

    if ($value === '') {
        return null;
    }

    try {
        return (new DateTimeImmutable($value))->format('Y-m-d');
    } catch (Throwable $throwable) {
        return null;
    }
}

function grade_update_period_validation(string $message, string $field): void
{
    grade_update_period_respond(422, [
        'ok' => false,
        'message' => $message,
        'field' => $field,
    ]);
}

function grade_update_period_respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}