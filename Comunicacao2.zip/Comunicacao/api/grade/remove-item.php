<?php
require __DIR__ . '/../../includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    grade_remove_item_respond(405, [
        'ok' => false,
        'message' => 'Metodo nao permitido.',
    ]);
}

if (!operator_has_role(['adm', 'analista'])) {
    grade_remove_item_respond(403, [
        'ok' => false,
        'message' => 'Acesso interno obrigatorio.',
    ]);
}

$pdo = db();

if (!$pdo instanceof PDO) {
    grade_remove_item_respond(503, [
        'ok' => false,
        'message' => 'Banco indisponivel no momento.',
    ]);
}

$itemId = (int) ($_POST['item_id'] ?? 0);
$periodId = (int) ($_POST['periodo_id'] ?? 0);

if ($itemId <= 0 || $periodId <= 0) {
    grade_remove_item_respond(422, [
        'ok' => false,
        'message' => 'Dados invalidos para remover o evento da grade.',
    ]);
}

try {
    $periodStatement = $pdo->prepare(
        'SELECT id, status
         FROM periodos_grade
         WHERE id = :id
         LIMIT 1'
    );
    $periodStatement->execute(['id' => $periodId]);
    $period = $periodStatement->fetch();

    if (!$period) {
        grade_remove_item_respond(404, [
            'ok' => false,
            'message' => 'Periodo da grade nao encontrado.',
        ]);
    }

    if (grade_period_is_closed($period) && !is_operator_admin()) {
        grade_remove_item_respond(423, [
            'ok' => false,
            'message' => 'Esta grade ja foi fechada e nao pode mais ser editada.',
        ]);
    }

    $itemStatement = $pdo->prepare(
        'SELECT
            ge.id,
            ge.periodo_id,
            ge.titulo AS grade_titulo,
            ge.tipo_demanda AS grade_tipo_demanda,
            ge.data_prevista_publicacao,
            b.id AS briefing_id,
            b.codigo,
            b.titulo AS briefing_titulo,
            b.origem,
            b.email_solicitante,
            b.data_desejada_publicacao,
            ss.chave AS status_solicitacao_chave,
            ss.nome AS status_solicitacao_nome,
            ss.cor AS status_solicitacao_cor,
            COALESCE(NULLIF(b.produto_tema, ""), b.titulo, ge.titulo) AS tema,
            COALESCE(NULLIF(a.nome, ""), "A definir") AS area_nome,
            COALESCE(NULLIF(cc.nome, ""), "Canal nao informado") AS canal_nome,
            COALESCE(NULLIF(cc.cor_badge, ""), "#1E5B8F") AS canal_cor,
            COALESCE(NULLIF(b.tipo_demanda, ""), NULLIF(ge.tipo_demanda, ""), "Encaixe") AS tipo_demanda,
            COALESCE(p.chave, "media") AS prioridade_chave,
            COALESCE(p.nome, "Media") AS prioridade_nome
         FROM grade_editorial ge
         LEFT JOIN briefings b ON b.grade_id = ge.id
         LEFT JOIN status_solicitacoes ss ON ss.id = b.status_solicitacao_id
         LEFT JOIN areas_solicitantes a ON a.id = COALESCE(b.area_id, ge.area_id)
         LEFT JOIN canais_comunicacao cc ON cc.id = ge.canal_id
         LEFT JOIN prioridades p ON p.id = b.prioridade_id
         WHERE ge.id = :id AND ge.periodo_id = :periodo_id
         LIMIT 1'
    );
    $itemStatement->execute([
        'id' => $itemId,
        'periodo_id' => $periodId,
    ]);
    $item = $itemStatement->fetch();

    if (!$item) {
        grade_remove_item_respond(404, [
            'ok' => false,
            'message' => 'Evento da grade nao encontrado neste periodo.',
        ]);
    }

    $briefingId = (int) ($item['briefing_id'] ?? 0);

    $pdo->beginTransaction();

    if ($briefingId > 0) {
        $updateBriefing = $pdo->prepare(
            'UPDATE briefings
             SET grade_id = NULL,
                 periodo_id = NULL,
                 esta_na_grade = 0
             WHERE id = :id
             LIMIT 1'
        );
        $updateBriefing->execute(['id' => $briefingId]);
    }

    $deleteItem = $pdo->prepare(
        'DELETE FROM grade_editorial
         WHERE id = :id AND periodo_id = :periodo_id
         LIMIT 1'
    );
    $deleteItem->execute([
        'id' => $itemId,
        'periodo_id' => $periodId,
    ]);

    if ($briefingId > 0) {
        $operator = current_operator() ?: [];
        $movementStatement = $pdo->prepare(
            'INSERT INTO briefing_movimentacoes (
                briefing_id,
                tipo_movimento,
                comentario_visivel,
                dados_adicionais,
                nome_autor,
                email_autor
            ) VALUES (
                :briefing_id,
                "remocao_grade",
                :comentario_visivel,
                :dados_adicionais,
                :nome_autor,
                :email_autor
            )'
        );
        $movementStatement->execute([
            'briefing_id' => $briefingId,
            'comentario_visivel' => 'Pedido removido da grade.',
            'dados_adicionais' => json_encode([
                'periodo_id' => $periodId,
                'grade_id' => $itemId,
                'data_publicacao' => $item['data_prevista_publicacao'] ?? null,
                'canal' => $item['canal_nome'] ?? null,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'nome_autor' => grade_remove_item_nullable($operator['nome'] ?? ''),
            'email_autor' => strtolower(trim((string) ($operator['email'] ?? 'sistema@local'))),
        ]);
    }

    $pdo->commit();

    $priority = priority_meta($item['prioridade_chave'] ?? 'media');
    $gradeReturnUrl = route_url('solicitacao-grade', ['periodo_id' => $periodId]);
    $briefing = null;

    if ($briefingId > 0) {
        $origin = strtolower(trim((string) ($item['origem'] ?? 'solicitante')));
        $originCategory = $origin === 'solicitacao_grade' ? 'grade' : 'briefing';
        $originLabel = $originCategory === 'grade' ? 'Solicitacao de grade' : 'Briefing';
        $solicitationStatus = solicitation_status_from_record($item);

        $briefing = [
            'id' => $briefingId,
            'codigo' => (string) ($item['codigo'] ?? ''),
            'title' => (string) ($item['tema'] ?: ($item['briefing_titulo'] ?? $item['grade_titulo'] ?? 'Pedido sem titulo')),
            'origin_category' => $originCategory,
            'origin_label' => $originLabel,
            'channel' => (string) ($item['canal_nome'] ?? 'Canal nao informado'),
            'channel_color' => (string) ($item['canal_cor'] ?? '#1E5B8F'),
            'area' => (string) ($item['area_nome'] ?? 'A definir'),
            'type' => (string) ($item['tipo_demanda'] ?? 'Encaixe'),
            'status' => $solicitationStatus,
            'priority_key' => (string) ($item['prioridade_chave'] ?? 'media'),
            'priority_label' => (string) ($priority['label'] ?? ($item['prioridade_nome'] ?? 'Media')),
            'priority_class' => tone_class($priority['tone'] ?? 'neutral'),
            'date_label' => format_date_br($item['data_desejada_publicacao'] ?: $item['data_prevista_publicacao']),
            'edit_url' => route_url('novo-briefing', [
                'briefing_id' => $briefingId,
                'email' => strtolower(trim((string) ($item['email_solicitante'] ?? ''))),
                'return_url' => $gradeReturnUrl,
            ]),
        ];
    }

    echo json_encode([
        'ok' => true,
        'message' => 'Evento removido da grade.',
        'item_id' => $itemId,
        'briefing' => $briefing,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    grade_remove_item_respond(500, [
        'ok' => false,
        'message' => 'Nao foi possivel remover o evento da grade agora.',
    ]);
}

function grade_remove_item_nullable($value): ?string
{
    $value = trim((string) $value);
    return $value === '' ? null : $value;
}

function grade_remove_item_respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
