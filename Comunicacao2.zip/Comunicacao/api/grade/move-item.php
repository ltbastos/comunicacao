<?php
require __DIR__ . '/../../includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'ok' => false,
        'message' => 'Método não permitido.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!operator_has_role(['adm', 'analista'])) {
    http_response_code(403);
    echo json_encode([
        'ok' => false,
        'message' => 'Acesso interno obrigatório.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$pdo = db();

if (!$pdo instanceof PDO) {
    http_response_code(503);
    echo json_encode([
        'ok' => false,
        'message' => 'Banco indisponível no momento.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$itemId = (int) ($_POST['item_id'] ?? 0);
$periodId = (int) ($_POST['periodo_id'] ?? 0);
$publishDate = trim((string) ($_POST['data_publicacao'] ?? ''));
$requestedSlot = (int) ($_POST['slot'] ?? 0);

if ($requestedSlot < 1 || $requestedSlot > 26) {
    $requestedSlot = 0;
}

if ($itemId <= 0 || $periodId <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $publishDate)) {
    http_response_code(422);
    echo json_encode([
        'ok' => false,
        'message' => 'Dados inválidos para mover o evento.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ((int) (new DateTimeImmutable($publishDate))->format('N') >= 6) {
    http_response_code(422);
    echo json_encode([
        'ok' => false,
        'message' => 'Sabado e domingo nao ficam disponiveis para encaixe na grade.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $periodStatement = $pdo->prepare(
        'SELECT id, data_inicio, data_fim, status
         FROM periodos_grade
         WHERE id = :id
         LIMIT 1'
    );
    $periodStatement->execute(['id' => $periodId]);
    $period = $periodStatement->fetch();

    if (!$period) {
        http_response_code(404);
        echo json_encode([
            'ok' => false,
            'message' => 'Período da grade não encontrado.',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if (grade_period_is_closed($period) && !is_operator_admin()) {
        http_response_code(423);
        echo json_encode([
            'ok' => false,
            'message' => 'Esta grade ja foi fechada e nao pode mais ser editada.',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if ($publishDate < $period['data_inicio'] || $publishDate > $period['data_fim']) {
        http_response_code(422);
        echo json_encode([
            'ok' => false,
            'message' => 'A nova data precisa ficar dentro da janela da grade.',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $itemStatement = $pdo->prepare(
        'SELECT ge.id, ge.canal_id, ge.ordem_dia, COALESCE(NULLIF(cc.nome, ""), "Canal nao informado") AS canal_nome
         FROM grade_editorial ge
         LEFT JOIN canais_comunicacao cc ON cc.id = ge.canal_id
         WHERE ge.id = :id AND ge.periodo_id = :periodo_id
         LIMIT 1'
    );
    $itemStatement->execute([
        'id' => $itemId,
        'periodo_id' => $periodId,
    ]);

    $item = $itemStatement->fetch();

    if (!$item) {
        http_response_code(404);
        echo json_encode([
            'ok' => false,
            'message' => 'Evento da grade não encontrado neste período.',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $capacity = grade_move_capacity_state(
        $pdo,
        $periodId,
        (int) $item['canal_id'],
        (string) $item['canal_nome'],
        $publishDate,
        $itemId,
        $period
    );

    if (!$capacity['available']) {
        http_response_code(422);
        echo json_encode([
            'ok' => false,
            'message' => sprintf(
                '%s ja atingiu o limite de %s em %s.',
                $item['canal_nome'],
                $capacity['limit_label'],
                format_date_br($publishDate)
            ),
            'next_free_date' => $capacity['next_free_date'],
            'next_free_label' => $capacity['next_free_date'] ? format_date_br($capacity['next_free_date']) : null,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $targetSlot = $requestedSlot > 0 ? $requestedSlot : max(1, (int) ($item['ordem_dia'] ?? 1));

    $updateStatement = $pdo->prepare(
        'UPDATE grade_editorial
         SET data_prevista_publicacao = :data_publicacao,
             ordem_dia = :ordem_dia
         WHERE id = :id AND periodo_id = :periodo_id
         LIMIT 1'
    );
    $updateStatement->execute([
        'data_publicacao' => $publishDate,
        'ordem_dia' => $targetSlot,
        'id' => $itemId,
        'periodo_id' => $periodId,
    ]);

    echo json_encode([
        'ok' => true,
        'message' => 'Evento movido com sucesso.',
        'item_id' => $itemId,
        'data_publicacao' => $publishDate,
        'slot' => $targetSlot,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Não foi possível salvar a nova data do evento.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function grade_move_capacity_state(PDO $pdo, int $periodId, int $channelId, string $channelName, string $date, int $excludeItemId, array $period): array
{
    $rule = grade_channel_limit_rule($channelName);
    $used = grade_move_used_slots($pdo, $periodId, $channelId, $date, $excludeItemId);

    return [
        'available' => $used < (int) $rule['limit'],
        'limit_label' => (string) ($rule['limit_label'] ?? ((int) $rule['limit'] . ' por dia')),
        'next_free_date' => grade_move_next_business_free_date($pdo, $periodId, $channelId, $channelName, $date, $excludeItemId, $period),
    ];
}

function grade_move_used_slots(PDO $pdo, int $periodId, int $channelId, string $date, int $excludeItemId): int
{
    $statement = $pdo->prepare(
        'SELECT COALESCE(SUM(capacidade_slot), 0)
         FROM grade_editorial
         WHERE periodo_id = :periodo_id
           AND canal_id = :canal_id
           AND data_prevista_publicacao = :data_publicacao
           AND id <> :exclude_id'
    );
    $statement->execute([
        'periodo_id' => $periodId,
        'canal_id' => $channelId,
        'data_publicacao' => $date,
        'exclude_id' => $excludeItemId,
    ]);

    return (int) $statement->fetchColumn();
}

function grade_move_next_business_free_date(PDO $pdo, int $periodId, int $channelId, string $channelName, string $startDate, int $excludeItemId, array $period): ?string
{
    $rule = grade_channel_limit_rule($channelName);
    $cursorDate = max($startDate, (new DateTimeImmutable('today'))->format('Y-m-d'), (string) $period['data_inicio']);
    $cursor = new DateTimeImmutable($cursorDate);
    $end = new DateTimeImmutable((string) $period['data_fim']);

    while ($cursor <= $end) {
        $dayOfWeek = (int) $cursor->format('N');
        $dateKey = $cursor->format('Y-m-d');

        if ($dayOfWeek <= 5 && grade_move_used_slots($pdo, $periodId, $channelId, $dateKey, $excludeItemId) < (int) $rule['limit']) {
            return $dateKey;
        }

        $cursor = $cursor->modify('+1 day');
    }

    return null;
}
