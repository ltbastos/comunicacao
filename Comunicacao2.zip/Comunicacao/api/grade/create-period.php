<?php

require __DIR__ . '/../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'ok' => false,
        'message' => 'Metodo nao permitido.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!is_operator_admin()) {
    http_response_code(403);
    echo json_encode([
        'ok' => false,
        'message' => 'Somente administradores podem criar uma nova grade.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$pdo = db();

if (!$pdo instanceof PDO) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Nao foi possivel conectar ao banco de dados.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$name = trim((string) ($_POST['nome'] ?? ''));
$startDate = normalize_period_date($_POST['data_inicio'] ?? null);
$endDate = normalize_period_date($_POST['data_fim'] ?? null);

if ($name === '') {
    respond_period_validation('Informe o nome da grade.', 'nome');
}

if ($startDate === null) {
    respond_period_validation('Informe a data de inicio da grade.', 'data_inicio');
}

if ($endDate === null) {
    respond_period_validation('Informe a data de fim da grade.', 'data_fim');
}

if ($startDate > $endDate) {
    respond_period_validation('A data de fim precisa ser maior ou igual a data de inicio.', 'data_fim');
}

$today = (new DateTimeImmutable('today'))->format('Y-m-d');
if ($startDate < $today || $endDate < $today) {
    respond_period_validation('A grade precisa comecar e terminar hoje ou em uma data futura.', 'data_inicio');
}

$start = new DateTimeImmutable($startDate);
$year = (int) $start->format('Y');
$month = (int) $start->format('n');

try {
    $insertStatement = $pdo->prepare(
        'INSERT INTO periodos_grade (
            nome,
            ano,
            mes,
            data_inicio,
            data_fim,
            status
         ) VALUES (
            :nome,
            :ano,
            :mes,
            :data_inicio,
            :data_fim,
            :status
         )'
    );
    $insertStatement->execute([
        'nome' => $name,
        'ano' => $year,
        'mes' => $month,
        'data_inicio' => $startDate,
        'data_fim' => $endDate,
        'status' => 'aberto',
    ]);

    echo json_encode([
        'ok' => true,
        'message' => 'Grade criada com sucesso.',
        'period' => [
            'id' => (int) $pdo->lastInsertId(),
            'nome' => $name,
            'ano' => $year,
            'mes' => $month,
            'data_inicio' => $startDate,
            'data_fim' => $endDate,
            'data_inicio_br' => format_date_br($startDate),
            'data_fim_br' => format_date_br($endDate),
            'status' => 'aberto',
            'status_label' => 'Aberta',
        ],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Nao consegui criar a grade agora.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function normalize_period_date($value): ?string
{
    $value = trim((string) $value);

    if ($value === '') {
        return null;
    }

    try {
        return (new DateTimeImmutable($value))->format('Y-m-d');
    } catch (Throwable $throwable) {
        return null;
    }
}

function respond_period_validation(string $message, string $field): void
{
    http_response_code(422);
    echo json_encode([
        'ok' => false,
        'message' => $message,
        'field' => $field,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
