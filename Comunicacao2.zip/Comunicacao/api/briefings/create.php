<?php

require __DIR__ . '/../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'ok' => false,
        'message' => 'Método não permitido.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$pdo = db();

if (!$pdo instanceof PDO) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Não consegui conectar ao banco agora.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$mode = strtolower(trim((string) ($_POST['mode'] ?? 'send')));
$mode = $mode === 'draft' ? 'draft' : 'send';
$briefingId = (int) ($_POST['briefing_id'] ?? 0);

$payload = [
    'titulo' => trim((string) ($_POST['titulo'] ?? '')),
    'descricao_resumida' => trim((string) ($_POST['descricao_resumida'] ?? '')),
    'objetivo' => trim((string) ($_POST['objetivo'] ?? '')),
    'contexto' => trim((string) ($_POST['contexto'] ?? '')),
    'mensagem_principal' => trim((string) ($_POST['mensagem_principal'] ?? '')),
    'produto_tema' => trim((string) ($_POST['produto_tema'] ?? '')),
    'cta' => trim((string) ($_POST['cta'] ?? '')),
    'nome_solicitante' => trim((string) ($_POST['nome_solicitante'] ?? '')),
    'email_solicitante' => strtolower(trim((string) ($_POST['email_solicitante'] ?? ''))),
    'links_apoio' => trim((string) ($_POST['links_apoio'] ?? '')),
    'observacoes_solicitante' => trim((string) ($_POST['observacoes_solicitante'] ?? '')),
    'acao_gerente' => trim((string) ($_POST['acao_gerente'] ?? '')),
    'change_flag' => trim((string) ($_POST['change_flag'] ?? 'Não')),
    'change_iniciativa' => trim((string) ($_POST['change_iniciativa'] ?? '')),
    'identidade_visual_existente' => trim((string) ($_POST['identidade_visual_existente'] ?? 'Não')),
    'link_local' => trim((string) ($_POST['link_local'] ?? '')),
    'link_destino' => trim((string) ($_POST['link_destino'] ?? '')),
    'onde_saber_mais' => trim((string) ($_POST['onde_saber_mais'] ?? '')),
    'sugestao_texto' => trim((string) ($_POST['sugestao_texto'] ?? '')),
];

$payload['area_id'] = (int) ($_POST['area_id'] ?? 0);
$payload['prioridade_id'] = (int) ($_POST['prioridade_id'] ?? 0);
$payload['esta_na_grade'] = normalize_boolean_choice($_POST['esta_na_grade'] ?? '1');
$payload['data_desejada_publicacao'] = normalize_date_value($_POST['data_desejada_publicacao'] ?? null);
$payload['validade_ate'] = normalize_date_value($_POST['validade_ate'] ?? null);

$payload['canais'] = normalize_integer_array($_POST['canais'] ?? []);
$payload['publicos_alvo'] = normalize_string_array($_POST['publicos_alvo'] ?? []);
$payload['classificacao_comunicacao'] = normalize_string_array($_POST['classificacao_comunicacao'] ?? []);
$payload['somos_tags'] = normalize_string_array($_POST['somos_tags'] ?? []);
$payload['tipos_comunicacao'] = normalize_string_array($_POST['tipos_comunicacao'] ?? []);

$payload['publico_alvo'] = implode(', ', $payload['publicos_alvo']);
$payload['segmento'] = implode(', ', $payload['classificacao_comunicacao']);
$payload['tipo_demanda'] = implode(', ', $payload['tipos_comunicacao']);
$payload['canal_id'] = null;

if ($payload['email_solicitante'] === '' || !filter_var($payload['email_solicitante'], FILTER_VALIDATE_EMAIL)) {
    respond_validation_error('Informe um e-mail válido para continuar.', 'email_solicitante');
}

if (date_is_before_today($payload['data_desejada_publicacao'])) {
    respond_validation_error('A data da publicação precisa ser hoje ou uma data futura.', 'data_desejada_publicacao');
}

if (date_is_before_today($payload['validade_ate'])) {
    respond_validation_error('A validade da comunicação precisa ser hoje ou uma data futura.', 'validade_ate');
}

$existingBriefing = null;
$isInternalBriefingEdit = false;
$isSubmittedBriefingEdit = false;

if ($briefingId > 0) {
    $existingStatement = $pdo->prepare(
        'SELECT
            b.id,
            b.codigo,
            b.email_solicitante,
            b.grade_id,
            b.status_id,
            b.status_solicitacao_id,
            ss.chave AS status_solicitacao_chave,
            cs.chave AS status_key,
            b.data_envio
         FROM briefings b
         LEFT JOIN configuracoes_status cs ON cs.id = b.status_id
         LEFT JOIN status_solicitacoes ss ON ss.id = b.status_solicitacao_id
         WHERE b.id = :id
         LIMIT 1'
    );
    $existingStatement->execute(['id' => $briefingId]);
    $existingBriefing = $existingStatement->fetch();

    if (!$existingBriefing) {
        respond_validation_error('Nao encontrei esse pedido para editar.', 'briefing_id');
    }

    $isSubmittedBriefingEdit = ($existingBriefing['status_key'] ?? '') !== 'rascunho';
    $existingSolicitationStatusKey = strtolower(trim((string) ($existingBriefing['status_solicitacao_chave'] ?? '')));
    $existingSolicitationStatusKey = $existingSolicitationStatusKey !== '' ? $existingSolicitationStatusKey : 'aberto';
    $existingRequesterEmail = strtolower(trim((string) ($existingBriefing['email_solicitante'] ?? '')));
    $currentRequester = current_requester();
    $currentRequesterEmail = strtolower(trim((string) ($currentRequester['email'] ?? '')));
    $isRequesterOwner = $currentRequesterEmail !== '' && $currentRequesterEmail === $existingRequesterEmail;
    $isAdmin = is_operator_admin();
    $isAnalyst = operator_has_role(['analista']);
    $canEditExistingBriefing = $isAdmin || ($existingSolicitationStatusKey === 'aberto' && ($isRequesterOwner || $isAnalyst));

    if (!$canEditExistingBriefing) {
        respond_validation_error('Este pedido so pode ser editado por adm quando nao esta aberto.', 'briefing_id');
    }

    $isInternalBriefingEdit = $isSubmittedBriefingEdit && operator_has_role(['adm', 'analista']);

    if (!$isInternalBriefingEdit && strtolower((string) $existingBriefing['email_solicitante']) !== $payload['email_solicitante']) {
        respond_validation_error('Esse pedido esta vinculado a outro e-mail.', 'email_solicitante');
    }
}

$requiredFields = [
    'titulo' => 'título da demanda',
    'email_solicitante' => 'e-mail do solicitante',
    'area_id' => 'área solicitante',
    'data_desejada_publicacao' => 'data da publicação',
    'produto_tema' => 'assunto / tema / ação',
    'objetivo' => 'objetivo da comunicação',
    'contexto' => 'histórico do assunto',
    'mensagem_principal' => 'mensagem principal',
    'descricao_resumida' => 'descrição resumida',
    'prioridade_id' => 'prioridade',
    'sugestao_texto' => 'sugestão de texto',
];

if ($mode === 'send') {
    foreach ($requiredFields as $field => $label) {
        $value = $payload[$field] ?? null;
        $isEmpty = is_int($value) ? $value <= 0 : $value === null || $value === '';

        if ($isEmpty) {
            respond_validation_error('Faltou preencher ' . $label . '.', $field);
        }
    }

    if (count($payload['canais']) === 0) {
        respond_validation_error('Escolha ao menos um canal desejado.', 'canais');
    }

    if (count($payload['publicos_alvo']) === 0) {
        respond_validation_error('Marque ao menos um público-alvo.', 'publicos_alvo');
    }
}

try {
    $statusMap = fetch_status_map($pdo);
    $solicitationStatusId = solicitation_status_id($pdo, 'aberto');
    $prioridadePadrao = resolve_priority_id($pdo, $payload['prioridade_id']);

    $statusId = $isSubmittedBriefingEdit
        ? (int) ($existingBriefing['status_id'] ?? 0)
        : ($mode === 'draft'
            ? ($statusMap['rascunho'] ?? null)
            : ($statusMap['enviado'] ?? null));

    if ($statusId === null || $solicitationStatusId === null || $prioridadePadrao === null) {
        throw new RuntimeException('Status ou prioridade padrão não encontrados.');
    }

    if ($isSubmittedBriefingEdit && (int) ($existingBriefing['status_solicitacao_id'] ?? 0) > 0) {
        $solicitationStatusId = (int) $existingBriefing['status_solicitacao_id'];
    }

    $payload['prioridade_id'] = $payload['prioridade_id'] > 0 ? $payload['prioridade_id'] : $prioridadePadrao;
    $payload['area_id'] = $payload['area_id'] > 0 ? $payload['area_id'] : null;

    $channelRows = fetch_channels_by_ids($pdo, $payload['canais']);
    $payload['canais'] = array_map(static function (array $row) {
        return (int) $row['id'];
    }, $channelRows);
    $payload['canal_id'] = $payload['canais'][0] ?? null;
    $payload['canais_nomes'] = array_map(static function (array $row) {
        return $row['nome'];
    }, $channelRows);

    if ($mode === 'send' && count($payload['canais']) === 0) {
        respond_validation_error('Escolha ao menos um canal válido.', 'canais');
    }

    if ($mode === 'send' && empty($existingBriefing['grade_id'])) {
        $capacityValidation = grade_capacity_validation_for_channels($pdo, $channelRows, $payload['data_desejada_publicacao']);
        if (!($capacityValidation['ok'] ?? true)) {
            respond_validation_error($capacityValidation['message'] ?? 'A data escolhida nao tem capacidade para o canal selecionado.', 'data_desejada_publicacao');
        }
    }

    $dadosFormulario = [
        'esta_na_grade' => $payload['esta_na_grade'] ? '1' : '0',
        'canais' => $payload['canais_nomes'],
        'canais_ids' => $payload['canais'],
        'publicos_alvo' => $payload['publicos_alvo'],
        'classificacao_comunicacao' => $payload['classificacao_comunicacao'],
        'somos_tags' => $payload['somos_tags'],
        'tipos_comunicacao' => $payload['tipos_comunicacao'],
        'change_flag' => $payload['change_flag'],
        'change_iniciativa' => $payload['change_iniciativa'],
        'identidade_visual_existente' => $payload['identidade_visual_existente'],
        'acao_gerente' => $payload['acao_gerente'],
        'link_local' => $payload['link_local'],
        'link_destino' => $payload['link_destino'],
        'onde_saber_mais' => $payload['onde_saber_mais'],
        'validade_ate' => $payload['validade_ate'],
        'sugestao_texto' => $payload['sugestao_texto'],
    ];

    $pdo->beginTransaction();

    $upsertUser = $pdo->prepare(
        'INSERT INTO usuarios_informados (nome, email)
         VALUES (:nome, :email)
         ON DUPLICATE KEY UPDATE
            nome = COALESCE(NULLIF(VALUES(nome), ""), nome),
            atualizado_em = CURRENT_TIMESTAMP'
    );
    $upsertUser->execute([
        'nome' => $payload['nome_solicitante'] !== '' ? $payload['nome_solicitante'] : null,
        'email' => $payload['email_solicitante'],
    ]);

    $dataEnvio = $mode === 'send'
        ? ($existingBriefing['data_envio'] ?? date('Y-m-d H:i:s'))
        : ($isSubmittedBriefingEdit ? ($existingBriefing['data_envio'] ?? null) : null);

    if ($existingBriefing) {
        $briefingId = (int) $existingBriefing['id'];

        $updateBriefing = $pdo->prepare(
            'UPDATE briefings SET
                titulo = :titulo,
                descricao_resumida = :descricao_resumida,
                objetivo = :objetivo,
                contexto = :contexto,
                mensagem_principal = :mensagem_principal,
                publico_alvo = :publico_alvo,
                segmento = :segmento,
                produto_tema = :produto_tema,
                cta = :cta,
                tipo_demanda = :tipo_demanda,
                canal_id = :canal_id,
                area_id = :area_id,
                esta_na_grade = :esta_na_grade,
                prioridade_id = :prioridade_id,
                status_id = :status_id,
                status_solicitacao_id = :status_solicitacao_id,
                nome_solicitante = :nome_solicitante,
                email_solicitante = :email_solicitante,
                data_desejada_publicacao = :data_desejada_publicacao,
                links_apoio = :links_apoio,
                observacoes_solicitante = :observacoes_solicitante,
                dados_formulario_json = :dados_formulario_json,
                data_envio = :data_envio
             WHERE id = :id'
        );

        $updateBriefing->execute([
            'id' => $briefingId,
            'titulo' => $payload['titulo'] !== '' ? $payload['titulo'] : 'Briefing em construção',
            'descricao_resumida' => nullable_value($payload['descricao_resumida']),
            'objetivo' => nullable_value($payload['objetivo']),
            'contexto' => nullable_value($payload['contexto']),
            'mensagem_principal' => nullable_value($payload['mensagem_principal']),
            'publico_alvo' => nullable_value($payload['publico_alvo']),
            'segmento' => nullable_value($payload['segmento']),
            'produto_tema' => nullable_value($payload['produto_tema']),
            'cta' => nullable_value($payload['cta']),
            'tipo_demanda' => nullable_value($payload['tipo_demanda']),
            'canal_id' => $payload['canal_id'],
            'area_id' => $payload['area_id'],
            'esta_na_grade' => $payload['esta_na_grade'],
            'prioridade_id' => $payload['prioridade_id'],
            'status_id' => $statusId,
            'status_solicitacao_id' => $solicitationStatusId,
            'nome_solicitante' => nullable_value($payload['nome_solicitante']),
            'email_solicitante' => $payload['email_solicitante'],
            'data_desejada_publicacao' => $payload['data_desejada_publicacao'],
            'links_apoio' => nullable_value($payload['links_apoio']),
            'observacoes_solicitante' => nullable_value(merge_observations($payload)),
            'dados_formulario_json' => json_encode($dadosFormulario, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'data_envio' => $dataEnvio,
        ]);

        $codigo = (string) $existingBriefing['codigo'];

        $deleteBriefingChannels = $pdo->prepare('DELETE FROM briefing_canais WHERE briefing_id = :briefing_id');
        $deleteBriefingChannels->execute(['briefing_id' => $briefingId]);
    } else {
        $temporaryCode = 'TMP-' . strtoupper(bin2hex(random_bytes(4)));

        $insertBriefing = $pdo->prepare(
            'INSERT INTO briefings (
                codigo,
                titulo,
                descricao_resumida,
                objetivo,
                contexto,
                mensagem_principal,
                publico_alvo,
                segmento,
                produto_tema,
                cta,
                tipo_demanda,
                canal_id,
                area_id,
                periodo_id,
                grade_id,
                esta_na_grade,
                prioridade_id,
                status_id,
                status_solicitacao_id,
                origem,
                nome_solicitante,
                email_solicitante,
                data_desejada_publicacao,
                prazo_limite,
                links_apoio,
                observacoes_solicitante,
                dados_formulario_json,
                responsavel_atual_nome,
                responsavel_atual_email,
                data_envio
             ) VALUES (
                :codigo,
                :titulo,
                :descricao_resumida,
                :objetivo,
                :contexto,
                :mensagem_principal,
                :publico_alvo,
                :segmento,
                :produto_tema,
                :cta,
                :tipo_demanda,
                :canal_id,
                :area_id,
                NULL,
                NULL,
                :esta_na_grade,
                :prioridade_id,
                :status_id,
                :status_solicitacao_id,
                "solicitante",
                :nome_solicitante,
                :email_solicitante,
                :data_desejada_publicacao,
                NULL,
                :links_apoio,
                :observacoes_solicitante,
                :dados_formulario_json,
                NULL,
                NULL,
                :data_envio
             )'
        );

        $insertBriefing->execute([
            'codigo' => $temporaryCode,
            'titulo' => $payload['titulo'] !== '' ? $payload['titulo'] : 'Briefing em construção',
            'descricao_resumida' => nullable_value($payload['descricao_resumida']),
            'objetivo' => nullable_value($payload['objetivo']),
            'contexto' => nullable_value($payload['contexto']),
            'mensagem_principal' => nullable_value($payload['mensagem_principal']),
            'publico_alvo' => nullable_value($payload['publico_alvo']),
            'segmento' => nullable_value($payload['segmento']),
            'produto_tema' => nullable_value($payload['produto_tema']),
            'cta' => nullable_value($payload['cta']),
            'tipo_demanda' => nullable_value($payload['tipo_demanda']),
            'canal_id' => $payload['canal_id'],
            'area_id' => $payload['area_id'],
            'esta_na_grade' => $payload['esta_na_grade'],
            'prioridade_id' => $payload['prioridade_id'],
            'status_id' => $statusId,
            'status_solicitacao_id' => $solicitationStatusId,
            'nome_solicitante' => nullable_value($payload['nome_solicitante']),
            'email_solicitante' => $payload['email_solicitante'],
            'data_desejada_publicacao' => $payload['data_desejada_publicacao'],
            'links_apoio' => nullable_value($payload['links_apoio']),
            'observacoes_solicitante' => nullable_value(merge_observations($payload)),
            'dados_formulario_json' => json_encode($dadosFormulario, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'data_envio' => $dataEnvio,
        ]);

        $briefingId = (int) $pdo->lastInsertId();
        $codigo = sprintf('BRF-%s-%04d', date('Y'), $briefingId);

        $updateCode = $pdo->prepare('UPDATE briefings SET codigo = :codigo WHERE id = :id');
        $updateCode->execute([
            'codigo' => $codigo,
            'id' => $briefingId,
        ]);
    }

    if (count($payload['canais']) > 0) {
        $insertBriefingCanal = $pdo->prepare(
            'INSERT INTO briefing_canais (briefing_id, canal_id, ordem)
             VALUES (:briefing_id, :canal_id, :ordem)'
        );

        foreach ($payload['canais'] as $index => $channelId) {
            $insertBriefingCanal->execute([
                'briefing_id' => $briefingId,
                'canal_id' => $channelId,
                'ordem' => $index + 1,
            ]);
        }
    }

    $uploadedAttachmentNames = store_uploaded_attachments($pdo, $briefingId, $_FILES['anexos'] ?? null);

    $previousStatusId = $existingBriefing ? (int) $existingBriefing['status_id'] : null;
    $movementType = $isSubmittedBriefingEdit
        ? 'atualizacao_briefing'
        : resolve_movement_type($existingBriefing !== null, $mode);
    $movementComment = $isSubmittedBriefingEdit
        ? ($isInternalBriefingEdit ? 'Pedido atualizado pelo time interno.' : 'Pedido atualizado pelo solicitante.')
        : ($mode === 'draft'
            ? ($existingBriefing ? 'Rascunho atualizado pelo solicitante.' : 'Rascunho iniciado pelo solicitante.')
            : ($existingBriefing ? 'Rascunho finalizado e enviado pelo solicitante.' : 'Briefing enviado pelo solicitante.'));

    $insertMovement = $pdo->prepare(
        'INSERT INTO briefing_movimentacoes (
            briefing_id,
            tipo_movimento,
            status_anterior_id,
            status_novo_id,
            comentario_interno,
            comentario_visivel,
            dados_adicionais,
            nome_autor,
            email_autor
        ) VALUES (
            :briefing_id,
            :tipo_movimento,
            :status_anterior_id,
            :status_novo_id,
            NULL,
            :comentario_visivel,
            :dados_adicionais,
            :nome_autor,
            :email_autor
        )'
    );

    $insertMovement->execute([
        'briefing_id' => $briefingId,
        'tipo_movimento' => $movementType,
        'status_anterior_id' => $previousStatusId ?: null,
        'status_novo_id' => $statusId,
        'comentario_visivel' => $movementComment,
        'dados_adicionais' => json_encode([
            'mode' => $mode,
            'origem' => 'novo-briefing',
            'canais' => $payload['canais_nomes'],
            'anexos' => $uploadedAttachmentNames,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'nome_autor' => $payload['nome_solicitante'] !== '' ? $payload['nome_solicitante'] : null,
        'email_autor' => $payload['email_solicitante'],
    ]);

    $pdo->commit();

    set_current_requester([
        'nome' => $payload['nome_solicitante'],
        'email' => $payload['email_solicitante'],
    ]);

    echo json_encode([
        'ok' => true,
        'briefing_id' => $briefingId,
        'codigo' => $codigo,
        'mode' => $mode,
        'message' => $isSubmittedBriefingEdit
            ? 'Mudanças aplicadas com sucesso.'
            : ($mode === 'draft' ? 'Rascunho salvo direitinho.' : 'Briefing enviado. Agora ele já aparece nos seus pedidos.'),
        'redirect_url' => route_url('acompanhar-pedidos', [
            'submitted' => $isSubmittedBriefingEdit ? 'updated' : $mode,
            'codigo' => $codigo,
        ]),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Não consegui salvar o briefing agora. Tente mais uma vez.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function respond_validation_error(string $message, string $field): void
{
    http_response_code(422);
    echo json_encode([
        'ok' => false,
        'message' => $message,
        'field' => $field,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function nullable_value(?string $value): ?string
{
    $trimmed = trim((string) $value);
    return $trimmed === '' ? null : $trimmed;
}

function normalize_boolean_choice($value): int
{
    return (string) $value === '1' ? 1 : 0;
}

function normalize_date_value($value): ?string
{
    $value = trim((string) $value);
    if ($value === '') {
        return null;
    }

    try {
        return (new DateTimeImmutable($value))->format('Y-m-d');
    } catch (Throwable $throwable) {
        return null;
    }
}

function date_is_before_today(?string $value): bool
{
    if ($value === null || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return false;
    }

    return $value < (new DateTimeImmutable('today'))->format('Y-m-d');
}

function normalize_string_array($values): array
{
    $values = is_array($values) ? $values : [$values];
    $normalized = [];

    foreach ($values as $value) {
        $value = trim((string) $value);
        if ($value !== '') {
            $normalized[] = $value;
        }
    }

    return array_values(array_unique($normalized));
}

function normalize_integer_array($values): array
{
    $values = is_array($values) ? $values : [$values];
    $normalized = [];

    foreach ($values as $value) {
        $value = (int) $value;
        if ($value > 0) {
            $normalized[] = $value;
        }
    }

    return array_values(array_unique($normalized));
}

function fetch_status_map(PDO $pdo): array
{
    $statement = $pdo->query('SELECT id, chave FROM configuracoes_status WHERE ativo = 1');
    $items = $statement->fetchAll();
    $map = [];

    foreach ($items as $item) {
        $map[$item['chave']] = (int) $item['id'];
    }

    return $map;
}

function resolve_priority_id(PDO $pdo, int $priorityId): ?int
{
    if ($priorityId > 0) {
        $statement = $pdo->prepare('SELECT id FROM prioridades WHERE id = :id AND ativo = 1 LIMIT 1');
        $statement->execute(['id' => $priorityId]);
        $row = $statement->fetch();
        if ($row) {
            return (int) $row['id'];
        }
    }

    $statement = $pdo->query(
        "SELECT id
         FROM prioridades
         WHERE ativo = 1
         ORDER BY CASE WHEN chave = 'media' THEN 0 ELSE 1 END, ordem, id
         LIMIT 1"
    );
    $row = $statement->fetch();

    return $row ? (int) $row['id'] : null;
}

function fetch_channels_by_ids(PDO $pdo, array $channelIds): array
{
    if (count($channelIds) === 0) {
        return [];
    }

    $placeholders = implode(', ', array_fill(0, count($channelIds), '?'));
    $statement = $pdo->prepare(
        "SELECT id, nome
         FROM canais_comunicacao
         WHERE ativo = 1 AND id IN ($placeholders)
         ORDER BY nome"
    );
    $statement->execute($channelIds);

    return $statement->fetchAll();
}

function resolve_movement_type(bool $isEditing, string $mode): string
{
    if ($isEditing && $mode === 'draft') {
        return 'atualizacao_rascunho';
    }

    if ($isEditing && $mode === 'send') {
        return 'envio_rascunho';
    }

    if (!$isEditing && $mode === 'draft') {
        return 'criacao_rascunho';
    }

    return 'criacao_envio';
}

function merge_observations(array $payload): string
{
    $parts = [];

    if ($payload['observacoes_solicitante'] !== '') {
        $parts[] = 'Observações: ' . $payload['observacoes_solicitante'];
    }

    if ($payload['onde_saber_mais'] !== '') {
        $parts[] = 'Onde saber mais: ' . $payload['onde_saber_mais'];
    }

    if ($payload['link_local'] !== '' || $payload['link_destino'] !== '') {
        $parts[] = 'Link na peça: ' . trim($payload['link_local'] . ' ' . $payload['link_destino']);
    }

    if ($payload['acao_gerente'] !== '') {
        $parts[] = 'Ação do gerente: ' . $payload['acao_gerente'];
    }

    if ($payload['sugestao_texto'] !== '') {
        $parts[] = 'Sugestão de texto: ' . $payload['sugestao_texto'];
    }

    return implode("\n\n", $parts);
}

function store_uploaded_attachments(PDO $pdo, int $briefingId, $files): array
{
    $entries = normalize_uploaded_files($files);
    if (count($entries) === 0) {
        return [];
    }

    $allowedExtensions = ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'csv', 'txt'];
    $maxSizeBytes = 10 * 1024 * 1024;

    $uploadRoot = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'briefings' . DIRECTORY_SEPARATOR . $briefingId;
    if (!is_dir($uploadRoot) && !mkdir($uploadRoot, 0775, true) && !is_dir($uploadRoot)) {
        throw new RuntimeException('Não consegui preparar a pasta de anexos.');
    }

    $insertAttachment = $pdo->prepare(
        'INSERT INTO briefing_anexos (
            briefing_id,
            nome_arquivo,
            nome_original,
            caminho_arquivo,
            extensao,
            mime_type,
            tamanho_bytes
         ) VALUES (
            :briefing_id,
            :nome_arquivo,
            :nome_original,
            :caminho_arquivo,
            :extensao,
            :mime_type,
            :tamanho_bytes
         )'
    );

    $storedNames = [];

    foreach ($entries as $entry) {
        if ((int) $entry['error'] !== UPLOAD_ERR_OK) {
            continue;
        }

        $originalName = (string) $entry['name'];
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

        if ($originalName === '' || !in_array($extension, $allowedExtensions, true)) {
            continue;
        }

        if ((int) $entry['size'] > $maxSizeBytes) {
            continue;
        }

        $safeBaseName = sanitize_file_name(pathinfo($originalName, PATHINFO_FILENAME));
        $targetName = $safeBaseName . '-' . uniqid('', true) . '.' . $extension;
        $targetPath = $uploadRoot . DIRECTORY_SEPARATOR . $targetName;

        if (!move_uploaded_file((string) $entry['tmp_name'], $targetPath)) {
            throw new RuntimeException('Falha ao salvar anexo enviado.');
        }

        $relativePath = 'uploads/briefings/' . $briefingId . '/' . $targetName;

        $insertAttachment->execute([
            'briefing_id' => $briefingId,
            'nome_arquivo' => $targetName,
            'nome_original' => $originalName,
            'caminho_arquivo' => $relativePath,
            'extensao' => $extension,
            'mime_type' => $entry['type'] ?? null,
            'tamanho_bytes' => (int) $entry['size'],
        ]);

        $storedNames[] = $originalName;
    }

    return $storedNames;
}

function normalize_uploaded_files($files): array
{
    if (!is_array($files) || !isset($files['name'])) {
        return [];
    }

    if (!is_array($files['name'])) {
        return [$files];
    }

    $normalized = [];
    $total = count($files['name']);

    for ($index = 0; $index < $total; $index += 1) {
        $normalized[] = [
            'name' => $files['name'][$index] ?? '',
            'type' => $files['type'][$index] ?? '',
            'tmp_name' => $files['tmp_name'][$index] ?? '',
            'error' => $files['error'][$index] ?? UPLOAD_ERR_NO_FILE,
            'size' => $files['size'][$index] ?? 0,
        ];
    }

    return $normalized;
}

function sanitize_file_name(string $value): string
{
    $value = preg_replace('/[^A-Za-z0-9_-]+/', '-', $value);
    $value = trim((string) $value, '-');
    return $value !== '' ? $value : 'anexo';
}
