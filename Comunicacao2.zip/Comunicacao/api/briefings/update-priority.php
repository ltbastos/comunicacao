<?php

require __DIR__ . '/../bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    briefing_priority_respond(405, [
        'ok' => false,
        'message' => 'Metodo nao permitido.',
    ]);
}

if (!is_operator_admin()) {
    briefing_priority_respond(403, [
        'ok' => false,
        'message' => 'Apenas administradores podem alterar a prioridade.',
    ]);
}

$pdo = db();

if (!$pdo instanceof PDO) {
    briefing_priority_respond(503, [
        'ok' => false,
        'message' => 'Banco indisponivel no momento.',
    ]);
}

$briefingId = (int) ($_POST['briefing_id'] ?? 0);
$priorityKey = strtolower(trim((string) ($_POST['priority'] ?? '')));

if ($briefingId <= 0 || $priorityKey === '') {
    briefing_priority_respond(422, [
        'ok' => false,
        'message' => 'Dados invalidos para atualizar a prioridade.',
    ]);
}

try {
    $priorityStatement = $pdo->prepare(
        'SELECT id, chave, nome
         FROM prioridades
         WHERE chave = :chave AND ativo = 1
         LIMIT 1'
    );
    $priorityStatement->execute(['chave' => $priorityKey]);
    $priority = $priorityStatement->fetch();

    if (!$priority) {
        briefing_priority_respond(422, [
            'ok' => false,
            'message' => 'Prioridade invalida.',
        ]);
    }

    $briefingStatement = $pdo->prepare(
        'SELECT
            b.id,
            b.codigo,
            b.prioridade_id,
            p.chave AS prioridade_chave,
            p.nome AS prioridade_nome
         FROM briefings b
         LEFT JOIN prioridades p ON p.id = b.prioridade_id
         WHERE b.id = :id
         LIMIT 1'
    );
    $briefingStatement->execute(['id' => $briefingId]);
    $briefing = $briefingStatement->fetch();

    if (!$briefing) {
        briefing_priority_respond(404, [
            'ok' => false,
            'message' => 'Briefing nao encontrado.',
        ]);
    }

    $priorityId = (int) $priority['id'];

    $pdo->beginTransaction();

    $updateStatement = $pdo->prepare(
        'UPDATE briefings
         SET prioridade_id = :prioridade_id
         WHERE id = :id
         LIMIT 1'
    );
    $updateStatement->execute([
        'prioridade_id' => $priorityId,
        'id' => $briefingId,
    ]);

    if ((int) ($briefing['prioridade_id'] ?? 0) !== $priorityId) {
        $operator = current_operator() ?: [];
        $movementStatement = $pdo->prepare(
            'INSERT INTO briefing_movimentacoes (
                briefing_id,
                tipo_movimento,
                comentario_interno,
                comentario_visivel,
                dados_adicionais,
                nome_autor,
                email_autor
            ) VALUES (
                :briefing_id,
                "prioridade",
                :comentario_interno,
                :comentario_visivel,
                :dados_adicionais,
                :nome_autor,
                :email_autor
            )'
        );
        $movementStatement->execute([
            'briefing_id' => $briefingId,
            'comentario_interno' => 'Prioridade atualizada pelo administrador.',
            'comentario_visivel' => 'Prioridade atualizada para ' . $priority['nome'] . '.',
            'dados_adicionais' => json_encode([
                'prioridade_anterior' => [
                    'chave' => (string) ($briefing['prioridade_chave'] ?? ''),
                    'nome' => (string) ($briefing['prioridade_nome'] ?? ''),
                ],
                'prioridade_nova' => [
                    'chave' => (string) $priority['chave'],
                    'nome' => (string) $priority['nome'],
                ],
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'nome_autor' => briefing_priority_nullable($operator['nome'] ?? ''),
            'email_autor' => strtolower(trim((string) ($operator['email'] ?? 'sistema@local'))),
        ]);
    }

    $pdo->commit();

    $meta = priority_meta((string) $priority['chave']);

    echo json_encode([
        'ok' => true,
        'message' => 'Prioridade atualizada para ' . $priority['nome'] . '.',
        'briefing_id' => $briefingId,
        'priority' => [
            'key' => (string) $priority['chave'],
            'label' => (string) $priority['nome'],
            'tone' => (string) ($meta['tone'] ?? 'neutral'),
        ],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    if ($pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    briefing_priority_respond(500, [
        'ok' => false,
        'message' => 'Nao foi possivel atualizar a prioridade agora.',
    ]);
}

function briefing_priority_nullable($value): ?string
{
    $value = trim((string) $value);
    return $value === '' ? null : $value;
}

function briefing_priority_respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}