<?php

require __DIR__ . '/../bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    briefing_status_respond(405, [
        'ok' => false,
        'message' => 'Metodo nao permitido.',
    ]);
}

if (!is_operator_admin()) {
    briefing_status_respond(403, [
        'ok' => false,
        'message' => 'Apenas administradores podem alterar o status da solicitacao.',
    ]);
}

$pdo = db();

if (!$pdo instanceof PDO) {
    briefing_status_respond(503, [
        'ok' => false,
        'message' => 'Banco indisponivel no momento.',
    ]);
}

$briefingId = (int) ($_POST['briefing_id'] ?? 0);
$statusKey = strtolower(trim((string) ($_POST['status'] ?? '')));

if ($briefingId <= 0 || $statusKey === '') {
    briefing_status_respond(422, [
        'ok' => false,
        'message' => 'Dados invalidos para atualizar o status.',
    ]);
}

try {
    $statusStatement = $pdo->prepare(
        'SELECT id, chave, nome, cor
         FROM status_solicitacoes
         WHERE chave = :chave AND ativo = 1
         LIMIT 1'
    );
    $statusStatement->execute(['chave' => $statusKey]);
    $status = $statusStatement->fetch();

    if (!$status) {
        briefing_status_respond(422, [
            'ok' => false,
            'message' => 'Status da solicitacao invalido.',
        ]);
    }

    $briefingStatement = $pdo->prepare(
        'SELECT
            b.id,
            b.codigo,
            b.status_solicitacao_id,
            ss.chave AS status_solicitacao_chave,
            ss.nome AS status_solicitacao_nome
         FROM briefings b
         LEFT JOIN status_solicitacoes ss ON ss.id = b.status_solicitacao_id
         WHERE b.id = :id
         LIMIT 1'
    );
    $briefingStatement->execute(['id' => $briefingId]);
    $briefing = $briefingStatement->fetch();

    if (!$briefing) {
        briefing_status_respond(404, [
            'ok' => false,
            'message' => 'Briefing nao encontrado.',
        ]);
    }

    $previousStatusKey = (string) ($briefing['status_solicitacao_chave'] ?? '');
    $previousStatusName = (string) ($briefing['status_solicitacao_nome'] ?? '');
    $statusId = (int) $status['id'];

    $pdo->beginTransaction();

    $updateStatement = $pdo->prepare(
        'UPDATE briefings
         SET status_solicitacao_id = :status_id
         WHERE id = :id
         LIMIT 1'
    );
    $updateStatement->execute([
        'status_id' => $statusId,
        'id' => $briefingId,
    ]);

    if ((int) ($briefing['status_solicitacao_id'] ?? 0) !== $statusId) {
        $operator = current_operator() ?: [];
        $movementStatement = $pdo->prepare(
            'INSERT INTO briefing_movimentacoes (
                briefing_id,
                tipo_movimento,
                comentario_interno,
                comentario_visivel,
                dados_adicionais,
                nome_autor,
                email_autor
            ) VALUES (
                :briefing_id,
                "status_solicitacao",
                :comentario_interno,
                :comentario_visivel,
                :dados_adicionais,
                :nome_autor,
                :email_autor
            )'
        );
        $movementStatement->execute([
            'briefing_id' => $briefingId,
            'comentario_interno' => 'Status operacional atualizado pelo administrador.',
            'comentario_visivel' => 'Status da solicitacao atualizado para ' . $status['nome'] . '.',
            'dados_adicionais' => json_encode([
                'status_anterior' => [
                    'chave' => $previousStatusKey,
                    'nome' => $previousStatusName,
                ],
                'status_novo' => [
                    'chave' => $status['chave'],
                    'nome' => $status['nome'],
                ],
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'nome_autor' => briefing_status_nullable($operator['nome'] ?? ''),
            'email_autor' => strtolower(trim((string) ($operator['email'] ?? 'sistema@local'))),
        ]);
    }

    $pdo->commit();

    $meta = solicitation_status_meta((string) $status['chave']);
    $meta['label'] = (string) $status['nome'];
    $meta['nome'] = (string) $status['nome'];
    $meta['color'] = (string) $status['cor'];
    $meta['cor'] = (string) $status['cor'];

    echo json_encode([
        'ok' => true,
        'message' => 'Status atualizado para ' . $status['nome'] . '.',
        'briefing_id' => $briefingId,
        'status' => $meta,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    if ($pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    briefing_status_respond(500, [
        'ok' => false,
        'message' => 'Nao foi possivel atualizar o status agora.',
    ]);
}

function briefing_status_nullable($value): ?string
{
    $value = trim((string) $value);
    return $value === '' ? null : $value;
}

function briefing_status_respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}