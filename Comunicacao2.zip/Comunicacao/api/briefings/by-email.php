<?php

require __DIR__ . '/../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'ok' => false,
        'message' => 'Método não permitido.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$email = trim((string) ($_POST['email'] ?? ''));

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode([
        'ok' => false,
        'message' => 'Informe um e-mail válido para continuar.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$pdo = db();

if (!$pdo instanceof PDO) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Não foi possível conectar ao banco de dados.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$normalizedEmail = strtolower($email);
$currentRequester = current_requester();
$currentRequesterEmail = strtolower(trim((string) ($currentRequester['email'] ?? '')));
$isLookupOwner = $currentRequesterEmail !== '' && $currentRequesterEmail === $normalizedEmail;
$isAnalyst = operator_has_role(['analista']);
$isAdmin = is_operator_admin();

try {
    $lookupName = null;

    $nameStatement = $pdo->prepare(
        'SELECT nome
         FROM usuarios_informados
         WHERE email = :email
            OR LOWER(email) = :email_lower
         LIMIT 1'
    );
    $nameStatement->execute([
        'email' => $normalizedEmail,
        'email_lower' => $normalizedEmail,
    ]);
    $storedUser = $nameStatement->fetch();

    if ($storedUser && !empty($storedUser['nome'])) {
        $lookupName = $storedUser['nome'];
    }

    if ($lookupName === null) {
        $fallbackNameStatement = $pdo->prepare(
            'SELECT nome_solicitante
             FROM briefings
             WHERE (
                    email_solicitante = :email
                    OR LOWER(email_solicitante) = :email_lower
                )
               AND nome_solicitante IS NOT NULL
               AND nome_solicitante <> ""
             ORDER BY atualizado_em DESC, id DESC
             LIMIT 1'
        );
        $fallbackNameStatement->execute([
            'email' => $normalizedEmail,
            'email_lower' => $normalizedEmail,
        ]);
        $fallbackUser = $fallbackNameStatement->fetch();

        if ($fallbackUser && !empty($fallbackUser['nome_solicitante'])) {
            $lookupName = $fallbackUser['nome_solicitante'];
        }
    }

    $briefingStatement = $pdo->prepare(
        'SELECT
            b.id,
            b.codigo,
            b.titulo,
            COALESCE(NULLIF(b.produto_tema, ""), b.titulo) AS tema,
            COALESCE(NULLIF(b.origem, ""), "solicitante") AS origem,
            COALESCE(b.data_publicacao, b.data_desejada_publicacao) AS data_publicacao_base,
            b.prazo_limite,
            COALESCE(NULLIF(b.responsavel_atual_nome, ""), "A definir") AS atendimento,
            cs.chave AS status_chave,
            cs.nome AS status_nome,
            cs.cor AS status_cor,
            ss.chave AS status_solicitacao_chave,
            ss.nome AS status_solicitacao_nome,
            ss.cor AS status_solicitacao_cor,
            (
                SELECT GROUP_CONCAT(cc.nome ORDER BY bc.ordem, bc.id SEPARATOR ", ")
                FROM briefing_canais bc
                INNER JOIN canais_comunicacao cc ON cc.id = bc.canal_id
                WHERE bc.briefing_id = b.id
            ) AS canais
         FROM briefings b
         LEFT JOIN configuracoes_status cs ON cs.id = b.status_id
         LEFT JOIN status_solicitacoes ss ON ss.id = b.status_solicitacao_id
         WHERE b.email_solicitante = :email
            OR LOWER(b.email_solicitante) = :email_lower
         ORDER BY
            COALESCE(b.data_publicacao, b.data_desejada_publicacao, DATE(b.criado_em)) DESC,
            b.id DESC'
    );
    $briefingStatement->execute([
        'email' => $normalizedEmail,
        'email_lower' => $normalizedEmail,
    ]);
    $briefings = $briefingStatement->fetchAll();

    $payload = array_map(static function (array $briefing) use ($normalizedEmail, $isLookupOwner, $isAnalyst, $isAdmin) {
        $status = solicitation_status_from_record($briefing);
        $statusKey = strtolower(trim((string) ($status['key'] ?: 'aberto')));
        $origin = strtolower(trim((string) ($briefing['origem'] ?? '')));
        $isGradeRequest = in_array($origin, ['solicitacao_grade', 'solicitacao-grade'], true);
        $canEdit = $isAdmin || ($statusKey === 'aberto' && ($isLookupOwner || $isAnalyst));

        return [
            'id' => (int) $briefing['id'],
            'codigo' => $briefing['codigo'],
            'titulo' => $briefing['titulo'],
            'tema' => $briefing['tema'],
            'origem' => $origin,
            'tipo_pedido' => [
                'key' => $isGradeRequest ? 'solicitacao_grade' : 'briefing',
                'label' => $isGradeRequest ? 'Solicitação de grade' : 'Briefing',
            ],
            'data_publicacao' => format_date_br($briefing['data_publicacao_base']),
            'prazo_limite' => format_date_br($briefing['prazo_limite'], true),
            'atendimento' => $briefing['atendimento'],
            'canais' => $briefing['canais'] ?: '',
            'status' => [
                'key' => $statusKey,
                'nome' => $status['label'] ?: 'Aberto',
                'cor' => $status['color'] ?: '#0EA5E9',
            ],
            'can_edit' => $canEdit,
            'edit_label' => (($briefing['status_chave'] ?? '') === 'rascunho') ? 'Continuar rascunho' : 'Editar pedido',
            'edit_url' => $canEdit
                ? route_url('novo-briefing', [
                    'briefing_id' => (int) $briefing['id'],
                    'email' => $normalizedEmail,
                    'return_url' => route_url('acompanhar-pedidos'),
                ])
                : null,
        ];
    }, $briefings);

    echo json_encode([
        'ok' => true,
        'email' => $normalizedEmail,
        'nome' => $lookupName,
        'total' => count($payload),
        'pedidos' => $payload,
        'briefings' => $payload,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $throwable) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Não foi possível consultar seus pedidos agora.',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
