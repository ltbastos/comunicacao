<?php

require __DIR__ . '/bootstrap.php';

$status = database_status();

echo json_encode([
    'application' => app_config('name'),
    'database' => $status,
    'server_time' => date('c'),
    'version' => '0.1.0',
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
