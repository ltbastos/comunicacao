# Central de Comunicacao

Ferramenta interna para o time de Comunicacao, pensada para rodar em ambiente XAMPP com PHP, MySQL/MariaDB, HTML, CSS e JavaScript puro.

## Estrutura

- `index.php`: front controller simples com roteamento por `?page=...`
- `app/pages`: telas principais do sistema
- `assets/css`: design system e estilos globais
- `assets/js`: interacoes do frontend
- `config`: configuracoes da aplicacao, banco e mock inicial
- `database`: SQL completo de criacao do banco e seeds iniciais
- `includes`: bootstrap, helpers e layout compartilhado
- `api`: ponto de partida para endpoints AJAX

## Como rodar

1. Copie a pasta para `htdocs/Comunicacao`
2. Importe [`database/comunicacao.sql`](/c:/xampp/htdocs/Comunicacao/database/comunicacao.sql) no MySQL/MariaDB
3. Ajuste [`config/database.php`](/c:/xampp/htdocs/Comunicacao/config/database.php) conforme o ambiente
4. Acesse `http://localhost/Comunicacao`

## Observacao

Esta primeira entrega inclui:

- arquitetura inicial enxuta
- modelagem relacional preparada para evolucao
- casca visual premium com cinco areas principais
- componentes reutilizaveis
- base JS para wizard, filtros visuais, identidade local e charts
- endpoint de healthcheck para futura integracao AJAX
