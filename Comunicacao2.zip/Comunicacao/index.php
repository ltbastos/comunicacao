<?php

require __DIR__ . '/includes/bootstrap.php';

$page = current_page();
$pageMeta = page_meta($page);
$viewFile = __DIR__ . '/app/pages/' . $page . '.php';

if (!is_file($viewFile)) {
    $page = 'not-found';
    $pageMeta = page_meta($page);
    $viewFile = __DIR__ . '/app/pages/not-found.php';
}

ensure_page_access($page);

require __DIR__ . '/includes/layout.php';
