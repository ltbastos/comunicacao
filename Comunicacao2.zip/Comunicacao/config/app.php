<?php

return [
    'name' => 'Comunicação 360',
    'tagline' => 'Workflow premium para briefings, grade editorial e operação do time de Comunicação.',
    'timezone' => 'America/Sao_Paulo',
    'navigation' => [
        ['key' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'bi-grid-1x2'],
        ['key' => 'gestao-membros', 'label' => 'Membros do Time', 'icon' => 'bi-people', 'roles' => ['adm']],
        ['key' => 'planejamento', 'label' => 'Planejamento da Grade', 'icon' => 'bi-calendar3'],
        ['key' => 'meus-briefings', 'label' => 'Meus Briefings', 'icon' => 'bi-journal-richtext'],
        ['key' => 'operacao', 'label' => 'Operacao da Comunicacao', 'icon' => 'bi-kanban'],
        ['key' => 'historico', 'label' => 'Consulta e Historico', 'icon' => 'bi-search'],
    ],
    'pages' => [
        'home' => [
            'title' => 'Comunicação 360',
            'eyebrow' => 'Entrada principal',
            'description' => 'Escolha por onde deseja começar.',
            'layout' => 'immersive',
        ],
        'envio-briefing' => [
            'title' => 'Acompanhe Seus Pedidos',
            'eyebrow' => 'Próxima etapa',
            'description' => 'Consulte briefings e solicitacoes de grade usando o usuario ativo da sessao.',
            'layout' => 'immersive',
        ],
        'solicitacao-grade' => [
            'title' => 'Solicitação de Grade',
            'eyebrow' => 'Planejamento da grade',
            'description' => 'Fluxo em etapas para configurar o ciclo, receber solicitações, analisar demandas e fechar a grade final.',
            'layout' => 'immersive',
        ],
        'encaixe' => [
            'title' => 'Solicitação de Encaixe',
            'eyebrow' => 'Próxima etapa',
            'description' => 'Fluxo em construção a partir da nova home.',
            'layout' => 'immersive',
        ],
        'acompanhar-pedidos' => [
            'title' => 'Acompanhe Seus Pedidos',
            'eyebrow' => 'Acompanhamento',
            'description' => 'Consulte briefings e solicitacoes de grade usando o usuario ativo da sessao.',
            'layout' => 'immersive',
        ],
        'novo-briefing' => [
            'title' => 'Novo Briefing',
            'eyebrow' => 'Formulário guiado',
            'description' => 'Monte seu briefing em etapas.',
            'layout' => 'immersive',
        ],
        'dashboard' => [
            'title' => 'Dashboard de Briefings',
            'eyebrow' => 'Painel de briefings',
            'description' => 'Volume, status, prazos e distribuicao dos briefings em um unico painel.',
            'layout' => 'immersive',
            'roles' => ['adm', 'analista'],
            'actions' => [
                ['label' => 'Gerir membros', 'icon' => 'bi-people', 'href' => 'index.php?page=gestao-membros', 'variant' => 'secondary', 'roles' => ['adm']],
                ['label' => 'Ver historico', 'icon' => 'bi-search', 'href' => 'index.php?page=historico', 'variant' => 'primary'],
                ['label' => 'Novo briefing', 'icon' => 'bi-plus-circle', 'href' => 'index.php?page=meus-briefings#novo-briefing', 'variant' => 'secondary'],
            ],
        ],
        'gestao-membros' => [
            'title' => 'Membros do Time de Comunicacao',
            'eyebrow' => 'Controle de acesso',
            'description' => 'Inclua e remova membros internos com perfil de adm ou analista.',
            'roles' => ['adm'],
        ],
        'planejamento' => [
            'title' => 'Planejamento da Grade',
            'eyebrow' => 'Agenda editorial',
            'description' => 'Visao mensal da grade com capacidade, itens criticos e distribuicao por canal.',
            'roles' => ['adm', 'analista'],
            'actions' => [
                ['label' => 'Próximas datas livres', 'icon' => 'bi-calendar-check', 'href' => '#grade-availability', 'variant' => 'primary'],
            ],
        ],
        'planejamento-dia' => [
            'title' => 'Detalhe da Grade do Dia',
            'eyebrow' => 'Agenda do dia',
            'description' => 'Leitura hora a hora dos eventos programados para a data escolhida.',
            'roles' => ['adm', 'analista'],
        ],
        'meus-briefings' => [
            'title' => 'Meus Briefings',
            'eyebrow' => 'Solicitante',
            'description' => 'Acompanhe demandas e abra novos briefings com o usuário ativo na sessão atual.',
            'actions' => [
                ['label' => 'Iniciar novo briefing', 'icon' => 'bi-stars', 'href' => '#novo-briefing', 'variant' => 'primary'],
            ],
        ],
        'operacao' => [
            'title' => 'Operacao da Comunicacao',
            'eyebrow' => 'Esteira operacional',
            'description' => 'Tabela operacional, pipeline visual, historico e acompanhamento por responsavel.',
            'actions' => [
                ['label' => 'Atualizar status', 'icon' => 'bi-arrow-repeat', 'href' => '#operacao-tabela', 'variant' => 'primary'],
            ],
        ],
        'historico' => [
            'title' => 'Consulta e Historico',
            'eyebrow' => 'Auditoria funcional',
            'description' => 'Busca avancada com filtros cruzados, visao detalhada e base pronta para exportacao futura.',
            'actions' => [
                ['label' => 'Buscar registros', 'icon' => 'bi-funnel', 'href' => '#filtros-historico', 'variant' => 'primary'],
            ],
        ],
        'not-found' => [
            'title' => 'Pagina nao encontrada',
            'eyebrow' => 'Navegacao',
            'description' => 'A rota solicitada nao existe nesta versao inicial da ferramenta.',
            'actions' => [
                ['label' => 'Voltar ao inicio', 'icon' => 'bi-house', 'href' => 'index.php?page=home', 'variant' => 'primary'],
            ],
        ],
    ],
];
