<?php

return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'database' => 'comunicacao_hub',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
