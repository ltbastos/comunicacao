<?php
require __DIR__ . '/_direct-access.php';
?>

<section class="surface-card empty-state-page">
    <i class="bi bi-compass"></i>
    <span class="eyebrow">Rota invalida</span>
    <h2>Pagina nao encontrada</h2>
    <p>Use a navegacao lateral para voltar a uma das areas principais da ferramenta.</p>
    <a class="action-button primary" href="<?php echo safe(route_url('dashboard')); ?>">
        <i class="bi bi-house"></i>
        <span>Voltar ao dashboard</span>
    </a>
</section>
