<?php
require __DIR__ . '/_direct-access.php';
?>

<section class="surface-card">
    <div class="section-heading">
        <div>
            <span class="eyebrow">Dashboard</span>
            <h3>Dashboard zerado</h3>
        </div>
    </div>

    <div class="empty-state">
        <i class="bi bi-layout-text-window-reverse"></i>
        <p>Base limpa para redesenhar o painel.</p>
    </div>
</section>