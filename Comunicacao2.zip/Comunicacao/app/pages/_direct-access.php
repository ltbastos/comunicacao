<?php

if (function_exists('route_url')) {
    return;
}

$page = basename($_SERVER['SCRIPT_FILENAME'] ?? __FILE__, '.php');
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$projectBase = str_replace('\\', '/', dirname(dirname(dirname($scriptName))));
$projectBase = $projectBase === '/' || $projectBase === '.' ? '' : rtrim($projectBase, '/');

if ($page === 'home') {
    header('Location: ' . $projectBase . '/index.php');
    exit;
}

header('Location: ' . $projectBase . '/index.php?page=' . rawurlencode($page));
exit;
