<?php
require __DIR__ . '/_direct-access.php';

$pdo = db();
$currentOperator = current_operator();
$feedback = null;
$formValues = [
    'nome' => '',
    'email' => '',
    'role' => 'analista',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim((string) ($_POST['member_action'] ?? 'save'));
    $formValues = [
        'nome' => trim((string) ($_POST['nome'] ?? '')),
        'email' => strtolower(trim((string) ($_POST['email'] ?? ''))),
        'role' => trim((string) ($_POST['role'] ?? 'analista')),
    ];

    if (!$pdo instanceof PDO) {
        $feedback = [
            'tone' => 'danger',
            'label' => 'Banco indisponível',
            'message' => 'Não foi possível atualizar os membros sem conexão com o banco.',
        ];
    } elseif ($action === 'remove') {
        $memberId = (int) ($_POST['member_id'] ?? 0);

        if ($memberId <= 0) {
            $feedback = [
                'tone' => 'warning',
                'label' => 'Seleção inválida',
                'message' => 'Escolha um membro válido para remover.',
            ];
        } else {
            $statement = $pdo->prepare('SELECT id, nome, email FROM usuarios_informados WHERE id = :id LIMIT 1');
            $statement->execute(['id' => $memberId]);
            $member = $statement->fetch();

            if (!$member) {
                $feedback = [
                    'tone' => 'warning',
                    'label' => 'Membro não encontrado',
                    'message' => 'O registro selecionado não está mais disponível.',
                ];
            } elseif (strtolower((string) ($member['email'] ?? '')) === strtolower((string) ($currentOperator['email'] ?? ''))) {
                $feedback = [
                    'tone' => 'warning',
                    'label' => 'Ação bloqueada',
                    'message' => 'Você não pode remover o próprio acesso enquanto estiver logado.',
                ];
            } else {
                $statement = $pdo->prepare('UPDATE usuarios_informados SET ativo = 0 WHERE id = :id LIMIT 1');
                $statement->execute(['id' => $memberId]);

                $feedback = [
                    'tone' => 'success',
                    'label' => 'Membro removido',
                    'message' => sprintf('%s foi retirado da lista interna.', trim((string) ($member['nome'] ?? 'O membro'))),
                ];
            }
        }
    } else {
        if ($formValues['nome'] === '') {
            $feedback = [
                'tone' => 'warning',
                'label' => 'Nome obrigatório',
                'message' => 'Informe o nome do membro que será incluído.',
            ];
        } elseif (!filter_var($formValues['email'], FILTER_VALIDATE_EMAIL)) {
            $feedback = [
                'tone' => 'warning',
                'label' => 'E-mail inválido',
                'message' => 'Use um e-mail válido para incluir o membro.',
            ];
        } elseif (!in_array($formValues['role'], ['adm', 'analista'], true)) {
            $feedback = [
                'tone' => 'warning',
                'label' => 'Perfil inválido',
                'message' => 'Escolha entre adm e analista.',
            ];
        } elseif ($formValues['email'] === strtolower((string) ($currentOperator['email'] ?? '')) && $formValues['role'] !== 'adm') {
            $feedback = [
                'tone' => 'warning',
                'label' => 'Ação bloqueada',
                'message' => 'Seu próprio acesso precisa permanecer como adm.',
            ];
        } else {
            $statement = $pdo->prepare(
                'INSERT INTO usuarios_informados (nome, email, role, ativo)
                 VALUES (:nome, :email, :role, 1)
                 ON DUPLICATE KEY UPDATE
                    nome = VALUES(nome),
                    role = VALUES(role),
                    ativo = VALUES(ativo)'
            );
            $statement->execute($formValues);

            $feedback = [
                'tone' => 'success',
                'label' => 'Lista atualizada',
                'message' => sprintf('%s agora está habilitado como %s.', $formValues['nome'], $formValues['role']),
            ];
            $formValues = [
                'nome' => '',
                'email' => '',
                'role' => 'analista',
            ];
        }
    }
}

$members = [];

if ($pdo instanceof PDO) {
    $statement = $pdo->query(
        'SELECT id, nome, email, role, criado_em, atualizado_em
         FROM usuarios_informados
         WHERE ativo = 1
           AND role IN ("adm", "analista")
         ORDER BY CASE role WHEN "adm" THEN 0 ELSE 1 END, nome, email'
    );
    $members = $statement->fetchAll();
}

$memberCount = count($members);
$adminCount = 0;
$analystCount = 0;

foreach ($members as $member) {
    if (($member['role'] ?? '') === 'adm') {
        $adminCount++;
    } elseif (($member['role'] ?? '') === 'analista') {
        $analystCount++;
    }
}
?>

<section class="section-stack">
    <div class="planner-overview member-overview">
        <article class="surface-card planner-highlight">
            <span class="eyebrow">Acesso interno</span>
            <h2>Time de Comunicação</h2>
            <p>Somente o perfil adm pode incluir ou remover quem enxerga dashboard, planejamento e demais telas internas.</p>
        </article>
        <article class="surface-card planner-stat"><strong><?php echo safe($memberCount); ?></strong><span>membros ativos</span></article>
        <article class="surface-card planner-stat"><strong><?php echo safe($adminCount); ?></strong><span>admins</span></article>
        <article class="surface-card planner-stat"><strong><?php echo safe($analystCount); ?></strong><span>analistas</span></article>
    </div>

    <?php if ($feedback): ?>
        <article class="surface-card member-feedback">
            <div class="section-heading">
                <div>
                    <span class="eyebrow">Atualização</span>
                    <h3>Lista do time</h3>
                </div>
                <span class="status-badge <?php echo safe(tone_class($feedback['tone'])); ?>"><?php echo safe($feedback['label']); ?></span>
            </div>
            <p><?php echo safe($feedback['message']); ?></p>
        </article>
    <?php endif; ?>
</section>

<section class="content-grid-two member-layout">
    <article class="surface-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Inclusão rápida</span>
                <h3>Adicionar ou reativar membro</h3>
            </div>
            <span class="meta-chip is-info">adm</span>
        </div>

        <form method="post" class="compact-form">
            <input type="hidden" name="member_action" value="save">

            <div class="form-grid two-columns">
                <label>
                    <span>Nome</span>
                    <input type="text" name="nome" value="<?php echo safe($formValues['nome']); ?>" placeholder="Ex.: Ana Martins" required>
                </label>

                <label>
                    <span>Role</span>
                    <select name="role" required>
                        <option value="adm" <?php echo $formValues['role'] === 'adm' ? 'selected' : ''; ?>>adm</option>
                        <option value="analista" <?php echo $formValues['role'] === 'analista' ? 'selected' : ''; ?>>analista</option>
                    </select>
                </label>
            </div>

            <label>
                <span>E-mail</span>
                <input type="email" name="email" value="<?php echo safe($formValues['email']); ?>" placeholder="nome@empresa.com.br" required>
            </label>

            <div class="info-banner">
                <i class="bi bi-shield-lock"></i>
                <div>
                    <strong>Regras atuais</strong>
                    <p>Analistas acessam o dashboard e o planejamento. O perfil adm também mantém a lista de membros.</p>
                </div>
            </div>

            <button class="action-button primary full" type="submit">
                <i class="bi bi-person-plus"></i>
                <span>Salvar membro</span>
            </button>
        </form>
    </article>

    <article class="surface-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Lista ativa</span>
                <h3>Membros habilitados</h3>
            </div>
            <span class="meta-chip is-neutral"><?php echo safe($memberCount); ?> acesso(s)</span>
        </div>

        <?php if (!$members): ?>
            <div class="info-banner">
                <i class="bi bi-people"></i>
                <div>
                    <strong>Nenhum membro ativo</strong>
                    <p>Inclua pelo menos um adm e um analista para liberar as telas internas.</p>
                </div>
            </div>
        <?php else: ?>
            <div class="stack-list">
                <?php foreach ($members as $member): ?>
                    <?php
                    $isCurrent = strtolower((string) ($member['email'] ?? '')) === strtolower((string) ($currentOperator['email'] ?? ''));
                    $roleTone = ($member['role'] ?? '') === 'adm' ? 'primary' : 'accent';
                    ?>
                    <article class="list-row member-row">
                        <div class="member-row__copy">
                            <strong><?php echo safe($member['nome'] ?: 'Sem nome'); ?></strong>
                            <p><?php echo safe($member['email']); ?></p>
                            <small>Atualizado em <?php echo safe(format_date_br($member['atualizado_em'] ?? null, true)); ?></small>
                        </div>

                        <div class="member-row__actions">
                            <span class="status-badge <?php echo safe(tone_class($roleTone)); ?>"><?php echo safe($member['role']); ?></span>
                            <?php if ($isCurrent): ?>
                                <span class="mini-badge is-info">Você</span>
                            <?php endif; ?>

                            <form method="post">
                                <input type="hidden" name="member_action" value="remove">
                                <input type="hidden" name="member_id" value="<?php echo safe($member['id']); ?>">
                                <button class="action-button ghost" type="submit" <?php echo $isCurrent ? 'disabled' : ''; ?>>
                                    <i class="bi bi-person-dash"></i>
                                    <span>Remover</span>
                                </button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </article>
</section>