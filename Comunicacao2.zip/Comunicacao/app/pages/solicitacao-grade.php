<?php
require __DIR__ . '/_direct-access.php';

$currentRequester = current_requester();
$currentOperator = current_operator();
$gradeRequester = $currentOperator ?: $currentRequester;
$gradeRequesterName = trim((string) ($gradeRequester['nome'] ?? ''));
$gradeRequesterEmail = strtolower(trim((string) ($gradeRequester['email'] ?? '')));
$gradeRequesterDisplayName = $gradeRequesterName !== '' ? $gradeRequesterName : $gradeRequesterEmail;

$channelLimits = [];

foreach (grade_channel_limit_rules() as $channelRule) {
    $channelLimits[] = [
        'name' => $channelRule['name'],
        'limit' => $channelRule['limit_label'],
    ];
}

$channelLimitMap = [];
foreach ($channelLimits as $channelLimit) {
    $channelLimitMap[$channelLimit['name']] = $channelLimit['limit'];
}

$todayDate = date('Y-m-d');
$currentMonth = date('Y-m');

$publicoOptions = [
    'Empresas',
    'Negócios',
    'Plataforma PJ',
    'Digital MEI',
    'BU Empresas e Negócios',
];

$classificacaoAssuntoOptions = [
    'Crédito',
    'Cash',
    'Base de clientes',
    'Seguros',
    'Investimentos',
    'Previdência',
    'Cartões',
    'Change',
    'Outros',
];

$areaResponsavelOptions = [
    'Comunicação PJ',
    'Produtos Empresas',
    'Negócios',
    'Plataforma PJ',
    'Digital MEI',
    'BU Empresas e Negócios',
];

$prioridadeOptions = [
    [
        'value' => 'muito-urgente',
        'label' => 'Muito urgente',
        'description' => 'Precisa acontecer imediatamente.',
        'tone' => 'critical',
    ],
    [
        'value' => 'urgente',
        'label' => 'Urgente',
        'description' => 'Importante realizar no curto prazo.',
        'tone' => 'warning',
    ],
    [
        'value' => 'importante',
        'label' => 'Importante',
        'description' => 'Relevante, mas pode ser planejado.',
        'tone' => 'attention',
    ],
    [
        'value' => 'informativo',
        'label' => 'Informativo',
        'description' => 'Mantém a grade atualizada sem urgência crítica.',
        'tone' => 'success',
    ],
];

$statusAnaliseOptions = [
    [
        'value' => 'aprovada',
        'label' => 'Aprovar para grade',
        'description' => 'Segue direto para a montagem final.',
    ],
    [
        'value' => 'ajustar',
        'label' => 'Ajustar informações',
        'description' => 'Refina data, canal ou contexto antes do fechamento.',
    ],
    [
        'value' => 'reorganizar',
        'label' => 'Reorganizar na grade',
        'description' => 'Redistribui a demanda conforme a capacidade do canal.',
    ],
];

$gradePeriodOptions = [];
$gradeCapacityMap = [];
$defaultGradePeriod = grade_fetch_period_record(0);
$pdoForPeriods = db();

if ($pdoForPeriods instanceof PDO) {
    try {
        $periodOptionsStatement = $pdoForPeriods->query(
            'SELECT id, nome, ano, mes, data_inicio, data_fim, status
             FROM periodos_grade
             WHERE status <> "cancelado"
             ORDER BY data_inicio DESC, id DESC
             LIMIT 40'
        );

        foreach ($periodOptionsStatement->fetchAll() as $periodOption) {
            $gradePeriodOptions[] = grade_map_period_record($periodOption);
        }

        $capacityStatement = $pdoForPeriods->query(
            'SELECT
                ge.periodo_id,
                cc.nome AS canal_nome,
                ge.data_prevista_publicacao,
                COALESCE(SUM(ge.capacidade_slot), 0) AS slots_usados
             FROM grade_editorial ge
             INNER JOIN canais_comunicacao cc ON cc.id = ge.canal_id
             INNER JOIN periodos_grade pg ON pg.id = ge.periodo_id
             WHERE pg.status <> "cancelado"
               AND ge.status <> "cancelado"
             GROUP BY ge.periodo_id, cc.nome, ge.data_prevista_publicacao'
        );

        foreach ($capacityStatement->fetchAll() as $capacityRow) {
            $periodIdKey = (string) ((int) ($capacityRow['periodo_id'] ?? 0));
            $channelKey = (string) ($capacityRow['canal_nome'] ?? '');
            $dateKey = (string) ($capacityRow['data_prevista_publicacao'] ?? '');

            if ($periodIdKey === '0' || $channelKey === '' || $dateKey === '') {
                continue;
            }

            $gradeCapacityMap[$periodIdKey][$channelKey][$dateKey] = (int) ($capacityRow['slots_usados'] ?? 0);
        }
    } catch (Throwable $throwable) {
        $gradePeriodOptions = [];
        $gradeCapacityMap = [];
    }
}

if (is_operator_admin()) {
    $pdo = db();
    $requestedPeriodId = (int) ($_GET['periodo_id'] ?? 0);
    $defaultOpenPeriod = null;
    $solicitationStatusOptions = array_values(solicitation_status_catalog());
    $briefingPriorityOptions = [];

    foreach ($gradePeriodOptions as $gradePeriodOption) {
        if (!grade_period_is_closed($gradePeriodOption)) {
            $defaultOpenPeriod = $gradePeriodOption;
            break;
        }
    }

    $period = $requestedPeriodId > 0
        ? grade_fetch_period_record($requestedPeriodId)
        : ($defaultOpenPeriod ?: grade_fetch_period_record(0));
    $gradeItems = $period ? grade_fetch_editorial_items_for_period($period['id']) : [];
    $periodClosed = $period ? grade_period_is_closed($period) : false;
    $calendarLocked = $period ? ($periodClosed && !is_operator_admin()) : true;
    $gradePeriods = $gradePeriodOptions;
    $pendingBriefings = [];

    if ($pdo instanceof PDO) {
        try {
            $pendingStatement = $pdo->query(
                'SELECT
                    b.id,
                    b.codigo,
                    b.titulo,
                    COALESCE(NULLIF(b.tipo_demanda, ""), "Encaixe") AS tipo_demanda,
                    COALESCE(NULLIF(b.produto_tema, ""), b.titulo) AS tema,
                    COALESCE(NULLIF(b.origem, ""), "solicitante") AS origem,
                    b.data_desejada_publicacao,
                    b.email_solicitante,
                    COALESCE(NULLIF(a.nome, ""), "A definir") AS area_nome,
                    COALESCE(cs.chave, "") AS status_chave,
                    COALESCE(cs.nome, "Sem status") AS status_nome,
                    ss.chave AS status_solicitacao_chave,
                    ss.nome AS status_solicitacao_nome,
                    ss.cor AS status_solicitacao_cor,
                    COALESCE(p.chave, "media") AS prioridade_chave,
                    COALESCE(p.nome, "Media") AS prioridade_nome,
                    COALESCE(
                        (
                            SELECT cc.nome
                            FROM briefing_canais bc
                            INNER JOIN canais_comunicacao cc ON cc.id = bc.canal_id
                            WHERE bc.briefing_id = b.id
                            ORDER BY bc.ordem, bc.id
                            LIMIT 1
                        ),
                        NULLIF(cc_principal.nome, ""),
                        "Canal nao informado"
                    ) AS canal_nome,
                    COALESCE(
                        (
                            SELECT cc.cor_badge
                            FROM briefing_canais bc
                            INNER JOIN canais_comunicacao cc ON cc.id = bc.canal_id
                            WHERE bc.briefing_id = b.id
                            ORDER BY bc.ordem, bc.id
                            LIMIT 1
                        ),
                        NULLIF(cc_principal.cor_badge, ""),
                        "#1E5B8F"
                    ) AS canal_cor
                 FROM briefings b
                 LEFT JOIN areas_solicitantes a ON a.id = b.area_id
                 LEFT JOIN configuracoes_status cs ON cs.id = b.status_id
                 LEFT JOIN status_solicitacoes ss ON ss.id = b.status_solicitacao_id
                 LEFT JOIN prioridades p ON p.id = b.prioridade_id
                 LEFT JOIN canais_comunicacao cc_principal ON cc_principal.id = b.canal_id
                 WHERE b.grade_id IS NULL
                   AND COALESCE(cs.chave, "") NOT IN ("rascunho", "cancelado", "publicado")
                 ORDER BY COALESCE(b.data_desejada_publicacao, DATE(b.criado_em)), b.id
                 LIMIT 80'
            );
            $pendingBriefings = $pendingStatement->fetchAll();

            $priorityStatement = $pdo->query(
                'SELECT id, chave, nome
                 FROM prioridades
                 WHERE ativo = 1
                 ORDER BY ordem, id'
            );

            foreach ($priorityStatement->fetchAll() as $priorityOption) {
                $priorityMeta = priority_meta($priorityOption['chave'] ?? 'media');
                $briefingPriorityOptions[] = [
                    'key' => (string) ($priorityOption['chave'] ?? ''),
                    'label' => (string) ($priorityOption['nome'] ?? ''),
                    'tone' => (string) ($priorityMeta['tone'] ?? 'neutral'),
                ];
            }
        } catch (Throwable $throwable) {
            $pendingBriefings = [];
            $briefingPriorityOptions = [];
        }
    }

    if (!$briefingPriorityOptions) {
        $briefingPriorityOptions = [
            ['key' => 'baixa', 'label' => 'Baixa', 'tone' => 'neutral'],
            ['key' => 'media', 'label' => 'Media', 'tone' => 'info'],
            ['key' => 'alta', 'label' => 'Alta', 'tone' => 'warning'],
            ['key' => 'critica', 'label' => 'Critica', 'tone' => 'danger'],
        ];
    }

    $channelRules = [];
    foreach (grade_channel_limit_rules() as $ruleName => $rule) {
        $channelRules[$ruleName] = [
            'limit' => (int) ($rule['limit'] ?? 1),
            'limit_label' => (string) ($rule['limit_label'] ?? '1 por dia'),
        ];
    }

    $gradeReturnUrl = route_url('solicitacao-grade', $period ? ['periodo_id' => (int) $period['id']] : []);
    $calendarEvents = [];
    foreach ($gradeItems as $index => $item) {
        $itemId = isset($item['id']) ? (string) $item['id'] : 'mock-' . $index;
        $status = status_meta($item['status'] ?? 'planejado');
        $canMove = $period && !$calendarLocked && !$period['is_mock'] && is_numeric($itemId) && (int) $itemId > 0;
        $editUrl = trim((string) ($item['briefing_id'] ?? '')) !== '' ? route_url('novo-briefing', [
            'briefing_id' => (int) $item['briefing_id'],
            'email' => (string) ($item['briefing_email'] ?? ''),
            'return_url' => $gradeReturnUrl,
        ]) : '';

        $calendarEvents[] = [
            'id' => $itemId,
            'title' => trim((string) ($item['title'] ?? 'Sem titulo')),
            'start' => (string) ($item['date'] ?? ''),
            'allDay' => true,
            'editable' => $canMove,
            'url' => $editUrl,
            'backgroundColor' => trim((string) ($item['channel_color'] ?? '#1E5B8F')),
            'borderColor' => trim((string) ($item['channel_color'] ?? '#1E5B8F')),
            'textColor' => '#ffffff',
            'classNames' => ['planner-event', 'planner-event--' . ($status['tone'] ?? 'info')],
            'extendedProps' => [
                'area' => trim((string) ($item['area'] ?? 'A definir')),
                'channel' => trim((string) ($item['channel'] ?? 'Canal nao informado')),
                'statusLabel' => trim((string) ($status['label'] ?? 'Planejado')),
                'type' => trim((string) ($item['type'] ?? '')),
                'editUrl' => $editUrl,
                'capacityUnits' => max(1, (int) ($item['capacity_units'] ?? 1)),
                'slot' => max(1, (int) ($item['slot'] ?? 1)),
                'canMove' => $canMove,
            ],
        ];
    }

    $todayForCalendar = (new DateTimeImmutable('today'))->format('Y-m-d');
    $calendarStart = $period ? $period['data_inicio'] : $todayForCalendar;
    $calendarEnd = $period ? $period['data_fim'] : $todayForCalendar;
    ?>

<section
    class="briefing-wizard grade-request grade-admin-page"
    id="gradeAdminPage"
    data-period-id="<?php echo safe((string) ($period['id'] ?? 0)); ?>"
    data-period-status="<?php echo safe((string) ($period['status'] ?? '')); ?>"
    data-period-closed="<?php echo $periodClosed ? '1' : '0'; ?>"
    data-calendar-locked="<?php echo $calendarLocked ? '1' : '0'; ?>"
    data-period-start="<?php echo safe((string) ($period['data_inicio'] ?? $todayForCalendar)); ?>"
    data-period-end="<?php echo safe((string) ($period['data_fim'] ?? $todayForCalendar)); ?>"
    data-calendar-start="<?php echo safe($calendarStart); ?>"
    data-calendar-end="<?php echo safe($calendarEnd); ?>"
    data-schedule-url="<?php echo safe(base_url() . '/api/grade/schedule-briefing.php'); ?>"
    data-move-url="<?php echo safe(base_url() . '/api/grade/move-item.php'); ?>"
    data-remove-url="<?php echo safe(base_url() . '/api/grade/remove-item.php'); ?>"
    data-status-update-url="<?php echo safe(base_url() . '/api/briefings/update-status.php'); ?>"
    data-priority-update-url="<?php echo safe(base_url() . '/api/briefings/update-priority.php'); ?>"
    data-create-period-url="<?php echo safe(base_url() . '/api/grade/create-period.php'); ?>"
    data-update-period-url="<?php echo safe(base_url() . '/api/grade/update-period.php'); ?>"
    data-finalize-period-url="<?php echo safe(base_url() . '/api/grade/finalize-period.php'); ?>"
    data-period-name="<?php echo safe((string) ($period['label'] ?? '')); ?>"
    data-channel-rules="<?php echo safe(json_encode($channelRules, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?>"
    data-solicitation-statuses="<?php echo safe(json_encode($solicitationStatusOptions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?>"
    data-priority-options="<?php echo safe(json_encode($briefingPriorityOptions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?>"
>
    <div class="briefing-wizard__overlay"></div>

    <div class="briefing-wizard__inner grade-request__inner grade-admin__inner">
        <div class="immersive-toolbar">
            <a class="briefing-wizard__back" href="<?php echo safe(route_url('home')); ?>">
                <i class="bi bi-arrow-left"></i>
                <span>Voltar</span>
            </a>

            <div class="grade-admin__quick-actions">
                <button class="grade-admin__top-action" type="button" id="gradeAdminOpenCreateModal">
                    <i class="bi bi-calendar2-plus"></i>
                    <span>Criar grade</span>
                </button>

                <?php if ($gradePeriods): ?>
                    <label class="grade-admin__period-select grade-admin__period-select--compact">
                        <span class="sr-only">Selecionar grade existente</span>
                        <select id="gradeAdminPeriodSelect" aria-label="Selecionar grade existente">
                            <option value="">Selecionar grade</option>
                            <?php foreach ($gradePeriods as $gradePeriod): ?>
                                <option value="<?php echo safe(route_url('solicitacao-grade', ['periodo_id' => (int) $gradePeriod['id']])); ?>" <?php echo $period && (int) $period['id'] === (int) $gradePeriod['id'] ? 'selected' : ''; ?>>
                                    <?php echo safe($gradePeriod['nome'] . ' - ' . format_date_br($gradePeriod['data_inicio']) . ' a ' . format_date_br($gradePeriod['data_fim']) . ' - ' . ($gradePeriod['status_label'] ?? grade_status_label($gradePeriod['status'] ?? 'aberto'))); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <i class="bi bi-chevron-down" aria-hidden="true"></i>
                    </label>
                <?php endif; ?>
            </div>
        </div>

        <div class="briefing-wizard__hero grade-admin__hero">
            <span class="briefing-wizard__eyebrow">Montagem da grade</span>
            <h1>Calendario</h1>
            <p>Arraste pedidos para a data desejada, confira a capacidade por canal e use a dica de proximo dia util livre antes de encaixar.</p>
        </div>

        <div class="grade-admin__topline">
            <article class="grade-request__signal-card" data-tone="<?php echo $period ? ($periodClosed ? 'neutral' : 'success') : 'warning'; ?>">
                <span>Grade ativa</span>
                <strong><?php echo safe($period['label'] ?? 'Nenhuma grade'); ?></strong>
                <p><?php echo $period ? safe(format_date_br($period['data_inicio']) . ' a ' . format_date_br($period['data_fim'])) : 'Crie uma grade para liberar o calendario.'; ?></p>
                <?php if ($period): ?>
                    <div class="grade-admin__status-row">
                        <span>Status da grade</span>
                        <strong class="mini-badge <?php echo $periodClosed ? 'is-neutral' : 'is-info'; ?>"><?php echo safe($periodClosed ? 'Fechada' : 'Aberta'); ?></strong>
                    </div>

                <?php endif; ?>
            </article>

            <article class="grade-request__signal-card" data-tone="neutral">
                <span>Solicitacoes pendentes</span>
                <strong id="gradeAdminPendingCount"><?php echo safe((string) count($pendingBriefings)); ?></strong>
                <p>Briefings e solicitacoes de grade ainda fora do calendario.</p>
            </article>

            <article class="grade-request__signal-card" data-tone="neutral">
                <span>Itens no calendario</span>
                <strong id="gradeAdminScheduledCount"><?php echo safe((string) count($calendarEvents)); ?></strong>
                <p>Itens ja posicionados na grade selecionada.</p>
            </article>
        </div>

        <section class="grade-request__limits grade-admin__queue-card">
            <div class="grade-admin__queue-head">
                <div class="grade-admin__queue-copy">
                    <div class="grade-request__limits-head">
                        <strong>Solicitacoes</strong>
                        <p><?php echo !$period ? 'Crie ou selecione uma grade para liberar as solicitacoes.' : ($calendarLocked ? 'Esta grade esta fechada para edicao.' : 'Arraste uma solicitacao para o calendario. A ferramenta bloqueia datas que estouram o limite do canal.'); ?></p>
                    </div>

                    <div class="grade-admin__filters" role="group" aria-label="Filtrar solicitacoes da fila">
                        <button class="grade-admin__filter is-active" type="button" data-grade-origin-filter="all">Todos</button>
                        <button class="grade-admin__filter" type="button" data-grade-origin-filter="grade">Solicitacao de grade</button>
                        <button class="grade-admin__filter" type="button" data-grade-origin-filter="briefing">Briefings</button>
                    </div>
                </div>

                <article class="grade-request__signal-card grade-admin__hint-card" id="gradeAdminHintCard" data-tone="neutral">
                    <span>Dica de encaixe</span>
                    <strong id="gradeAdminHintTitle">Selecione um pedido</strong>
                    <p id="gradeAdminHintCopy">Clique em um pedido ou evento para ver o proximo dia util livre conforme a regra do canal.</p>
                </article>
            </div>

            <div class="grade-admin__request-list grade-admin__request-list--rail" id="gradeAdminRequestList">
                <?php if (!$pendingBriefings): ?>
                    <div class="grade-admin__empty">
                        <i class="bi bi-check2-circle"></i>
                        <strong>Nenhum pedido pendente</strong>
                        <span>Quando novos pedidos chegarem, eles aparecem aqui.</span>
                    </div>
                <?php else: ?>
                    <?php foreach ($pendingBriefings as $briefing): ?>
                        <?php $priority = priority_meta($briefing['prioridade_chave'] ?? 'media'); ?>
                        <?php $solicitationStatus = solicitation_status_from_record($briefing); ?>
                        <?php $solicitationStatusKey = (string) ($solicitationStatus['key'] ?? 'aberto'); ?>
                        <?php $requestOrigin = strtolower(trim((string) ($briefing['origem'] ?? 'solicitante'))); ?>
                        <?php $requestOriginCategory = $requestOrigin === 'solicitacao_grade' ? 'grade' : 'briefing'; ?>
                        <?php $requestOriginLabel = $requestOriginCategory === 'grade' ? 'Solicitacao de grade' : 'Briefing'; ?>
                        <?php $requestTitle = trim((string) ($briefing['tema'] ?: $briefing['titulo'])); ?>
                        <?php $requestAux = trim((string) ($briefing['canal_nome'] . ' - ' . $briefing['area_nome'])); ?>
                        <article
                            class="grade-admin__request <?php echo (!$period || $calendarLocked) ? 'is-locked' : ''; ?>"
                            draggable="<?php echo (!$period || $calendarLocked) ? 'false' : 'true'; ?>"
                            data-briefing-id="<?php echo safe($briefing['id']); ?>"
                            data-title="<?php echo safe($requestTitle); ?>"
                            data-channel="<?php echo safe($briefing['canal_nome']); ?>"
                            data-channel-color="<?php echo safe($briefing['canal_cor']); ?>"
                            data-area="<?php echo safe($briefing['area_nome']); ?>"
                            data-type="<?php echo safe($briefing['tipo_demanda']); ?>"
                            data-status-key="<?php echo safe($solicitationStatusKey); ?>"
                            data-status-label="<?php echo safe($solicitationStatus['label'] ?? 'Aberto'); ?>"
                            data-status-tone="<?php echo safe($solicitationStatus['tone'] ?? 'info'); ?>"
                            data-priority-key="<?php echo safe($briefing['prioridade_chave'] ?? 'media'); ?>"
                            data-origin-category="<?php echo safe($requestOriginCategory); ?>"
                            data-origin-label="<?php echo safe($requestOriginLabel); ?>"
                            data-edit-url="<?php echo safe(route_url('novo-briefing', ['briefing_id' => (int) $briefing['id'], 'email' => (string) $briefing['email_solicitante'], 'return_url' => $gradeReturnUrl])); ?>"
                            title="<?php echo safe($requestTitle); ?>"
                        >
                            <span class="grade-admin__request-code"><?php echo safe($briefing['codigo']); ?></span>
                            <strong title="<?php echo safe($requestTitle); ?>"><?php echo safe($requestTitle); ?></strong>
                            <p title="<?php echo safe($requestAux); ?>"><?php echo safe($briefing['canal_nome']); ?> &middot; <?php echo safe($briefing['area_nome']); ?></p>
                            <div class="grade-admin__request-meta">
                                <span class="mini-badge grade-admin__status-badge <?php echo safe(tone_class($solicitationStatus['tone'] ?? 'info')); ?>" data-request-status-badge title="<?php echo safe($solicitationStatus['label'] ?? 'Aberto'); ?>"><?php echo safe($solicitationStatus['label'] ?? 'Aberto'); ?></span>
                                <span class="mini-badge is-neutral" title="<?php echo safe($requestOriginLabel); ?>"><?php echo safe($requestOriginLabel); ?></span>
                                <span class="mini-badge <?php echo safe(tone_class($priority['tone'])); ?>" data-request-priority-badge title="<?php echo safe($priority['label']); ?>"><?php echo safe($priority['label']); ?></span>
                                <span><?php echo safe(format_date_br($briefing['data_desejada_publicacao'])); ?></span>
                            </div>
                        </article>
                    <?php endforeach; ?>
                    <div class="grade-admin__empty grade-admin__filter-empty is-hidden" id="gradeAdminFilterEmpty">
                        <i class="bi bi-funnel"></i>
                        <strong>Nenhuma solicitacao neste filtro</strong>
                        <span>Troque o filtro para ver os outros itens pendentes.</span>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <?php if (!$period): ?>
            <article class="grade-request__signal-card" data-tone="warning">
                <span>Calendario indisponivel</span>
                <strong>Crie uma grade para comecar</strong>
                <p>Assim que a grade for criada, os pedidos poderao ser arrastados para o calendario.</p>
            </article>
        <?php else: ?>
            <script type="application/json" id="gradeAdminEvents"><?php echo json_encode($calendarEvents, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?></script>

            <section class="grade-admin__layout">
                <article class="grade-request__limits grade-admin__calendar-card">
                    <div class="grade-admin__calendar-head">
                        <div class="grade-request__limits-head">
                            <strong>Calendario da grade</strong>
                            <p><?php echo $calendarLocked ? 'Grade fechada: os itens ficam disponiveis apenas para consulta.' : ($periodClosed ? 'Grade fechada: administradores ainda podem ajustar o calendario.' : 'Arraste os pedidos para uma data livre dentro da janela da grade.'); ?></p>
                        </div>

                        <div class="grade-admin__calendar-actions">
                            <button class="briefing-wizard__secondary" type="button" id="gradeAdminEditPeriod" <?php echo $calendarLocked ? 'disabled' : ''; ?>>
                                <i class="bi bi-pencil-square"></i>
                                <span>Editar grade</span>
                            </button>
                            <a class="briefing-wizard__secondary" href="<?php echo safe(base_url() . '/api/grade/export-calendar.php?periodo_id=' . (int) ($period['id'] ?? 0)); ?>" download>
                                <i class="bi bi-download"></i>
                                <span>Baixar</span>
                            </a>
                            <button class="briefing-wizard__secondary" type="button" id="gradeAdminFinalizePeriod" <?php echo $periodClosed ? 'disabled' : ''; ?>>
                                <i class="bi bi-lock"></i>
                                <span>Fechar grade</span>
                            </button>
                        </div>
                    </div>
                    <div id="gradeAdminCalendar" class="planning-calendar grade-admin__calendar"></div>
                </article>
            </section>
        <?php endif; ?>
    </div>

    <div class="grade-admin__modal" id="gradeAdminCreateModal" aria-hidden="true">
        <div class="grade-admin__modal-backdrop" data-grade-modal-close></div>
        <section class="grade-admin__modal-card" role="dialog" aria-modal="true" aria-labelledby="gradeAdminCreateTitle">
            <button class="grade-admin__modal-close" type="button" data-grade-modal-close aria-label="Fechar modal de criar grade">
                <i class="bi bi-x-lg"></i>
            </button>

            <div class="grade-admin__modal-head">
                <span>Nova grade</span>
                <h2 id="gradeAdminCreateTitle">Criar grade</h2>
            </div>

            <form class="grade-request__admin-form" id="gradeAdminPeriodForm">
                <div class="briefing-wizard__grid three-columns">
                    <label>
                        <span>Nome da grade</span>
                        <input type="text" name="nome" placeholder="Ex.: Grade Junho 2026" required>
                    </label>
                    <label>
                        <span>Data de inicio</span>
                        <input type="date" name="data_inicio" min="<?php echo safe($todayDate); ?>" required>
                    </label>
                    <label>
                        <span>Data de fim</span>
                        <input type="date" name="data_fim" min="<?php echo safe($todayDate); ?>" required>
                    </label>
                </div>

                <div class="grade-request__admin-actions grade-admin__modal-actions">
                    <button class="briefing-wizard__ghost" type="button" data-grade-modal-close>
                        <span>Cancelar</span>
                    </button>
                    <button class="briefing-entry__primary" type="submit" id="gradeAdminPeriodSubmit">
                        <span>Criar grade</span>
                        <i class="bi bi-calendar2-plus"></i>
                    </button>
                </div>
            </form>
        </section>
    </div>

    <div class="grade-admin__modal grade-admin__confirm-modal" id="gradeAdminFinalizeModal" aria-hidden="true">
        <div class="grade-admin__modal-backdrop" data-grade-finalize-close></div>
        <section class="grade-admin__modal-card grade-admin__confirm-card" role="dialog" aria-modal="true" aria-labelledby="gradeAdminFinalizeTitle">
            <button class="grade-admin__modal-close" type="button" data-grade-finalize-close aria-label="Fechar confirmação de fechamento">
                <i class="bi bi-x-lg"></i>
            </button>

            <div class="grade-admin__confirm-body">
                <span class="grade-admin__confirm-icon" aria-hidden="true">
                    <i class="bi bi-lock"></i>
                </span>
                <div>
                    <span>Fechar grade</span>
                    <h2 id="gradeAdminFinalizeTitle">Confirmar fechamento?</h2>
                    <p>A grade ficará marcada como fechada, mas administradores ainda poderão ajustar o calendário quando necessário.</p>
                </div>
            </div>

            <div class="grade-admin__modal-actions grade-admin__confirm-actions">
                <button class="briefing-wizard__ghost" type="button" data-grade-finalize-close>
                    <span>Cancelar</span>
                </button>
                <button class="briefing-entry__primary" type="button" id="gradeAdminFinalizeConfirm">
                    <span>Fechar grade</span>
                    <i class="bi bi-check2"></i>
                </button>
            </div>
        </section>
    </div>
</section>
<?php
    return;
}
?>

<section
    class="briefing-wizard grade-request"
    id="gradeRequestPage"
    data-channel-limits="<?php echo safe(json_encode($channelLimitMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?>"
    data-create-period-url="<?php echo safe(base_url() . '/api/grade/create-period.php'); ?>"
    data-submit-url="<?php echo safe(base_url() . '/api/grade/request.php'); ?>"
    data-grade-periods="<?php echo safe(json_encode($gradePeriodOptions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?>"
    data-grade-capacity="<?php echo safe(json_encode($gradeCapacityMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?>"
    data-current-operator="<?php echo safe(json_encode($currentOperator, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?>"
    data-current-requester="<?php echo safe(json_encode($currentRequester, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?>"
>
    <div class="briefing-wizard__overlay"></div>

    <div class="briefing-wizard__inner grade-request__inner">
        <div class="immersive-toolbar">
            <a class="briefing-wizard__back" href="<?php echo safe(route_url('home')); ?>">
                <i class="bi bi-arrow-left"></i>
                <span>Voltar</span>
            </a>
        </div>

        <section class="briefing-entry__intro is-hidden" id="gradeRequestIdentity">
            <span class="briefing-entry__eyebrow">Acesso interno</span>
            <h1>Solicitacao de grade</h1>
            <p>O usuário atual da sessão não está liberado para a operação interna. Se precisar acessar a grade, troque o usuário no topo por um e-mail com perfil adm ou analista.</p>

            <article class="session-requester-card">
                <span class="session-requester-card__avatar" aria-hidden="true"><?php echo safe($currentRequester['iniciais'] ?? 'U'); ?></span>
                <div class="session-requester-card__copy">
                    <span>Usuário atual</span>
                    <strong><?php echo safe(($currentRequester['nome'] ?? '') !== '' ? $currentRequester['nome'] : ($currentRequester['email'] ?? 'Usuário atual')); ?></strong>
                    <p><?php echo safe($currentRequester['email'] ?? 'Troque o usuário atual no topo para liberar outro perfil.'); ?></p>
                </div>
            </article>

            <p class="grade-request__identity-note">O briefing continua público para preenchimento. Já a operação da grade depende do cadastro interno do time de Comunicação.</p>
        </section>

        <div class="grade-request__flow" id="gradeRequestFlow">

        <article class="grade-request__signal-card grade-request__operator-card is-hidden" id="gradeRequestOperatorCard" data-tone="neutral">
            <div class="grade-request__operator-copy">
                <span>Acesso liberado</span>
                <strong id="gradeRequestOperatorName">Operador identificado</strong>
                <p id="gradeRequestOperatorEmail">Seu perfil interno foi carregado para esta sessão.</p>
            </div>

            <span class="status-badge is-neutral" id="gradeRequestOperatorRole">Analista</span>
        </article>

        <section class="grade-request__limits grade-request__admin-card is-hidden" id="gradeRequestAdminCard">
            <div class="grade-request__limits-head">
                <strong>Criar grade</strong>
                <p>Somente administradores criam a grade desta competência. Nesta primeira fase, a janela precisa começar e terminar no mesmo mês.</p>
            </div>

            <form class="grade-request__admin-form" id="gradeRequestPeriodForm">
                <div class="briefing-wizard__grid three-columns">
                    <label>
                        <span>Nome da grade</span>
                        <input type="text" name="nome" placeholder="Ex.: Grade Junho 2026" required>
                    </label>

                    <label>
                        <span>Data de início</span>
                        <input type="date" name="data_inicio" min="<?php echo safe($todayDate); ?>" required>
                    </label>

                    <label>
                        <span>Data de fim</span>
                        <input type="date" name="data_fim" min="<?php echo safe($todayDate); ?>" required>
                    </label>
                </div>

                <div class="grade-request__admin-actions">
                    <button class="briefing-entry__primary" type="submit" id="gradeRequestPeriodSubmit">
                        <span>Criar grade</span>
                        <i class="bi bi-calendar2-plus"></i>
                    </button>

                    <span class="status-badge is-danger">Somente adm</span>
                </div>
            </form>

            <article class="grade-request__signal-card grade-request__created-card is-hidden" id="gradeRequestPeriodResultCard" data-tone="success">
                <span>Grade criada</span>
                <strong id="gradeRequestPeriodResultTitle">Nova grade preparada</strong>
                <p id="gradeRequestPeriodResultCopy">A janela criada já pode alimentar o ciclo desta solicitação.</p>
            </article>
        </section>

        <div class="briefing-wizard__hero grade-request__hero grade-request__hero--minimal">
            <h1>Solicitacao de grade</h1>
        </div>

        <div class="briefing-wizard__progress">
            <div class="briefing-wizard__progress-copy">
                <strong id="gradeRequestStepLabel">Etapa 1 de 4</strong>
                <span id="gradeRequestStepTitle">Ciclo e entrada</span>
            </div>
            <div class="briefing-wizard__progress-bar">
                <span id="gradeRequestProgressBar" style="width: 25%;"></span>
            </div>
        </div>

        <div class="briefing-wizard__steps grade-request__steps">
            <button class="briefing-wizard__step is-active" type="button" data-grade-step-trigger="1">
                <span>1</span>
                <strong>Ciclo</strong>
            </button>
            <button class="briefing-wizard__step" type="button" data-grade-step-trigger="2">
                <span>2</span>
                <strong>Solicitação</strong>
            </button>
            <button class="briefing-wizard__step" type="button" data-grade-step-trigger="3">
                <span>3</span>
                <strong>Análise</strong>
            </button>
            <button class="briefing-wizard__step" type="button" data-grade-step-trigger="4">
                <span>4</span>
                <strong>Grade final</strong>
            </button>
        </div>

        <form class="briefing-wizard__form" id="gradeRequestForm">
            <section class="briefing-wizard__panel is-active" data-grade-step-panel="1" data-grade-step-title="Ciclo e entrada">
                <div class="briefing-wizard__panel-head">
                    <h2>Primeiro, configure a janela do ciclo.</h2>
                    <p>A partir daqui a ferramenta já consegue dizer se a entrada vai como grade perfeita ou encaixe.</p>
                </div>

                <div class="briefing-wizard__grid two-columns is-compact">
                    <label>
                        <span>Ciclo de referência</span>
                        <input type="month" name="ciclo_referencia" min="<?php echo safe($currentMonth); ?>" value="<?php echo safe(!empty($defaultGradePeriod['data_inicio']) ? substr((string) $defaultGradePeriod['data_inicio'], 0, 7) : $currentMonth); ?>" readonly>
                    </label>

                    <label>
                        <span>Data da solicitação</span>
                        <input type="date" name="data_solicitacao" min="<?php echo safe($todayDate); ?>" value="<?php echo safe($todayDate); ?>" required>
                    </label>

                    <label>
                        <span>Data de abertura</span>
                        <input type="date" name="data_abertura_ciclo" value="<?php echo safe((string) ($defaultGradePeriod['data_inicio'] ?? '')); ?>" readonly>
                    </label>

                    <label>
                        <span>Data de fechamento</span>
                        <input type="date" name="data_fechamento_ciclo" value="<?php echo safe((string) ($defaultGradePeriod['data_fim'] ?? '')); ?>" readonly>
                    </label>

                    <article class="grade-request__requester-card full-span" id="gradeRequestRequesterCard">
                        <div class="grade-request__requester-copy">
                            <span>Solicitante identificada</span>
                            <strong id="gradeRequestRequesterName">Aguardando identificação interna</strong>
                            <p id="gradeRequestRequesterEmail">O nome e o e-mail vêm do cadastro do usuário interno.</p>
                        </div>
                        <span class="mini-badge is-info">Preenchimento automático</span>
                    </article>

                    <input type="hidden" name="nome_solicitante" id="gradeRequestName" value="<?php echo safe($gradeRequesterDisplayName); ?>" required>
                    <input type="hidden" name="email_solicitante" id="gradeRequestEmail" value="<?php echo safe($gradeRequesterEmail); ?>" required>

                    <div class="grade-request__signal-grid full-span">
                        <article class="grade-request__signal-card" id="gradeRequestEntryTypeCard" data-tone="neutral">
                            <span>Entrada no ciclo</span>
                            <strong id="gradeRequestEntryType">Aguardando janela</strong>
                            <p id="gradeRequestEntryCopy">Defina abertura e fechamento para classificar a solicitação.</p>
                        </article>

                        <article class="grade-request__signal-card" id="gradeRequestCutoffCard" data-tone="neutral">
                            <span>Status do corte</span>
                            <strong id="gradeRequestCutoffStatus">Janela não configurada</strong>
                            <p id="gradeRequestCutoffCopy">Sem datas ainda, então a regra de corte continua pendente.</p>
                        </article>
                    </div>

                    <div class="briefing-wizard__hint-card full-span">
                        <i class="bi bi-stars"></i>
                        <div>
                            <strong>Regra principal da solicitante</strong>
                            <p>Durante a janela, a demanda entra como grade perfeita. Depois do corte, qualquer novo cadastro passa automaticamente a ser tratado como encaixe.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section class="briefing-wizard__panel" data-grade-step-panel="2" data-grade-step-title="Cadastro da solicitação">
                <div class="briefing-wizard__panel-head">
                    <h2>Agora cadastre a solicitação da comunicação.</h2>
                    <p>Este bloco foi montado com os campos citados pela solicitante: tema, justificativa, canais, público, data e responsáveis.</p>
                </div>

                <div class="briefing-wizard__grid two-columns is-compact">
                    <label class="full-span">
                        <span>Tema / assunto</span>
                        <input type="text" name="tema_assunto" placeholder="Ex.: Campanha de crédito para empresas" required>
                    </label>

                    <label class="full-span">
                        <span>Justificativa do tema</span>
                        <textarea name="justificativa_tema" placeholder="Explique por que a pauta precisa entrar na grade e qual contexto sustenta a demanda." required></textarea>
                    </label>

                    <fieldset class="briefing-wizard__field-group" data-required-group="publicos_alvo[]" data-required-label="ao menos um público-alvo">
                        <div class="briefing-wizard__group-head">
                            <span>Público-alvo</span>
                            <small>Empresas, negócios e demais recortes que recebem a comunicação.</small>
                        </div>

                        <div class="briefing-wizard__choice-grid">
                            <?php foreach ($publicoOptions as $publicoOption): ?>
                                <label class="briefing-wizard__choice-card">
                                    <input type="checkbox" name="publicos_alvo[]" value="<?php echo safe($publicoOption); ?>" data-label="<?php echo safe($publicoOption); ?>">
                                    <span><?php echo safe($publicoOption); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>

                    <label>
                        <span>Data sugerida de publicação</span>
                        <input type="date" name="data_publicacao_sugerida" min="<?php echo safe($todayDate); ?>" required>
                    </label>

                    <fieldset class="briefing-wizard__field-group full-span" data-required-group="canais[]" data-required-label="ao menos um canal desejado">
                        <div class="briefing-wizard__group-head">
                            <span>Sugestão de canais</span>
                            <small>Marque todos os canais que podem compor a grade desta pauta.</small>
                        </div>

                        <div class="briefing-wizard__choice-grid is-channel-grid">
                            <?php foreach ($channelLimits as $channelLimit): ?>
                                <label class="briefing-wizard__choice-card">
                                    <input type="checkbox" name="canais[]" value="<?php echo safe($channelLimit['name']); ?>" data-label="<?php echo safe($channelLimit['name']); ?>">
                                    <span><?php echo safe($channelLimit['name']); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>

                    <label class="briefing-wizard__select-label">
                        <span>Classificação do assunto</span>
                        <select name="classificacao_assunto" required>
                            <option value="">Selecione</option>
                            <?php foreach ($classificacaoAssuntoOptions as $classificacaoAssuntoOption): ?>
                                <option value="<?php echo safe($classificacaoAssuntoOption); ?>"><?php echo safe($classificacaoAssuntoOption); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <label>
                        <span>Nome do responsável pelo tema</span>
                        <input type="text" name="responsavel_tema" placeholder="Quem lidera esse assunto" required>
                    </label>

                    <label class="briefing-wizard__select-label">
                        <span>Área responsável pelo tema</span>
                        <select name="area_responsavel_tema" required>
                            <option value="">Selecione</option>
                            <?php foreach ($areaResponsavelOptions as $areaResponsavelOption): ?>
                                <option value="<?php echo safe($areaResponsavelOption); ?>"><?php echo safe($areaResponsavelOption); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <fieldset class="briefing-wizard__field-group" data-required-group="classificacao_demanda" data-required-label="a classificação da demanda">
                        <div class="briefing-wizard__group-head">
                            <span>Classificação da demanda</span>
                            <small>Separação pedida no fluxo entre informativo e estratégico.</small>
                        </div>

                        <div class="briefing-wizard__inline-toggle">
                            <label class="briefing-wizard__radio-card">
                                <input type="radio" name="classificacao_demanda" value="Informativo" data-label="Informativo">
                                <span>Informativo</span>
                            </label>
                            <label class="briefing-wizard__radio-card">
                                <input type="radio" name="classificacao_demanda" value="Estratégico" data-label="Estratégico">
                                <span>Estratégico</span>
                            </label>
                        </div>
                    </fieldset>

                    <fieldset class="briefing-wizard__field-group full-span" data-required-group="grau_necessidade" data-required-label="o grau de necessidade">
                        <div class="briefing-wizard__group-head">
                            <span>Grau de necessidade</span>
                            <small>Ajuda a priorizar o que entra primeiro na análise e na grade final.</small>
                        </div>

                        <div class="grade-request__priority-grid">
                            <?php foreach ($prioridadeOptions as $prioridadeOption): ?>
                                <label class="grade-request__priority-card grade-request__priority-card--<?php echo safe($prioridadeOption['tone']); ?>">
                                    <input type="radio" name="grau_necessidade" value="<?php echo safe($prioridadeOption['label']); ?>" data-label="<?php echo safe($prioridadeOption['label']); ?>">
                                    <span class="grade-request__priority-dot" aria-hidden="true"></span>
                                    <span class="grade-request__priority-copy">
                                        <strong><?php echo safe($prioridadeOption['label']); ?></strong>
                                        <small><?php echo safe($prioridadeOption['description']); ?></small>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>
                </div>
            </section>

            <section class="briefing-wizard__panel" data-grade-step-panel="3" data-grade-step-title="Análise e aprovação">
                <div class="briefing-wizard__panel-head">
                    <h2>Analise a solicitação e prepare a grade final.</h2>
                    <p>Essa etapa concentra a visão consolidada do ciclo, a aprovação individual e o ajuste de data ou canal quando necessário.</p>
                </div>

                <div class="grade-request__signal-grid">
                    <article class="grade-request__signal-card" id="gradeRequestAnalysisEntryCard" data-tone="neutral">
                        <span>Classificação da entrada</span>
                        <strong id="gradeRequestAnalysisEntryType">Aguardando janela</strong>
                        <p id="gradeRequestAnalysisEntryCopy">A regra do corte aparece aqui assim que o ciclo estiver definido.</p>
                    </article>

                    <article class="grade-request__signal-card" id="gradeRequestDeadlineCard" data-tone="neutral">
                        <span>Prazo do briefing</span>
                        <strong id="gradeRequestBriefingDeadline">Aguardando data final</strong>
                        <p id="gradeRequestDeadlineCopy">A data final de publicação libera o cálculo de 10 dias úteis antes.</p>
                    </article>

                    <article class="grade-request__signal-card" id="gradeRequestLockCard" data-tone="neutral">
                        <span>Janela de edição</span>
                        <strong id="gradeRequestLockState">Ainda sem trava</strong>
                        <p id="gradeRequestLockCopy">Depois do prazo do briefing, a solicitação passa a ficar travada.</p>
                    </article>
                </div>

                <div class="briefing-wizard__grid two-columns is-compact">
                    <fieldset class="briefing-wizard__field-group full-span" data-required-group="status_analise" data-required-label="a decisão da análise">
                        <div class="briefing-wizard__group-head">
                            <span>Decisão da análise</span>
                            <small>Aprova, ajusta ou reorganiza a solicitação antes da montagem da grade.</small>
                        </div>

                        <div class="grade-request__decision-grid">
                            <?php foreach ($statusAnaliseOptions as $statusAnaliseOption): ?>
                                <label class="grade-request__decision-card">
                                    <input type="radio" name="status_analise" value="<?php echo safe($statusAnaliseOption['label']); ?>" data-label="<?php echo safe($statusAnaliseOption['label']); ?>">
                                    <span class="grade-request__decision-copy">
                                        <strong><?php echo safe($statusAnaliseOption['label']); ?></strong>
                                        <small><?php echo safe($statusAnaliseOption['description']); ?></small>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>

                    <label>
                        <span>Data final de publicação</span>
                        <input type="date" name="data_publicacao_final" min="<?php echo safe($todayDate); ?>" required>
                    </label>

                    <label class="briefing-wizard__select-label">
                        <span>Canal principal</span>
                        <select name="canal_principal" required>
                            <option value="">Selecione</option>
                            <?php foreach ($channelLimits as $channelLimit): ?>
                                <option value="<?php echo safe($channelLimit['name']); ?>"><?php echo safe($channelLimit['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <fieldset class="briefing-wizard__field-group full-span" data-required-group="canais_aprovados[]" data-required-label="os canais aprovados">
                        <div class="briefing-wizard__group-head">
                            <span>Canais aprovados para a grade</span>
                            <small>Você pode reorganizar a demanda e ajustar a distribuição por canal.</small>
                        </div>

                        <div class="briefing-wizard__choice-grid is-channel-grid">
                            <?php foreach ($channelLimits as $channelLimit): ?>
                                <label class="briefing-wizard__choice-card">
                                    <input type="checkbox" name="canais_aprovados[]" value="<?php echo safe($channelLimit['name']); ?>" data-label="<?php echo safe($channelLimit['name']); ?>">
                                    <span><?php echo safe($channelLimit['name']); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>

                    <label>
                        <span>Responsável pelo atendimento</span>
                        <input type="text" name="responsavel_atendimento" placeholder="Quem assume a execução após a aprovação" required>
                    </label>

                    <label class="full-span">
                        <span>Parecer da análise</span>
                        <textarea name="parecer_analise" placeholder="Registre ajustes de data, canal, priorização e qualquer reorganização necessária." required></textarea>
                    </label>

                    <div class="grade-request__limits full-span">
                        <div class="grade-request__limits-head">
                            <strong>Limites dos canais selecionados</strong>
                            <p>Essa visão ajuda a montar a grade final respeitando a capacidade diária de cada canal.</p>
                        </div>

                        <div class="grade-request__limits-list" id="gradeRequestLimitList"></div>
                        <p class="grade-request__limits-empty" id="gradeRequestLimitEmpty">Selecione os canais aprovados para conferir os limites diários aplicáveis.</p>
                    </div>
                </div>
            </section>

            <section class="briefing-wizard__panel" data-grade-step-panel="4" data-grade-step-title="Grade final e revisão">
                <div class="briefing-wizard__panel-head">
                    <h2>Feche a grade final com a leitura do ciclo.</h2>
                    <p>Aqui você enxerga a entrada classificada, o prazo do briefing e o recorte de canais que precisa ser respeitado.</p>
                </div>

                <div class="grade-request__final-grid">
                    <article class="grade-request__final-card" id="gradeRequestFinalEntryCard" data-tone="neutral">
                        <span>Entrada classificada</span>
                        <strong id="gradeRequestFinalEntryType">Aguardando análise</strong>
                        <p id="gradeRequestFinalEntryCopy">A definição do ciclo alimenta esta leitura automaticamente.</p>
                    </article>

                    <article class="grade-request__final-card" id="gradeRequestFinalDeadlineCard" data-tone="neutral">
                        <span>Prazo do briefing</span>
                        <strong id="gradeRequestFinalDeadline">Aguardando data final</strong>
                        <p id="gradeRequestFinalDeadlineCopy">Assim que a publicação final estiver definida, o prazo aparece aqui.</p>
                    </article>

                    <article class="grade-request__final-card" id="gradeRequestFinalLockCard" data-tone="neutral">
                        <span>Status da janela</span>
                        <strong id="gradeRequestFinalLockState">Sem trava por enquanto</strong>
                        <p id="gradeRequestFinalLockCopy">Depois do prazo do briefing, a edição deve ser bloqueada.</p>
                    </article>
                </div>

                <div class="briefing-wizard__review" id="gradeRequestReview"></div>

                <div class="grade-request__limits grade-request__limits--final">
                    <div class="grade-request__limits-head">
                        <strong>Capacidade considerada para a grade final</strong>
                        <p>Os mesmos limites abaixo podem alimentar a futura visão em calendário e a exportação final.</p>
                    </div>

                    <div class="grade-request__limits-list" id="gradeRequestFinalLimitList"></div>
                    <p class="grade-request__limits-empty" id="gradeRequestFinalLimitEmpty">Os canais aprovados ainda não foram definidos.</p>
                </div>

                <div class="briefing-wizard__hint-card">
                    <i class="bi bi-calendar2-check"></i>
                    <div>
                        <strong>Próxima evolução natural</strong>
                        <p>O próximo passo é conectar esta revisão a uma grade visual por data e canal, com aprovação final e exportação em Excel.</p>
                    </div>
                </div>
            </section>

            <div class="briefing-wizard__footer">
                <button class="briefing-wizard__ghost" type="button" data-grade-prev>
                    <i class="bi bi-arrow-left"></i>
                    <span>Etapa anterior</span>
                </button>

                <div class="briefing-wizard__footer-actions">
                    <button class="briefing-wizard__secondary" type="button" data-grade-reset>
                        <i class="bi bi-arrow-counterclockwise"></i>
                        <span>Limpar fluxo</span>
                    </button>

                    <button class="briefing-wizard__ghost" type="button" data-grade-next>
                        <span>Próxima etapa</span>
                        <i class="bi bi-arrow-right"></i>
                    </button>

                    <button class="briefing-wizard__primary is-hidden" type="button" data-grade-finish>
                        <span>Enviar solicitacao</span>
                        <i class="bi bi-check2-circle"></i>
                    </button>
                </div>
            </div>
        </form>
        </div>
    </div>
</section>
