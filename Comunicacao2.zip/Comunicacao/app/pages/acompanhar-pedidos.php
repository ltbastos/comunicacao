<?php
require __DIR__ . '/_direct-access.php';

$currentRequester = current_requester();
?>

<section
    class="briefing-entry"
    id="briefingEntry"
    data-lookup-url="<?php echo safe(base_url() . '/api/briefings/by-email.php'); ?>"
    data-create-url="<?php echo safe(route_url('novo-briefing')); ?>"
    data-session-email="<?php echo safe($currentRequester['email'] ?? ''); ?>"
    data-session-name="<?php echo safe($currentRequester['nome'] ?? ''); ?>"
>
    <div class="briefing-entry__overlay"></div>

    <div class="briefing-entry__inner">
        <div class="immersive-toolbar">
            <a class="briefing-entry__back" href="<?php echo safe(route_url('home')); ?>">
                <i class="bi bi-arrow-left"></i>
                <span>Voltar</span>
            </a>
        </div>

        <section class="briefing-entry__intro" id="briefingIntro">
            <span class="briefing-entry__eyebrow">Acompanhamento</span>
            <h1>Acompanhe seus pedidos</h1>
            <p>Estou usando o usuario desta sessao para puxar briefings e solicitacoes de grade, conferir prazos e mostrar tudo por aqui sem pedir o e-mail de novo.</p>

            <article class="session-requester-card">
                <span class="session-requester-card__avatar" aria-hidden="true"><?php echo safe($currentRequester['iniciais'] ?? 'U'); ?></span>
                <div class="session-requester-card__copy">
                    <span>Usuario da sessao</span>
                    <strong><?php echo safe(($currentRequester['nome'] ?? '') !== '' ? $currentRequester['nome'] : ($currentRequester['email'] ?? 'Usuario atual')); ?></strong>
                    <p><?php echo safe($currentRequester['email'] ?? 'Use o topo da pagina para trocar o usuario atual.'); ?></p>
                </div>
            </article>
        </section>

        <section class="briefing-entry__loading is-hidden" id="briefingLookupLoading" aria-live="polite">
            <div class="briefing-entry__loader">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <strong>Boa. Estou buscando suas informacoes.</strong>
            <p id="briefingLookupLoadingMessage">Conferindo seus pedidos, prazos e atendimentos...</p>
        </section>

        <section class="briefing-entry__results is-hidden" id="briefingLookupResults">
            <div class="briefing-entry__results-head">
                <div>
                    <span class="briefing-entry__eyebrow">Pedidos encontrados</span>
                    <h2 id="briefingLookupHeading">Seus pedidos</h2>
                    <p class="briefing-entry__results-copy" id="briefingLookupCopy">Aqui estao seus briefings e solicitacoes de grade em andamento.</p>
                </div>
            </div>

            <div class="briefing-entry__summary-row">
                <div class="briefing-entry__summary-card">
                    <span class="briefing-entry__summary-label">Consulta atual</span>
                    <div class="briefing-entry__email-pill" id="briefingLookupEmailPill"></div>
                </div>

                <div class="briefing-entry__session-note">
                    <i class="bi bi-person-badge"></i>
                    <span>Se precisar mudar de usuario, use o topo da pagina.</span>
                </div>
            </div>

            <div class="briefing-entry__list" id="briefingLookupList"></div>

            <div class="briefing-entry__empty is-hidden" id="briefingLookupEmpty">
                <i class="bi bi-chat-heart"></i>
                <strong>Voce ainda nao tem pedidos por aqui.</strong>
                <p>Sem problema. Voce pode comecar um novo briefing ou abrir uma solicitacao de grade pela pagina inicial.</p>
            </div>

            <div class="briefing-entry__actions">
                <button class="briefing-entry__primary" type="button" id="briefingLookupCreate">
                    <span>Enviar novo briefing</span>
                    <i class="bi bi-send"></i>
                </button>
                <a class="briefing-entry__secondary" href="<?php echo safe(route_url('home')); ?>">
                    <span>Voltar ao inicio</span>
                </a>
            </div>
        </section>
    </div>
</section>
