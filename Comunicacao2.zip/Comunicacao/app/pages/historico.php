<?php
require __DIR__ . '/_direct-access.php';

$briefings = mock_data('briefings', []);
$detail = mock_data('history', [])['detail'];
$detailStatus = status_meta($detail['status']);
$detailPriority = priority_meta($detail['priority']);
?>

<section class="surface-card filter-panel" id="filtros-historico">
    <div class="section-heading">
        <div>
            <span class="eyebrow">Busca avancada</span>
            <h3>Filtros cruzados</h3>
        </div>
    </div>

    <form class="form-grid four-columns">
        <label>
            <span>Texto</span>
            <input type="search" placeholder="Titulo, mensagem ou codigo">
        </label>
        <label>
            <span>E-mail do solicitante</span>
            <input type="email" placeholder="solicitante@empresa.com.br">
        </label>
        <label>
            <span>Status</span>
            <select><option>Todos</option><option>Em analise</option><option>Publicado</option><option>Atrasado</option></select>
        </label>
        <label>
            <span>Canal</span>
            <select><option>Todos</option><option>Intranet</option><option>E-mail Marketing</option><option>Portal</option></select>
        </label>
    </form>
</section>

<section class="history-layout">
    <article class="surface-card table-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Resultados</span>
                <h3>Historico de briefings</h3>
            </div>
            <span class="meta-chip is-neutral">Paginacao pronta para evolucao</span>
        </div>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Codigo</th><th>Titulo</th><th>Solicitante</th><th>Area</th><th>Status</th><th>Prioridade</th><th>Ultima atualizacao</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($briefings as $briefing): ?>
                    <?php $status = status_meta($briefing['status']); ?>
                    <?php $priority = priority_meta($briefing['priority']); ?>
                    <tr>
                        <td><?php echo safe($briefing['code']); ?></td>
                        <td><?php echo safe($briefing['title']); ?></td>
                        <td><?php echo safe($briefing['name']); ?><br><small><?php echo safe($briefing['email']); ?></small></td>
                        <td><?php echo safe($briefing['area']); ?></td>
                        <td><span class="status-badge <?php echo safe(tone_class($status['tone'])); ?>"><?php echo safe($status['label']); ?></span></td>
                        <td><span class="mini-badge <?php echo safe(tone_class($priority['tone'])); ?>"><?php echo safe($priority['label']); ?></span></td>
                        <td><?php echo safe(format_date_br($briefing['updated_at'], true)); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="pagination-bar">
            <button class="pagination-button is-active" type="button">1</button>
            <button class="pagination-button" type="button">2</button>
            <button class="pagination-button" type="button">3</button>
            <button class="pagination-button" type="button">Proxima</button>
        </div>
    </article>

    <aside class="surface-card detail-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Detalhe selecionado</span>
                <h3><?php echo safe($detail['code']); ?></h3>
            </div>
        </div>

        <div class="detail-card-top">
            <strong><?php echo safe($detail['title']); ?></strong>
            <div class="detail-badges">
                <span class="status-badge <?php echo safe(tone_class($detailStatus['tone'])); ?>"><?php echo safe($detailStatus['label']); ?></span>
                <span class="mini-badge <?php echo safe(tone_class($detailPriority['tone'])); ?>"><?php echo safe($detailPriority['label']); ?></span>
            </div>
        </div>

        <div class="detail-meta">
            <div>
                <span>Solicitante</span>
                <strong><?php echo safe($detail['requester']); ?></strong>
                <small><?php echo safe($detail['requester_email']); ?></small>
            </div>
            <div>
                <span>Area / Canal</span>
                <strong><?php echo safe($detail['area']); ?></strong>
                <small><?php echo safe($detail['channel']); ?></small>
            </div>
            <div>
                <span>Criado em</span>
                <strong><?php echo safe(format_date_br($detail['created_at'], true)); ?></strong>
                <small>Atualizado em <?php echo safe(format_date_br($detail['updated_at'], true)); ?></small>
            </div>
        </div>

        <div class="timeline-list">
            <?php foreach ($detail['notes'] as $note): ?>
                <article class="timeline-item compact">
                    <span class="timeline-dot"></span>
                    <div><p><?php echo safe($note); ?></p></div>
                </article>
            <?php endforeach; ?>
        </div>
    </aside>
</section>
