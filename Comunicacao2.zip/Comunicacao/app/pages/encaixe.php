<?php
require __DIR__ . '/_direct-access.php';
?>

<section class="immersive-placeholder">
    <div class="immersive-placeholder__card">
        <span class="immersive-placeholder__eyebrow">Nova tela em seguida</span>
        <h1>Precisa de um encaixe?</h1>
        <p>Esta area sera desenhada em seguida para pedidos fora da grade e ajustes rapidos de pauta.</p>
        <a class="immersive-placeholder__back" href="<?php echo safe(route_url('home')); ?>">
            <i class="bi bi-arrow-left"></i>
            <span>Voltar</span>
        </a>
    </div>
</section>
