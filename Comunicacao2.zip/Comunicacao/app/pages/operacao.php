<?php
require __DIR__ . '/_direct-access.php';

$briefings = mock_data('briefings', []);
$groupedBriefings = briefings_by_status($briefings);
$columns = ['enviado' => 'Enviado', 'em_analise' => 'Em analise', 'com_pendencia' => 'Com pendencia', 'em_producao' => 'Em producao', 'publicado' => 'Publicado'];
$timeline = mock_data('operation', [])['timeline'];
?>

<section class="planner-overview">
    <article class="surface-card planner-highlight">
        <span class="eyebrow">Esteira ativa</span>
        <h2>Operacao do time de Comunicacao</h2>
        <p>Visao tatico-operacional com filtros, pipeline e historico das movimentacoes mais recentes.</p>
    </article>
    <article class="surface-card planner-stat"><strong>11</strong><span>em analise</span></article>
    <article class="surface-card planner-stat"><strong>6</strong><span>com pendencia</span></article>
    <article class="surface-card planner-stat"><strong>3</strong><span>atrasados</span></article>
</section>

<section class="surface-card filter-panel">
    <div class="filter-row">
        <button class="filter-chip is-active" type="button">Todos os status</button>
        <button class="filter-chip" type="button">Responsavel</button>
        <button class="filter-chip" type="button">Abril 2026</button>
        <button class="filter-chip" type="button">Canal</button>
        <button class="filter-chip" type="button">Prioridade</button>
    </div>
</section>

<section class="section-stack">
    <div class="section-heading">
        <div>
            <span class="eyebrow">Visoes operacionais</span>
            <h3>Alternar entre tabela e pipeline</h3>
        </div>
        <div class="view-switch">
            <button class="view-switch-button is-active" type="button" data-view-target="table"><i class="bi bi-table"></i><span>Tabela</span></button>
            <button class="view-switch-button" type="button" data-view-target="kanban"><i class="bi bi-kanban"></i><span>Pipeline</span></button>
        </div>
    </div>

    <div class="view-panel is-active" data-view-panel="table">
        <article class="surface-card table-card" id="operacao-tabela">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Codigo</th><th>Titulo</th><th>Area</th><th>Canal</th><th>Responsavel</th><th>Prazo</th><th>Status</th><th>Prioridade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($briefings as $briefing): ?>
                        <?php $status = status_meta($briefing['status']); ?>
                        <?php $priority = priority_meta($briefing['priority']); ?>
                        <tr>
                            <td><?php echo safe($briefing['code']); ?></td>
                            <td><strong><?php echo safe($briefing['title']); ?></strong><small><?php echo safe($briefing['summary']); ?></small></td>
                            <td><?php echo safe($briefing['area']); ?></td>
                            <td><?php echo safe($briefing['channel']); ?></td>
                            <td><?php echo safe($briefing['owner']); ?></td>
                            <td><?php echo safe(format_date_br($briefing['due'])); ?></td>
                            <td><span class="status-badge <?php echo safe(tone_class($status['tone'])); ?>"><?php echo safe($status['label']); ?></span></td>
                            <td><span class="mini-badge <?php echo safe(tone_class($priority['tone'])); ?>"><?php echo safe($priority['label']); ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </article>
    </div>

    <div class="view-panel" data-view-panel="kanban">
        <div class="kanban-board">
            <?php foreach ($columns as $statusKey => $label): ?>
                <?php $status = status_meta($statusKey); ?>
                <article class="surface-card kanban-column">
                    <div class="kanban-column-head">
                        <strong><?php echo safe($label); ?></strong>
                        <span class="mini-badge <?php echo safe(tone_class($status['tone'])); ?>"><?php echo safe(count($groupedBriefings[$statusKey] ?? [])); ?></span>
                    </div>
                    <div class="kanban-list">
                        <?php foreach ($groupedBriefings[$statusKey] ?? [] as $briefing): ?>
                            <?php $priority = priority_meta($briefing['priority']); ?>
                            <article class="kanban-card">
                                <span class="briefing-code"><?php echo safe($briefing['code']); ?></span>
                                <h4><?php echo safe($briefing['title']); ?></h4>
                                <p><?php echo safe($briefing['area']); ?> • <?php echo safe($briefing['channel']); ?></p>
                                <div class="kanban-meta">
                                    <span><?php echo safe($briefing['owner']); ?></span>
                                    <span><?php echo safe(format_date_br($briefing['due'])); ?></span>
                                </div>
                                <span class="mini-badge <?php echo safe(tone_class($priority['tone'])); ?>"><?php echo safe($priority['label']); ?></span>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="content-grid-two">
    <article class="surface-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Historico recente</span>
                <h3>Movimentacoes</h3>
            </div>
        </div>
        <div class="timeline-list">
            <?php foreach ($timeline as $event): ?>
                <article class="timeline-item">
                    <span class="timeline-dot"></span>
                    <div>
                        <strong><?php echo safe($event['title']); ?></strong>
                        <p><?php echo safe($event['detail']); ?></p>
                        <small><?php echo safe($event['author']); ?> • <?php echo safe(format_date_br($event['time'], true)); ?></small>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </article>

    <article class="surface-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Controles rapidos</span>
                <h3>Atualizacao de status</h3>
            </div>
        </div>

        <form class="compact-form" data-demo-form="status">
            <label>
                <span>Briefing</span>
                <select><option>BRF-2026-0001</option><option>BRF-2026-0002</option><option>BRF-2026-0006</option></select>
            </label>
            <label>
                <span>Novo status</span>
                <select><option>Em analise</option><option>Com pendencia</option><option>Aprovado</option><option>Em producao</option></select>
            </label>
            <label>
                <span>Responsavel</span>
                <input type="email" placeholder="responsavel@empresa.com.br">
            </label>
            <label>
                <span>Comentario interno</span>
                <textarea rows="4" placeholder="Registre contexto, pendencia ou decisao."></textarea>
            </label>
            <button class="action-button primary full" type="submit">
                <i class="bi bi-check2-square"></i>
                <span>Salvar movimentacao</span>
            </button>
        </form>
    </article>
</section>
