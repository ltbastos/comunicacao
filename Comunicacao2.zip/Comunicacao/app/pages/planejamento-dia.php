<?php
require __DIR__ . '/_direct-access.php';

$requestedPeriodId = (int) ($_GET['periodo_id'] ?? 0);
$planningContext = grade_resolve_planning_context($requestedPeriodId);
$period = $planningContext['period'];
$items = (array) ($planningContext['items'] ?? []);
$source = (string) ($planningContext['source'] ?? 'empty');

if (!$period):
?>
    <article class="surface-card empty-state-page">
        <i class="bi bi-calendar-x"></i>
        <h2>Período indisponível</h2>
        <p>Selecione ou crie uma grade para abrir o detalhe diário.</p>
    </article>
<?php
    return;
endif;

$selectedDate = trim((string) ($_GET['date'] ?? $period['data_inicio']));

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate) || $selectedDate < $period['data_inicio'] || $selectedDate > $period['data_fim']) {
    $selectedDate = $period['data_inicio'];
}

$dayItems = [];

foreach ($items as $item) {
    if (($item['date'] ?? '') === $selectedDate) {
        $dayItems[] = $item;
    }
}

usort($dayItems, function ($left, $right) {
    $leftSlot = (int) ($left['slot'] ?? 1);
    $rightSlot = (int) ($right['slot'] ?? 1);

    if ($leftSlot === $rightSlot) {
        return strcmp((string) ($left['title'] ?? ''), (string) ($right['title'] ?? ''));
    }

    return $leftSlot <=> $rightSlot;
});

$scheduledItems = [];
$nextSlotIndex = 0;
$scheduleBase = new DateTimeImmutable('2000-01-01 08:00:00');
$usageByChannel = [];

foreach ($dayItems as $item) {
    $desiredIndex = max($nextSlotIndex, max(0, ((int) ($item['slot'] ?? 1)) - 1));
    $scheduledItems[] = $item + [
        'scheduled_time' => $scheduleBase->modify('+' . ($desiredIndex * 2) . ' hours')->format('H:i'),
    ];
    $nextSlotIndex = $desiredIndex + 1;

    $channelName = trim((string) ($item['channel'] ?? ''));
    $usageByChannel[$channelName] = (int) ($usageByChannel[$channelName] ?? 0) + max(1, (int) ($item['capacity_units'] ?? 1));
}

$dailyCapacity = [];

foreach ($usageByChannel as $channelName => $usedSlots) {
    $rule = grade_channel_limit_rule($channelName);
    $dailyCapacity[] = [
        'name' => $rule['name'],
        'used' => $usedSlots,
        'limit' => $rule['limit'],
        'limit_label' => $rule['limit_label'],
    ];
}

$backUrl = route_url('planejamento', ['periodo_id' => $period['id'], 'date' => $selectedDate]);
$sourceLabel = $source === 'database' ? 'Grade real' : 'Modo demonstração';
$sourceTone = $source === 'database' ? 'success' : 'warning';
?>

<section class="section-stack">
    <div class="planner-overview">
        <article class="surface-card planner-highlight">
            <span class="eyebrow">Agenda do dia</span>
            <h2><?php echo safe(format_date_br($selectedDate)); ?></h2>
            <p>Visão hora a hora dos eventos previstos para <?php echo safe($period['label']); ?>, com leitura rápida de status, canal e área responsável.</p>
        </article>
        <article class="surface-card planner-stat"><strong><?php echo safe(count($scheduledItems)); ?></strong><span>eventos no dia</span></article>
        <article class="surface-card planner-stat"><strong><?php echo safe(count($dailyCapacity)); ?></strong><span>canais ocupados</span></article>
        <article class="surface-card planner-stat"><strong><?php echo safe($period['label']); ?></strong><span>competência</span></article>
    </div>

    <article class="surface-card planner-summary-band">
        <div>
            <span class="eyebrow">Período</span>
            <h3><?php echo safe(format_date_br($period['data_inicio']) . ' a ' . format_date_br($period['data_fim'])); ?></h3>
            <p>Use este detalhe para revisar o dia antes de fechar a grade ou encaixar novas demandas.</p>
        </div>
        <div class="detail-badges">
            <span class="status-badge <?php echo safe(tone_class($sourceTone)); ?>"><?php echo safe($sourceLabel); ?></span>
            <a class="action-button ghost" href="<?php echo safe($backUrl); ?>">
                <i class="bi bi-arrow-left"></i>
                <span>Voltar ao calendário</span>
            </a>
        </div>
    </article>
</section>

<section class="day-detail-layout">
    <article class="surface-card detail-card">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Hora a hora</span>
                <h3>Agenda editorial do dia</h3>
            </div>
        </div>

        <?php if (!$scheduledItems): ?>
            <div class="empty-state">
                <i class="bi bi-calendar2-check"></i>
                <p>Nenhum evento cadastrado para esta data.</p>
            </div>
        <?php else: ?>
            <div class="timeline-list day-schedule-list">
                <?php foreach ($scheduledItems as $item): ?>
                    <?php $status = status_meta($item['status'] ?? 'planejado'); ?>
                    <article class="timeline-item">
                        <span class="timeline-dot" style="background: <?php echo safe($item['channel_color']); ?>;"></span>
                        <div class="day-schedule-row">
                            <span class="schedule-hour"><?php echo safe($item['scheduled_time']); ?></span>

                            <div>
                                <strong><?php echo safe($item['title']); ?></strong>
                                <p><?php echo safe($item['channel']); ?> • <?php echo safe($item['area']); ?></p>

                                <div class="detail-badges">
                                    <span class="mini-badge <?php echo safe(tone_class($status['tone'])); ?>"><?php echo safe($status['label']); ?></span>
                                    <span class="mini-badge is-neutral"><?php echo safe($item['type'] ?? 'Demanda editorial'); ?></span>
                                    <?php if (empty($item['in_plan'])): ?>
                                        <span class="mini-badge is-warning">Fora da grade</span>
                                    <?php endif; ?>
                                </div>

                                <?php if (!empty($item['notes'])): ?>
                                    <p class="schedule-note"><?php echo safe($item['notes']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </article>

    <aside class="planner-side">
        <article class="surface-card">
            <div class="section-heading">
                <div>
                    <span class="eyebrow">Resumo</span>
                    <h3>Leitura rápida</h3>
                </div>
            </div>

            <div class="detail-meta">
                <div>
                    <span>Data</span>
                    <strong><?php echo safe(format_date_br($selectedDate)); ?></strong>
                </div>
                <div>
                    <span>Eventos</span>
                    <strong><?php echo safe(count($scheduledItems)); ?></strong>
                </div>
                <div>
                    <span>Período</span>
                    <strong><?php echo safe($period['label']); ?></strong>
                </div>
            </div>
        </article>

        <article class="surface-card">
            <div class="section-heading">
                <div>
                    <span class="eyebrow">Capacidade do dia</span>
                    <h3>Uso por canal</h3>
                </div>
            </div>

            <?php if (!$dailyCapacity): ?>
                <div class="info-banner">
                    <i class="bi bi-info-circle"></i>
                    <div>
                        <strong>Dia livre</strong>
                        <p>Nenhum canal ocupa slot nesta data.</p>
                    </div>
                </div>
            <?php else: ?>
                <div class="stack-list">
                    <?php foreach ($dailyCapacity as $capacity): ?>
                        <article class="list-row compact">
                            <div>
                                <strong><?php echo safe($capacity['name']); ?></strong>
                                <p><?php echo safe($capacity['limit_label']); ?></p>
                            </div>
                            <span class="status-badge <?php echo safe(tone_class($capacity['used'] >= $capacity['limit'] ? 'warning' : 'success')); ?>">
                                <?php echo safe($capacity['used'] . '/' . $capacity['limit']); ?> slot(s)
                            </span>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </article>
    </aside>
</section>