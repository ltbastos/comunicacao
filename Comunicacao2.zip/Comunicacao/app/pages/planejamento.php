<?php
require __DIR__ . '/_direct-access.php';

$requestedPeriodId = (int) ($_GET['periodo_id'] ?? 0);
$focusedDate = trim((string) ($_GET['date'] ?? ''));
$planningContext = grade_resolve_planning_context($requestedPeriodId);
$period = $planningContext['period'];
$items = (array) ($planningContext['items'] ?? []);
$source = (string) ($planningContext['source'] ?? 'empty');

if (!$period):
?>
    <article class="surface-card empty-state-page">
        <i class="bi bi-calendar-x"></i>
        <h2>Nenhuma grade disponível</h2>
        <p>Crie um período em Solicitação de Grade para liberar o calendário operacional.</p>
    </article>
<?php
    return;
endif;

$calendar = calendar_matrix($period['year'], $period['month'], $items);
$outsideItems = [];
$plannedCount = 0;
$channelUsageByDate = [];

foreach ($items as $item) {
    if (!empty($item['in_plan'])) {
        $plannedCount++;
    } else {
        $outsideItems[] = $item;
    }

    $channelName = trim((string) ($item['channel'] ?? ''));
    $dateKey = trim((string) ($item['date'] ?? ''));
    $capacityUnits = max(1, (int) ($item['capacity_units'] ?? 1));

    if ($channelName === '' || $dateKey === '') {
        continue;
    }

    if (!isset($channelUsageByDate[$channelName])) {
        $channelUsageByDate[$channelName] = [];
    }

    if (!isset($channelUsageByDate[$channelName][$dateKey])) {
        $channelUsageByDate[$channelName][$dateKey] = 0;
    }

    $channelUsageByDate[$channelName][$dateKey] += $capacityUnits;
}

$criticalDaysMap = [];

foreach ($channelUsageByDate as $channelName => $dailyUsage) {
    $rule = grade_channel_limit_rule($channelName);

    foreach ($dailyUsage as $dateKey => $usedSlots) {
        if ($usedSlots >= $rule['limit']) {
            $criticalDaysMap[$dateKey] = true;
        }
    }
}

$periodStart = new DateTimeImmutable($period['data_inicio']);
$periodEnd = new DateTimeImmutable($period['data_fim']);
$today = new DateTimeImmutable(date('Y-m-d'));
$availabilityCursorStart = $periodStart->format('Y-m-d') < $today->format('Y-m-d') ? $today : $periodStart;
$channelAvailability = [];

foreach (grade_channel_limit_rules() as $channelName => $rule) {
    $peakUsed = 0;
    $totalScheduled = 0;

    foreach ((array) ($channelUsageByDate[$channelName] ?? []) as $usedSlots) {
        $usedSlots = (int) $usedSlots;
        $totalScheduled += $usedSlots;

        if ($usedSlots > $peakUsed) {
            $peakUsed = $usedSlots;
        }
    }

    $nextFreeDate = null;
    $cursor = $availabilityCursorStart;

    while ($cursor->format('Y-m-d') <= $periodEnd->format('Y-m-d')) {
        $dateKey = $cursor->format('Y-m-d');
        $usedSlots = (int) ($channelUsageByDate[$channelName][$dateKey] ?? 0);

        if ($usedSlots < $rule['limit']) {
            $nextFreeDate = $dateKey;
            break;
        }

        $cursor = $cursor->modify('+1 day');
    }

    $channelAvailability[] = [
        'name' => $rule['name'],
        'limit_label' => $rule['limit_label'],
        'next_free_date' => $nextFreeDate,
        'next_free_label' => $nextFreeDate ? format_date_br($nextFreeDate) : 'Sem slot neste período',
        'peak_used' => $peakUsed,
        'peak_label' => $peakUsed > 0 ? sprintf('%d de %d slot(s) no pico', $peakUsed, $rule['limit']) : 'Nenhum evento na janela',
        'tooltip' => $nextFreeDate
            ? sprintf('Limite diário: %s. Próxima data livre: %s.', $rule['limit_label'], format_date_br($nextFreeDate))
            : sprintf('Limite diário: %s. Não há slot livre neste período.', $rule['limit_label']),
    ];
}

$windowLabel = format_date_br($period['data_inicio']) . ' a ' . format_date_br($period['data_fim']);
$sourceLabel = $source === 'database' ? 'Grade real' : 'Modo demonstração';
$sourceTone = $source === 'database' ? 'success' : 'warning';
$dayDetailBaseUrl = route_url('planejamento-dia', ['periodo_id' => $period['id']]);
$calendarEvents = [];

foreach ($items as $index => $item) {
    $itemId = isset($item['id']) ? (string) $item['id'] : 'mock-' . $index;
    $status = status_meta($item['status'] ?? 'planejado');
    $canMove = $source === 'database' && is_numeric($itemId) && (int) $itemId > 0;

    $calendarEvents[] = [
        'id' => $itemId,
        'title' => trim((string) ($item['title'] ?? 'Sem título')),
        'start' => (string) ($item['date'] ?? ''),
        'allDay' => true,
        'editable' => $canMove,
        'backgroundColor' => trim((string) ($item['channel_color'] ?? '#1E5B8F')),
        'borderColor' => trim((string) ($item['channel_color'] ?? '#1E5B8F')),
        'textColor' => '#ffffff',
        'classNames' => ['planner-event', 'planner-event--' . ($status['tone'] ?? 'info')],
        'extendedProps' => [
            'area' => trim((string) ($item['area'] ?? 'A definir')),
            'channel' => trim((string) ($item['channel'] ?? 'Canal não informado')),
            'statusLabel' => trim((string) ($status['label'] ?? 'Planejado')),
            'dayUrl' => route_url('planejamento-dia', [
                'periodo_id' => $period['id'],
                'date' => (string) ($item['date'] ?? ''),
            ]),
            'canMove' => $canMove,
        ],
    ];
}
?>

<section class="section-stack" id="planningCalendarPage"
    data-period-id="<?php echo safe((string) $period['id']); ?>"
    data-initial-date="<?php echo safe($focusedDate !== '' ? $focusedDate : $period['data_inicio']); ?>"
    data-period-start="<?php echo safe($period['data_inicio']); ?>"
    data-period-end="<?php echo safe($period['data_fim']); ?>"
    data-source="<?php echo safe($source); ?>"
    data-day-url-base="<?php echo safe($dayDetailBaseUrl); ?>"
    data-move-url="<?php echo safe(base_url() . '/api/grade/move-item.php'); ?>"
>
    <div class="planner-overview">
        <article class="surface-card planner-highlight">
            <span class="eyebrow">Competência ativa</span>
            <h2><?php echo safe($period['label']); ?></h2>
            <p>Calendário grande da grade com leitura diária, arraste entre dias e atalho para o detalhe hora a hora.</p>
        </article>
        <article class="surface-card planner-stat"><strong><?php echo safe($plannedCount); ?></strong><span>eventos dentro da grade</span></article>
        <article class="surface-card planner-stat"><strong><?php echo safe(count($criticalDaysMap)); ?></strong><span>dias no limite</span></article>
        <article class="surface-card planner-stat"><strong><?php echo safe(count($outsideItems)); ?></strong><span>fora da grade</span></article>
    </div>

    <article class="surface-card planner-summary-band">
        <div>
            <span class="eyebrow">Janela da grade</span>
            <h3><?php echo safe($windowLabel); ?></h3>
            <p>Clique em um dia para abrir o detalhe ou arraste um evento para remanejar a agenda dentro do período.</p>
        </div>
        <span class="status-badge <?php echo safe(tone_class($sourceTone)); ?>"><?php echo safe($sourceLabel); ?></span>
    </article>

    <script type="application/json" id="planningCalendarEvents"><?php echo json_encode($calendarEvents, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?></script>
</section>

<section class="planner-layout">
    <article class="surface-card calendar-shell">
        <div class="section-heading">
            <div>
                <span class="eyebrow">Visual mensal</span>
                <h3>Calendário da grade</h3>
            </div>
            <span class="meta-chip is-neutral">Arraste e solte</span>
        </div>

        <div class="planner-calendar-note">
            <span class="mini-badge is-info">Clique em um dia vazio para abrir o detalhe</span>
            <span class="mini-badge is-neutral">Eventos reais podem ser arrastados entre datas</span>
        </div>

        <div id="planningCalendar" class="planning-calendar"></div>
    </article>

    <aside class="planner-side">
        <article class="surface-card" id="grade-availability">
            <div class="section-heading">
                <div>
                    <span class="eyebrow">Limites por canal</span>
                    <h3>Próxima data livre</h3>
                </div>
            </div>

            <div class="planner-availability-list">
                <?php foreach ($channelAvailability as $availability): ?>
                    <div class="availability-row">
                        <div class="availability-row__copy">
                            <strong><?php echo safe($availability['name']); ?></strong>
                            <p><?php echo safe($availability['limit_label']); ?> • <?php echo safe($availability['peak_label']); ?></p>
                        </div>

                        <div class="availability-row__meta">
                            <button class="tooltip-chip" type="button" aria-label="Detalhes do limite de <?php echo safe($availability['name']); ?>">
                                <i class="bi bi-info-circle"></i>
                                <span class="tooltip-chip__content"><?php echo safe($availability['tooltip']); ?></span>
                            </button>
                            <span class="availability-date"><?php echo safe($availability['next_free_label']); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>

        <article class="surface-card">
            <div class="section-heading">
                <div>
                    <span class="eyebrow">Fora da grade</span>
                    <h3>Itens para triagem</h3>
                </div>
            </div>

            <?php if (!$outsideItems): ?>
                <div class="info-banner">
                    <i class="bi bi-check2-circle"></i>
                    <div>
                        <strong>Nada pendente</strong>
                        <p>Todos os eventos atuais cabem dentro da capacidade desta grade.</p>
                    </div>
                </div>
            <?php else: ?>
                <div class="stack-list">
                    <?php foreach ($outsideItems as $item): ?>
                        <?php $status = status_meta($item['status'] ?? 'planejado'); ?>
                        <article class="list-row compact">
                            <div>
                                <strong><?php echo safe($item['title']); ?></strong>
                                <p><?php echo safe($item['area']); ?> • <?php echo safe(format_date_br($item['date'])); ?></p>
                            </div>
                            <span class="status-badge <?php echo safe(tone_class($status['tone'])); ?>"><?php echo safe($status['label']); ?></span>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </article>
    </aside>
</section>
