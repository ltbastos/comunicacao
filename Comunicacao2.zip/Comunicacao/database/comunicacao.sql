SET NAMES utf8mb4;
SET time_zone = '-03:00';

CREATE DATABASE IF NOT EXISTS comunicacao_hub
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE comunicacao_hub;

CREATE TABLE IF NOT EXISTS usuarios_informados (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(150) NULL,
    email VARCHAR(180) NOT NULL,
    role ENUM('adm', 'analista') NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_usuarios_informados_email (email),
    KEY idx_usuarios_informados_nome (nome),
    KEY idx_usuarios_informados_role (role),
    KEY idx_usuarios_informados_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS areas_solicitantes (
    id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(120) NOT NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_areas_solicitantes_nome (nome),
    KEY idx_areas_solicitantes_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS canais_comunicacao (
    id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(120) NOT NULL,
    descricao VARCHAR(255) NULL,
    cor_badge CHAR(7) NOT NULL DEFAULT '#1E5B8F',
    icone VARCHAR(60) NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_canais_comunicacao_nome (nome),
    KEY idx_canais_comunicacao_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS periodos_grade (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(80) NOT NULL,
    ano SMALLINT UNSIGNED NOT NULL,
    mes TINYINT UNSIGNED NOT NULL,
    data_inicio DATE NOT NULL,
    data_fim DATE NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'aberto',
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_periodos_grade_ano_mes (ano, mes),
    KEY idx_periodos_grade_status (status),
    KEY idx_periodos_grade_data_inicio (data_inicio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS configuracoes_status (
    id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    chave VARCHAR(50) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(255) NULL,
    cor CHAR(7) NOT NULL,
    ordem SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    mostra_pipeline TINYINT(1) NOT NULL DEFAULT 1,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_configuracoes_status_chave (chave),
    KEY idx_configuracoes_status_ordem (ordem),
    KEY idx_configuracoes_status_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS status_solicitacoes (
    id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
    chave VARCHAR(30) NOT NULL,
    nome VARCHAR(60) NOT NULL,
    descricao VARCHAR(255) NULL,
    cor CHAR(7) NOT NULL DEFAULT '#0EA5E9',
    ordem TINYINT UNSIGNED NOT NULL DEFAULT 0,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_status_solicitacoes_chave (chave),
    KEY idx_status_solicitacoes_ordem (ordem),
    KEY idx_status_solicitacoes_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS prioridades (
    id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
    chave VARCHAR(30) NOT NULL,
    nome VARCHAR(60) NOT NULL,
    cor CHAR(7) NOT NULL,
    ordem TINYINT UNSIGNED NOT NULL DEFAULT 0,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_prioridades_chave (chave),
    KEY idx_prioridades_ordem (ordem),
    KEY idx_prioridades_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS grade_editorial (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    periodo_id INT UNSIGNED NOT NULL,
    titulo VARCHAR(180) NOT NULL,
    descricao TEXT NULL,
    area_id SMALLINT UNSIGNED NULL,
    canal_id SMALLINT UNSIGNED NOT NULL,
    tipo_demanda VARCHAR(100) NULL,
    data_prevista_publicacao DATE NOT NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'planejado',
    capacidade_slot TINYINT UNSIGNED NOT NULL DEFAULT 1,
    ordem_dia TINYINT UNSIGNED NOT NULL DEFAULT 1,
    dentro_capacidade TINYINT(1) NOT NULL DEFAULT 1,
    observacoes TEXT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_grade_editorial_periodo (periodo_id),
    KEY idx_grade_editorial_area (area_id),
    KEY idx_grade_editorial_canal (canal_id),
    KEY idx_grade_editorial_data (data_prevista_publicacao),
    KEY idx_grade_editorial_status (status),
    KEY idx_grade_editorial_periodo_data (periodo_id, data_prevista_publicacao),
    FULLTEXT KEY ftx_grade_editorial_titulo_descricao (titulo, descricao),
    CONSTRAINT fk_grade_editorial_periodo FOREIGN KEY (periodo_id) REFERENCES periodos_grade (id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_grade_editorial_area FOREIGN KEY (area_id) REFERENCES areas_solicitantes (id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_grade_editorial_canal FOREIGN KEY (canal_id) REFERENCES canais_comunicacao (id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS briefings (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    codigo VARCHAR(20) NOT NULL,
    titulo VARCHAR(180) NOT NULL,
    descricao_resumida TEXT NULL,
    objetivo TEXT NULL,
    contexto MEDIUMTEXT NULL,
    mensagem_principal MEDIUMTEXT NULL,
    publico_alvo VARCHAR(180) NULL,
    segmento VARCHAR(180) NULL,
    produto_tema VARCHAR(180) NULL,
    cta VARCHAR(255) NULL,
    tipo_demanda VARCHAR(100) NULL,
    canal_id SMALLINT UNSIGNED NULL,
    area_id SMALLINT UNSIGNED NULL,
    periodo_id INT UNSIGNED NULL,
    grade_id BIGINT UNSIGNED NULL,
    esta_na_grade TINYINT(1) NOT NULL DEFAULT 0,
    prioridade_id TINYINT UNSIGNED NOT NULL,
    status_id SMALLINT UNSIGNED NOT NULL,
    status_solicitacao_id TINYINT UNSIGNED NOT NULL DEFAULT 1,
    origem VARCHAR(30) NOT NULL DEFAULT 'solicitante',
    nome_solicitante VARCHAR(150) NULL,
    email_solicitante VARCHAR(180) NOT NULL,
    data_desejada_publicacao DATE NULL,
    prazo_limite DATETIME NULL,
    links_apoio MEDIUMTEXT NULL,
    observacoes_solicitante TEXT NULL,
    dados_formulario_json LONGTEXT NULL,
    responsavel_atual_nome VARCHAR(150) NULL,
    responsavel_atual_email VARCHAR(180) NULL,
    data_envio DATETIME NULL,
    data_publicacao DATETIME NULL,
    data_cancelamento DATETIME NULL,
    motivo_cancelamento TEXT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_briefings_codigo (codigo),
    KEY idx_briefings_status (status_id),
    KEY idx_briefings_status_solicitacao (status_solicitacao_id),
    KEY idx_briefings_prioridade (prioridade_id),
    KEY idx_briefings_area (area_id),
    KEY idx_briefings_canal (canal_id),
    KEY idx_briefings_periodo (periodo_id),
    KEY idx_briefings_grade (grade_id),
    KEY idx_briefings_email_solicitante (email_solicitante),
    KEY idx_briefings_responsavel_email (responsavel_atual_email),
    KEY idx_briefings_prazo_limite (prazo_limite),
    KEY idx_briefings_data_publicacao (data_publicacao),
    KEY idx_briefings_criado_em (criado_em),
    KEY idx_briefings_atraso (status_id, prazo_limite, data_publicacao),
    FULLTEXT KEY ftx_briefings_busca (titulo, descricao_resumida, objetivo, contexto, mensagem_principal),
    CONSTRAINT fk_briefings_canal FOREIGN KEY (canal_id) REFERENCES canais_comunicacao (id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_briefings_area FOREIGN KEY (area_id) REFERENCES areas_solicitantes (id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_briefings_periodo FOREIGN KEY (periodo_id) REFERENCES periodos_grade (id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_briefings_grade FOREIGN KEY (grade_id) REFERENCES grade_editorial (id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_briefings_prioridade FOREIGN KEY (prioridade_id) REFERENCES prioridades (id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_briefings_status FOREIGN KEY (status_id) REFERENCES configuracoes_status (id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_briefings_status_solicitacao FOREIGN KEY (status_solicitacao_id) REFERENCES status_solicitacoes (id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS briefing_canais (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    briefing_id BIGINT UNSIGNED NOT NULL,
    canal_id SMALLINT UNSIGNED NOT NULL,
    ordem TINYINT UNSIGNED NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_briefing_canais_briefing_canal (briefing_id, canal_id),
    KEY idx_briefing_canais_canal (canal_id),
    KEY idx_briefing_canais_ordem (ordem),
    CONSTRAINT fk_briefing_canais_briefing FOREIGN KEY (briefing_id) REFERENCES briefings (id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_briefing_canais_canal FOREIGN KEY (canal_id) REFERENCES canais_comunicacao (id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS briefing_movimentacoes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    briefing_id BIGINT UNSIGNED NOT NULL,
    tipo_movimento VARCHAR(40) NOT NULL DEFAULT 'status',
    status_anterior_id SMALLINT UNSIGNED NULL,
    status_novo_id SMALLINT UNSIGNED NULL,
    comentario_interno TEXT NULL,
    comentario_visivel TEXT NULL,
    dados_adicionais LONGTEXT NULL,
    nome_autor VARCHAR(150) NULL,
    email_autor VARCHAR(180) NOT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_briefing_movimentacoes_briefing (briefing_id),
    KEY idx_briefing_movimentacoes_criado_em (criado_em),
    KEY idx_briefing_movimentacoes_autor (email_autor),
    CONSTRAINT fk_movimentacoes_briefing FOREIGN KEY (briefing_id) REFERENCES briefings (id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_movimentacoes_status_anterior FOREIGN KEY (status_anterior_id) REFERENCES configuracoes_status (id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_movimentacoes_status_novo FOREIGN KEY (status_novo_id) REFERENCES configuracoes_status (id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS briefing_responsaveis (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    briefing_id BIGINT UNSIGNED NOT NULL,
    nome_responsavel VARCHAR(150) NOT NULL,
    email_responsavel VARCHAR(180) NOT NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    iniciado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    encerrado_em DATETIME NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_briefing_responsaveis_briefing (briefing_id),
    KEY idx_briefing_responsaveis_email (email_responsavel),
    KEY idx_briefing_responsaveis_ativo (ativo),
    CONSTRAINT fk_responsaveis_briefing FOREIGN KEY (briefing_id) REFERENCES briefings (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS briefing_anexos (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    briefing_id BIGINT UNSIGNED NOT NULL,
    nome_arquivo VARCHAR(180) NOT NULL,
    nome_original VARCHAR(255) NULL,
    caminho_arquivo VARCHAR(255) NOT NULL,
    extensao VARCHAR(20) NULL,
    mime_type VARCHAR(120) NULL,
    tamanho_bytes INT UNSIGNED NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_briefing_anexos_briefing (briefing_id),
    CONSTRAINT fk_anexos_briefing FOREIGN KEY (briefing_id) REFERENCES briefings (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dashboard_cache (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    chave VARCHAR(80) NOT NULL,
    valor_json MEDIUMTEXT NOT NULL,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_dashboard_cache_chave (chave)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO usuarios_informados (nome, email, role, ativo) VALUES
    ('Michelle Cristina', 'michelle.cristina@bradesco.com.br', 'adm', 1),
    ('Lua Bastos', 'lua.bastos@bradesco.com.br', 'adm', 1)
ON DUPLICATE KEY UPDATE
    nome = VALUES(nome),
    role = VALUES(role),
    ativo = VALUES(ativo);

INSERT INTO configuracoes_status (id, chave, nome, descricao, cor, ordem, mostra_pipeline, ativo) VALUES
    (1, 'rascunho', 'Rascunho', 'Preenchimento ainda nao enviado ao time de Comunicacao.', '#94A3B8', 1, 0, 1),
    (2, 'pendente_envio', 'Pendente de envio', 'Identificacao feita, mas ainda nao finalizado.', '#F59E0B', 2, 0, 1),
    (3, 'enviado', 'Enviado', 'Briefing enviado e aguardando triagem inicial.', '#0EA5E9', 3, 1, 1),
    (4, 'em_analise', 'Em analise', 'Time de Comunicacao avaliando escopo, contexto e viabilidade.', '#1E5B8F', 4, 1, 1),
    (5, 'com_pendencia', 'Com pendencia', 'Ha retorno ou informacao faltante para prosseguir.', '#7C3AED', 5, 1, 1),
    (6, 'aguardando_ajuste', 'Aguardando ajuste', 'Solicitante precisa complementar ou ajustar o briefing.', '#F59E0B', 6, 1, 1),
    (7, 'aprovado', 'Aprovado', 'Escopo validado para execucao.', '#16A34A', 7, 1, 1),
    (8, 'em_producao', 'Em producao', 'Peca ou entrega em desenvolvimento.', '#16B3C4', 8, 1, 1),
    (9, 'em_aprovacao', 'Em aprovacao', 'Material em rodada final de validacao.', '#1E5B8F', 9, 1, 1),
    (10, 'reagendado', 'Reagendado', 'Entrega reposicionada para outra janela de publicacao.', '#F59E0B', 10, 1, 1),
    (11, 'publicado', 'Publicado', 'Entrega publicada no canal definido.', '#16A34A', 11, 1, 1),
    (12, 'cancelado', 'Cancelado', 'Demanda encerrada sem publicacao.', '#DC2626', 12, 0, 1),
    (13, 'atrasado', 'Atrasado', 'Prazo vencido sem conclusao ou publicacao.', '#DC2626', 13, 1, 1)
ON DUPLICATE KEY UPDATE
    nome = VALUES(nome),
    descricao = VALUES(descricao),
    cor = VALUES(cor),
    ordem = VALUES(ordem),
    mostra_pipeline = VALUES(mostra_pipeline),
    ativo = VALUES(ativo);

INSERT INTO status_solicitacoes (id, chave, nome, descricao, cor, ordem, ativo) VALUES
    (1, 'aberto', 'Aberto', 'Solicitacao recebida e aberta para acompanhamento.', '#0EA5E9', 1, 1),
    (2, 'analisando', 'Analisando', 'Solicitacao em avaliacao pelo time responsavel.', '#F59E0B', 2, 1),
    (3, 'aprovado', 'Aprovado', 'Solicitacao aprovada para seguir no fluxo.', '#16A34A', 3, 1),
    (4, 'rejeitado', 'Rejeitado', 'Solicitacao nao aprovada para continuidade.', '#DC2626', 4, 1)
ON DUPLICATE KEY UPDATE
    nome = VALUES(nome),
    descricao = VALUES(descricao),
    cor = VALUES(cor),
    ordem = VALUES(ordem),
    ativo = VALUES(ativo);

INSERT INTO prioridades (id, chave, nome, cor, ordem, ativo) VALUES
    (1, 'baixa', 'Baixa', '#94A3B8', 1, 1),
    (2, 'media', 'Media', '#0EA5E9', 2, 1),
    (3, 'alta', 'Alta', '#F59E0B', 3, 1),
    (4, 'critica', 'Critica', '#DC2626', 4, 1)
ON DUPLICATE KEY UPDATE
    nome = VALUES(nome),
    cor = VALUES(cor),
    ordem = VALUES(ordem),
    ativo = VALUES(ativo);

INSERT INTO canais_comunicacao (id, nome, descricao, cor_badge, icone, ativo) VALUES
    (1, 'Intranet', 'Noticias, comunicados e paginas internas.', '#10324A', 'bi-display', 1),
    (2, 'E-mail Marketing', 'Disparos internos e campanhas de alto alcance.', '#1E5B8F', 'bi-envelope-paper', 1),
    (3, 'LinkedIn', 'Comunicacao institucional externa e employer branding.', '#0EA5E9', 'bi-linkedin', 1),
    (4, 'TV Corporativa', 'Paineis e telas internas para comunicacao visual.', '#16B3C4', 'bi-tv', 1),
    (5, 'Portal', 'Hub de conteudo, landing pages e agenda editorial.', '#7C3AED', 'bi-globe2', 1),
    (6, 'WhatsApp', 'Comunicados rapidos em grupos autorizados.', '#16A34A', 'bi-whatsapp', 1)
ON DUPLICATE KEY UPDATE
    descricao = VALUES(descricao),
    cor_badge = VALUES(cor_badge),
    icone = VALUES(icone),
    ativo = VALUES(ativo);

INSERT INTO canais_comunicacao (nome, descricao, cor_badge, icone, ativo) VALUES
    ('Mensagem da Diretoria', 'Comunicados institucionais assinados pela liderança.', '#10324A', 'bi-megaphone', 1),
    ('WhatsApp - Comunica PJ', 'Disparo rápido do fluxo Comunica PJ no WhatsApp.', '#16A34A', 'bi-whatsapp', 1),
    ('Post Viva Engage - Comunica PJ', 'Publicacao para jornada Viva Engage no fluxo PJ.', '#1E5B8F', 'bi-postcard', 1),
    ('E-mail MKT - Comunica PJ', 'Campanha de e-mail dedicada ao fluxo PJ.', '#0EA5E9', 'bi-envelope-paper-heart', 1),
    ('Banner Portal PJ', 'Banner interno para o portal PJ.', '#7C3AED', 'bi-window-sidebar', 1),
    ('Bom Dia PJ', 'Mensagem curta de abertura para a operacao PJ.', '#F59E0B', 'bi-sunrise', 1),
    ('Banner Home', 'Banner principal da home interna.', '#16B3C4', 'bi-house-door', 1),
    ('Banner Subhome MEI', 'Banner para a subhome de MEI.', '#16B3C4', 'bi-layout-sidebar', 1),
    ('Banner Subhome Plataforma PJ', 'Banner para a subhome Plataforma PJ.', '#16B3C4', 'bi-layout-sidebar-inset', 1),
    ('Banner Subhome Negócios', 'Banner para a subhome de Negócios.', '#16B3C4', 'bi-layout-text-sidebar', 1),
    ('Banner Subhome Empresas', 'Banner para a subhome de Empresas.', '#16B3C4', 'bi-layout-text-window', 1),
    ('Banner Corporativo', 'Peça visual institucional de circulação corporativa.', '#1E5B8F', 'bi-image', 1),
    ('Teams - Varejo Informa', 'Postagem ou aviso no canal Teams Varejo Informa.', '#5B5FC7', 'bi-microsoft-teams', 1),
    ('Comunica PJ - Teams', 'Comunicacao publicada no canal Teams do PJ.', '#5B5FC7', 'bi-microsoft-teams', 1),
    ('Conexão', 'Conteudo da editoria Conexao.', '#7C3AED', 'bi-diagram-3', 1),
    ('PODC', 'Conteudo de podcast ou audio editorial.', '#DC2626', 'bi-mic', 1),
    ('Vídeo', 'Conteudo em video para a grade.', '#0EA5E9', 'bi-camera-video', 1),
    ('Outros', 'Canal ou formato ainda nao classificado.', '#64748B', 'bi-three-dots', 1),
    ('Lives', 'Acao com transmissao ao vivo ou apoio a live.', '#DC2626', 'bi-broadcast', 1)
ON DUPLICATE KEY UPDATE
    descricao = VALUES(descricao),
    cor_badge = VALUES(cor_badge),
    icone = VALUES(icone),
    ativo = VALUES(ativo);

INSERT INTO areas_solicitantes (id, nome, ativo) VALUES
    (1, 'RH', 1),
    (2, 'Comercial', 1),
    (3, 'TI', 1),
    (4, 'Juridico', 1),
    (5, 'Financeiro', 1),
    (6, 'Presidencia', 1),
    (7, 'Sustentabilidade', 1)
ON DUPLICATE KEY UPDATE
    ativo = VALUES(ativo);

INSERT INTO areas_solicitantes (nome, ativo) VALUES
    ('ComunicaÃ§Ã£o PJ', 1),
    ('Produtos Empresas', 1),
    ('NegÃ³cios', 1),
    ('Plataforma PJ', 1),
    ('Digital MEI', 1),
    ('BU Empresas e NegÃ³cios', 1)
ON DUPLICATE KEY UPDATE
    ativo = VALUES(ativo);

INSERT INTO periodos_grade (id, nome, ano, mes, data_inicio, data_fim, status) VALUES
    (1, 'Abril 2026', 2026, 4, '2026-04-01', '2026-04-30', 'aberto'),
    (2, 'Maio 2026', 2026, 5, '2026-05-01', '2026-05-31', 'planejado')
ON DUPLICATE KEY UPDATE
    nome = VALUES(nome),
    data_inicio = VALUES(data_inicio),
    data_fim = VALUES(data_fim),
    status = VALUES(status);
