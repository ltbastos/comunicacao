document.addEventListener('DOMContentLoaded', () => {
    initThemeToggle();
    initRequesterSwitchModal();
    initHomeScreen();
    initBriefingLookup();
    initBriefingWizardPage();
    initGradeRequestFlow();
    initBriefingStatusControls();
    initGradeAdminQueueFilters();
    initGradeAdminCalendar();
    initPlanningCalendarPage();
    initSidebar();
    initCharts();
    initIdentity();
    initWizard();
    initViewSwitch();
    initDemoForms();
});

function initRequesterSwitchModal() {
    const roots = document.querySelectorAll('[data-requester-switch]');
    if (!roots.length) return;

    let activeModal = null;
    let activeTrigger = null;

    const hasOtherOpenModals = () => Boolean(document.querySelector('.grade-admin__modal.is-open, .requester-switch-modal.is-open'));

    const closeModal = (modal = activeModal, restoreFocus = true) => {
        if (!modal) return;

        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');

        if (activeModal === modal) {
            activeModal = null;
        }

        if (!hasOtherOpenModals()) {
            document.body.classList.remove('has-modal-open');
        }

        if (restoreFocus) {
            activeTrigger?.focus?.();
        }
    };

    const openModal = (modal, trigger) => {
        if (!modal) return;

        if (activeModal && activeModal !== modal) {
            closeModal(activeModal, false);
        }

        activeModal = modal;
        activeTrigger = trigger;
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('has-modal-open');
        modal.querySelector('button, input, select, textarea, a[href]')?.focus?.();
    };

    roots.forEach((root) => {
        const modal = root.querySelector('[data-requester-switch-modal]');
        const trigger = root.querySelector('[data-requester-switch-open]');

        trigger?.addEventListener('click', () => openModal(modal, trigger));

        modal?.querySelectorAll('[data-requester-switch-close]').forEach((control) => {
            control.addEventListener('click', () => closeModal(modal));
        });
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && activeModal) {
            closeModal(activeModal);
        }
    });
}

function initThemeToggle() {
    const toggle = document.getElementById('themeToggle');
    if (!toggle) return;

    const label = toggle.querySelector('.theme-toggle__label');

    const syncThemeUi = () => {
        const isLight = document.documentElement.classList.contains('theme-light');
        toggle.setAttribute('aria-pressed', isLight ? 'true' : 'false');

        if (label) {
            label.textContent = isLight ? 'Modo escuro' : 'Modo claro';
        }
    };

    toggle.addEventListener('click', () => {
        document.documentElement.classList.toggle('theme-light');

        try {
            const isLight = document.documentElement.classList.contains('theme-light');
            localStorage.setItem('comunicacao_theme', isLight ? 'light' : 'dark');
        } catch (error) {}

        syncThemeUi();
    });

    syncThemeUi();
}

function initSidebar() {
    const toggle = document.getElementById('sidebarToggle');
    if (!toggle) return;

    toggle.addEventListener('click', () => {
        document.body.classList.toggle('sidebar-open');
    });
}

function initHomeScreen() {
    const homeScreen = document.getElementById('homeScreen');
    if (!homeScreen) return;

    homeScreen.addEventListener('pointermove', (event) => {
        const rect = homeScreen.getBoundingClientRect();
        const x = ((event.clientX - rect.left) / rect.width) * 100;
        const y = ((event.clientY - rect.top) / rect.height) * 100;

        homeScreen.style.setProperty('--pointer-x', `${x}%`);
        homeScreen.style.setProperty('--pointer-y', `${y}%`);
    });
}

function initBriefingLookup() {
    const root = document.getElementById('briefingEntry');
    if (!root) return;

    const lookupUrl = root.dataset.lookupUrl;
    const createUrl = root.dataset.createUrl;
    const sessionEmail = (root.dataset.sessionEmail || '').trim().toLowerCase();
    const form = document.getElementById('briefingLookupForm');
    const emailInput = document.getElementById('briefingLookupEmail');
    const intro = document.getElementById('briefingIntro');
    const loading = document.getElementById('briefingLookupLoading');
    const loadingMessage = document.getElementById('briefingLookupLoadingMessage');
    const results = document.getElementById('briefingLookupResults');
    const heading = document.getElementById('briefingLookupHeading');
    const copy = document.getElementById('briefingLookupCopy');
    const emailPill = document.getElementById('briefingLookupEmailPill');
    const list = document.getElementById('briefingLookupList');
    const empty = document.getElementById('briefingLookupEmpty');
    const changeEmail = document.getElementById('briefingLookupChangeEmail');
    const createButton = document.getElementById('briefingLookupCreate');
    const query = new URLSearchParams(window.location.search);
    let currentLookupEmail = sessionEmail;

    const loadingMessages = [
        'Conferindo seus pedidos, prazos e atendimentos...',
        'Organizando a sua vitrine de pedidos...',
        'Quase lá. Só mais um instante...',
    ];

    let loadingMessageIndex = 0;
    let loadingInterval = null;

    const startLoading = () => {
        intro?.classList.add('is-hidden');
        results?.classList.add('is-hidden');
        loading?.classList.remove('is-hidden');

        if (loadingMessage) {
            loadingMessage.textContent = loadingMessages[0];
        }

        loadingInterval = window.setInterval(() => {
            loadingMessageIndex = (loadingMessageIndex + 1) % loadingMessages.length;
            if (loadingMessage) {
                loadingMessage.textContent = loadingMessages[loadingMessageIndex];
            }
        }, 850);
    };

    const stopLoading = () => {
        if (loadingInterval) {
            window.clearInterval(loadingInterval);
            loadingInterval = null;
        }
        loading?.classList.add('is-hidden');
        loadingMessageIndex = 0;
    };

    const resetToIntro = () => {
        stopLoading();
        results?.classList.remove('is-empty');
        results?.classList.add('is-hidden');
        intro?.classList.remove('is-hidden');
        currentLookupEmail = '';
        emailInput?.focus();
    };

    const renderResults = (payload) => {
        const pedidos = payload.pedidos || payload.briefings || [];
        const hasPedidos = pedidos.length > 0;
        currentLookupEmail = payload.email || '';

        if (heading) {
            heading.textContent = hasPedidos
                ? 'Pronto. Estes são os seus pedidos.'
                : 'Ainda não encontrei pedidos por aqui.';
        }

        if (copy) {
            copy.textContent = hasPedidos
                ? 'Aqui estão seus briefings e solicitações de grade com publicação, prazo, tema e atendimento.'
                : 'Sem estresse. Você pode começar um novo briefing ou abrir uma solicitação de grade pela página inicial.';
        }

        if (emailPill) {
            emailPill.innerHTML = `
                <i class="bi bi-envelope-paper"></i>
                <span>E-mail consultado: ${escapeHtml(payload.email)}</span>
            `;
        }

        if (list) {
            list.innerHTML = pedidos.map((briefing) => `
                <article class="briefing-entry__item">
                    <div class="briefing-entry__item-head">
                        <div>
                            <div class="briefing-entry__item-kicker">
                                <span class="briefing-entry__item-code">${escapeHtml(briefing.codigo)}</span>
                                <span class="briefing-entry__type">${escapeHtml(briefing.tipo_pedido?.label || 'Briefing')}</span>
                            </div>
                            <strong>${escapeHtml(briefing.tema)}</strong>
                        </div>
                        <span class="briefing-entry__status" style="background:${hexToRgba(briefing.status.cor, 0.18)}; color:${escapeHtml(briefing.status.cor)};">
                            ${escapeHtml(briefing.status.nome)}
                        </span>
                    </div>

                    <div class="briefing-entry__meta">
                        <div class="briefing-entry__meta-card">
                            <span>Publicação</span>
                            <strong>${escapeHtml(briefing.data_publicacao || 'A definir')}</strong>
                        </div>
                        <div class="briefing-entry__meta-card">
                            <span>Prazo limite</span>
                            <strong>${escapeHtml(briefing.prazo_limite || 'A definir')}</strong>
                        </div>
                        <div class="briefing-entry__meta-card">
                            <span>Tema</span>
                            <strong>${escapeHtml(briefing.titulo || briefing.tema)}</strong>
                        </div>
                        <div class="briefing-entry__meta-card">
                            <span>Atendimento</span>
                            <strong>${escapeHtml(briefing.atendimento || 'A definir')}</strong>
                        </div>
                    </div>

                    ${briefing.canais ? `
                        <div class="briefing-entry__item-aux">
                            <span>Canais</span>
                            <strong>${escapeHtml(briefing.canais)}</strong>
                        </div>
                    ` : ''}

                    ${briefing.can_edit ? `
                        <div class="briefing-entry__item-footer">
                            <a class="briefing-entry__item-action" href="${escapeHtml(briefing.edit_url || '#')}">
                                <span>${escapeHtml(briefing.edit_label || 'Editar pedido')}</span>
                                <i class="bi bi-pencil-square"></i>
                            </a>
                        </div>
                    ` : ''}
                </article>
            `).join('');
        }

        if (empty) {
            empty.classList.toggle('is-hidden', hasPedidos);
        }

        results?.classList.toggle('is-empty', !hasPedidos);
        results?.classList.remove('is-hidden');
    };

    const performLookup = async (email) => {
        if (!email) {
            showToast('Me diga seu e-mail para eu buscar suas demandas.', 'warning');
            return;
        }

        startLoading();

        try {
            const response = await fetch(lookupUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                },
                body: new URLSearchParams({ email }).toString(),
            });

            const payload = await response.json();
            stopLoading();

            if (!response.ok || !payload.ok) {
                showToast(payload.message || 'Não consegui buscar seus pedidos agora.', 'warning');
                resetToIntro();
                return;
            }

            renderResults(payload);
        } catch (error) {
            stopLoading();
            resetToIntro();
            showToast('Tive um problema ao buscar seus pedidos. Tente novamente.', 'warning');
        }
    };

    form?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const email = (emailInput?.value || '').trim().toLowerCase();
        await performLookup(email);
    });

    changeEmail?.addEventListener('click', () => {
        resetToIntro();
    });

    createButton?.addEventListener('click', () => {
        const target = new URL(createUrl, window.location.origin);

        window.location.href = `${target.pathname}${target.search}`;
    });

    const submitted = query.get('submitted') || '';
    if (submitted === 'draft') {
        showToast('Rascunho salvo direitinho.', 'success');
    } else if (submitted === 'send') {
        showToast('Briefing enviado. Agora ele já aparece nos seus pedidos.', 'success');
    } else if (submitted === 'updated') {
        showToast('Mudanças aplicadas com sucesso.', 'success');
    } else if (submitted === 'grade') {
        showToast('Solicitação de grade enviada. Agora ela já aparece nos seus pedidos.', 'success');
    }

    if (submitted || query.get('codigo') || query.get('email')) {
        const nextUrl = new URL(window.location.href);
        nextUrl.searchParams.delete('submitted');
        nextUrl.searchParams.delete('codigo');
        nextUrl.searchParams.delete('email');
        window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
    }

    if (sessionEmail) {
        if (emailInput && !emailInput.value) {
            emailInput.value = sessionEmail;
        }

        performLookup(sessionEmail);
    }
}

function initBriefingWizardPage() {
    const root = document.getElementById('briefingWizardPage');
    if (!root) return;

    const submitUrl = root.dataset.submitUrl;
    const form = document.getElementById('briefingWizardForm');
    const panels = [...root.querySelectorAll('[data-briefing-step-panel]')];
    const triggers = [...root.querySelectorAll('[data-briefing-step-trigger]')];
    const prevButton = root.querySelector('[data-briefing-prev]');
    const nextButton = root.querySelector('[data-briefing-next]');
    const saveButton = root.querySelector('[data-briefing-save]');
    const sendButton = root.querySelector('[data-briefing-send]');
    const stepLabel = document.getElementById('briefingWizardStepLabel');
    const stepTitle = document.getElementById('briefingWizardStepTitle');
    const progressBar = document.getElementById('briefingWizardProgressBar');
    const review = document.getElementById('briefingWizardReview');
    const emailField = document.getElementById('briefingWizardEmail');
    const nameField = document.getElementById('briefingWizardName');
    const modeField = document.getElementById('briefingWizardMode');
    const filesInput = document.getElementById('briefingWizardFiles');
    const filesList = document.getElementById('briefingWizardFilesList');

    if (!form || !panels.length || !modeField) return;

    const prefillEmail = (root.dataset.prefillEmail || '').trim().toLowerCase();
    const prefillName = (root.dataset.prefillName || '').trim();
    const requiresChangesBeforeApply = root.dataset.briefingRequiresChanges === '1';

    if (emailField && prefillEmail && !emailField.value) {
        emailField.value = prefillEmail;
    }

    if (nameField && prefillName && !nameField.value) {
        nameField.value = prefillName;
    }

    const stepFieldMap = {
        titulo: 1,
        email_solicitante: 1,
        area_id: 1,
        data_desejada_publicacao: 1,
        produto_tema: 1,
        'canais[]': 2,
        'publicos_alvo[]': 2,
        objetivo: 3,
        contexto: 3,
        prioridade_id: 3,
        mensagem_principal: 4,
        sugestao_texto: 4,
        descricao_resumida: 4,
    };

    const reviewSections = [
        {
            title: 'Planejamento e identificação',
            fields: ['esta_na_grade', 'data_desejada_publicacao', 'area_id', 'nome_solicitante', 'email_solicitante', 'produto_tema', 'titulo'],
        },
        {
            title: 'Canais e público',
            fields: ['canais[]', 'publicos_alvo[]', 'classificacao_comunicacao[]', 'somos_tags[]'],
        },
        {
            title: 'Contexto e direcionamento',
            fields: ['contexto', 'objetivo', 'change_flag', 'change_iniciativa', 'identidade_visual_existente', 'tipos_comunicacao[]', 'prioridade_id', 'cta'],
        },
        {
            title: 'Conteúdo da peça',
            fields: ['mensagem_principal', 'acao_gerente', 'sugestao_texto', 'descricao_resumida'],
        },
        {
            title: 'Complementos',
            fields: ['link_local', 'link_destino', 'onde_saber_mais', 'validade_ate', 'observacoes_solicitante', 'links_apoio'],
        },
    ];

    let currentStep = 1;
    let initialFormSnapshot = '';

    const formSnapshot = () => {
        const formData = new FormData(form);
        formData.delete('mode');

        return JSON.stringify([...formData.entries()].map(([name, value]) => {
            if (value instanceof File) {
                return [name, value.name ? `${value.name}:${value.size}:${value.lastModified}` : ''];
            }

            return [name, String(value)];
        }));
    };

    const hasFormChanges = () => formSnapshot() !== initialFormSnapshot;

    const syncEditingSubmitState = () => {
        if (!requiresChangesBeforeApply || !sendButton) return;

        const hasChanges = hasFormChanges();
        sendButton.disabled = !hasChanges;
        sendButton.classList.toggle('is-disabled', !hasChanges);
        sendButton.title = hasChanges ? '' : 'Faça uma alteração para aplicar mudanças.';
    };

    const renderSelectedFiles = () => {
        if (!filesInput || !filesList) return;

        const files = [...(filesInput.files || [])];
        filesList.innerHTML = files.map((file) => `
            <div class="briefing-wizard__file-item">
                <i class="bi bi-paperclip"></i>
                <span>${escapeHtml(file.name)}</span>
                <small>${formatFileSize(file.size)}</small>
            </div>
        `).join('');

        filesList.classList.toggle('is-hidden', files.length === 0);
    };

    const syncWizard = () => {
        panels.forEach((panel) => {
            panel.classList.toggle('is-active', Number(panel.dataset.briefingStepPanel) === currentStep);
        });

        triggers.forEach((trigger) => {
            trigger.classList.toggle('is-active', Number(trigger.dataset.briefingStepTrigger) === currentStep);
        });

        if (prevButton) {
            prevButton.disabled = currentStep === 1;
        }

        if (nextButton) {
            nextButton.classList.toggle('is-hidden', currentStep === panels.length);
        }

        if (sendButton) {
            sendButton.classList.toggle('is-hidden', currentStep !== panels.length);
        }

        syncEditingSubmitState();

        const activePanel = panels[currentStep - 1];

        if (stepLabel) {
            stepLabel.textContent = `Etapa ${currentStep} de ${panels.length}`;
        }

        if (stepTitle && activePanel) {
            stepTitle.textContent = activePanel.dataset.briefingStepTitle || '';
        }

        if (progressBar) {
            progressBar.style.width = `${(currentStep / panels.length) * 100}%`;
        }

        if (currentStep === panels.length) {
            buildReview();
        }
    };

    const validatePanel = (step) => {
        const panel = panels[step - 1];
        if (!panel) return true;

        const requiredFields = [...panel.querySelectorAll('[required]')];
        for (const field of requiredFields) {
            const value = getFieldValue(form, field.name);
            const isEmpty = Array.isArray(value) ? value.length === 0 : !value;
            if (isEmpty) {
                field.reportValidity();
                return false;
            }

            if (typeof field.checkValidity === 'function' && !field.checkValidity()) {
                field.reportValidity();
                return false;
            }
        }

        const requiredGroups = [...panel.querySelectorAll('[data-required-group]')];
        for (const group of requiredGroups) {
            const fieldName = group.dataset.requiredGroup;
            const label = group.dataset.requiredLabel || 'este grupo';
            const value = getFieldValue(form, fieldName);
            const isEmpty = Array.isArray(value) ? value.length === 0 : !value;

            if (isEmpty) {
                showToast(`Faltou marcar ${label}.`, 'warning');
                return false;
            }
        }

        return true;
    };

    const validateForSend = () => {
        const requiredFields = [
            ['titulo', 'título da demanda'],
            ['email_solicitante', 'e-mail do solicitante'],
            ['area_id', 'área solicitante'],
            ['data_desejada_publicacao', 'data da publicação'],
            ['produto_tema', 'assunto / tema / ação'],
            ['objetivo', 'objetivo da comunicação'],
            ['contexto', 'histórico do assunto'],
            ['prioridade_id', 'prioridade'],
            ['mensagem_principal', 'mensagem principal'],
            ['sugestao_texto', 'sugestão de texto'],
            ['descricao_resumida', 'descrição resumida'],
            ['canais[]', 'ao menos um canal desejado'],
            ['publicos_alvo[]', 'ao menos um público-alvo'],
        ];

        for (const [name, label] of requiredFields) {
            const value = getFieldValue(form, name);
            const isEmpty = Array.isArray(value) ? value.length === 0 : !value;
            if (isEmpty) {
                currentStep = stepFieldMap[name] || 1;
                syncWizard();
                const field = form.elements.namedItem(name);
                if (field && typeof field.reportValidity === 'function') {
                    field.reportValidity();
                }
                showToast(`Faltou preencher ${label}.`, 'warning');
                return false;
            }
        }

        const email = getFieldValue(form, 'email_solicitante');
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            currentStep = 1;
            syncWizard();
            const field = form.elements.namedItem('email_solicitante');
            if (field && typeof field.reportValidity === 'function') {
                field.reportValidity();
            }
            showToast('Me passa um e-mail válido para continuar.', 'warning');
            return false;
        }

        const publicationDateField = form.elements.namedItem('data_desejada_publicacao');
        if (publicationDateField && typeof publicationDateField.checkValidity === 'function' && !publicationDateField.checkValidity()) {
            currentStep = 1;
            syncWizard();
            publicationDateField.reportValidity();
            showToast('Escolha uma data de publicação de hoje em diante.', 'warning');
            return false;
        }

        const validityDateField = form.elements.namedItem('validade_ate');
        if (validityDateField && validityDateField.value && typeof validityDateField.checkValidity === 'function' && !validityDateField.checkValidity()) {
            currentStep = 5;
            syncWizard();
            validityDateField.reportValidity();
            showToast('A validade precisa ser hoje ou uma data futura.', 'warning');
            return false;
        }

        return true;
    };

    const buildReview = () => {
        if (!review) return;

        review.innerHTML = reviewSections.map((section) => `
            <article class="briefing-wizard__review-card">
                <strong>${escapeHtml(section.title)}</strong>
                <div class="briefing-wizard__review-list">
                    ${section.fields.map((fieldName) => `
                        <div class="briefing-wizard__review-item">
                            <span>${escapeHtml(getFieldLabel(form, fieldName))}</span>
                            <p>${formatReviewValue(getFieldDisplayValue(form, fieldName))}</p>
                        </div>
                    `).join('')}
                </div>
            </article>
        `).join('');
    };

    const submitWizard = async (mode) => {
        modeField.value = mode;

        if (mode === 'send' && !validateForSend()) {
            return;
        }

        if (mode === 'send' && requiresChangesBeforeApply && !hasFormChanges()) {
            syncEditingSubmitState();
            showToast('Faça uma alteração antes de aplicar mudanças.', 'warning');
            return;
        }

        const buttons = [prevButton, nextButton, saveButton, sendButton].filter(Boolean);
        buttons.forEach((button) => {
            button.disabled = true;
        });

        try {
            const formData = new FormData(form);
            const response = await fetch(submitUrl, {
                method: 'POST',
                body: formData,
            });

            const payload = await response.json();

            if (!response.ok || !payload.ok) {
                showToast(payload.message || 'Não consegui salvar o briefing agora.', 'warning');
                return;
            }

            if (mode === 'send' && !requiresChangesBeforeApply) {
                await playBriefingSentCelebration();
            }

            window.location.href = (mode === 'send' && requiresChangesBeforeApply)
                ? (root.dataset.backUrl || payload.redirect_url)
                : (payload.redirect_url || root.dataset.backUrl);
        } catch (error) {
            showToast('Tive um problema ao salvar. Vamos tentar de novo?', 'warning');
        } finally {
            buttons.forEach((button) => {
                button.disabled = false;
            });
        }
    };

    triggers.forEach((trigger) => {
        trigger.addEventListener('click', () => {
            const targetStep = Number(trigger.dataset.briefingStepTrigger);
            if (targetStep > currentStep && !validatePanel(currentStep)) {
                return;
            }

            currentStep = targetStep;
            syncWizard();
        });
    });

    nextButton?.addEventListener('click', () => {
        if (!validatePanel(currentStep)) {
            return;
        }

        currentStep = Math.min(currentStep + 1, panels.length);
        syncWizard();
    });

    prevButton?.addEventListener('click', () => {
        currentStep = Math.max(currentStep - 1, 1);
        syncWizard();
    });

    saveButton?.addEventListener('click', () => {
        submitWizard('draft');
    });

    sendButton?.addEventListener('click', () => {
        buildReview();
        submitWizard('send');
    });

    form.addEventListener('input', () => {
        if (currentStep === panels.length) {
            buildReview();
        }

        syncEditingSubmitState();
    });

    form.addEventListener('change', () => {
        if (currentStep === panels.length) {
            buildReview();
        }

        syncEditingSubmitState();
    });

    filesInput?.addEventListener('change', () => {
        renderSelectedFiles();
        syncEditingSubmitState();
    });

    applyFutureOnlyDateFields(root);
    syncWizard();
    renderSelectedFiles();
    initialFormSnapshot = formSnapshot();
    syncEditingSubmitState();
}

function initGradeRequestFlow() {
    const root = document.getElementById('gradeRequestPage');
    if (!root) return;

    const initialOperatorPayload = root.dataset.currentOperator || 'null';
    const initialRequesterPayload = root.dataset.currentRequester || 'null';
    const createPeriodUrl = root.dataset.createPeriodUrl;
    const submitUrl = root.dataset.submitUrl;
    const identity = document.getElementById('gradeRequestIdentity');
    const identityForm = document.getElementById('gradeRequestIdentityForm');
    const lookupEmailField = document.getElementById('gradeRequestLookupEmail');
    const flow = document.getElementById('gradeRequestFlow');
    const operatorCard = document.getElementById('gradeRequestOperatorCard');
    const operatorName = document.getElementById('gradeRequestOperatorName');
    const operatorEmail = document.getElementById('gradeRequestOperatorEmail');
    const operatorRole = document.getElementById('gradeRequestOperatorRole');
    const requesterName = document.getElementById('gradeRequestRequesterName');
    const requesterEmail = document.getElementById('gradeRequestRequesterEmail');
    const adminCard = document.getElementById('gradeRequestAdminCard');
    const periodForm = document.getElementById('gradeRequestPeriodForm');
    const periodSubmitButton = document.getElementById('gradeRequestPeriodSubmit');
    const periodResultCard = document.getElementById('gradeRequestPeriodResultCard');
    const periodResultTitle = document.getElementById('gradeRequestPeriodResultTitle');
    const periodResultCopy = document.getElementById('gradeRequestPeriodResultCopy');
    const form = document.getElementById('gradeRequestForm');
    const panels = [...root.querySelectorAll('[data-grade-step-panel]')];
    const triggers = [...root.querySelectorAll('[data-grade-step-trigger]')];
    const prevButton = root.querySelector('[data-grade-prev]');
    const nextButton = root.querySelector('[data-grade-next]');
    const finishButton = root.querySelector('[data-grade-finish]');
    const resetButton = root.querySelector('[data-grade-reset]');
    const stepLabel = document.getElementById('gradeRequestStepLabel');
    const stepTitle = document.getElementById('gradeRequestStepTitle');
    const progressBar = document.getElementById('gradeRequestProgressBar');
    const review = document.getElementById('gradeRequestReview');
    const emailField = document.getElementById('gradeRequestEmail');
    const nameField = document.getElementById('gradeRequestName');

    if (!form || !panels.length) return;

    applyFutureOnlyDateFields(root);

    let channelLimits = {};
    let gradePeriods = [];
    let gradeCapacity = {};

    try {
        channelLimits = JSON.parse(root.dataset.channelLimits || '{}');
    } catch (error) {
        channelLimits = {};
    }

    try {
        gradePeriods = JSON.parse(root.dataset.gradePeriods || '[]')
            .filter((period) => period && period.data_inicio && period.data_fim);
    } catch (error) {
        gradePeriods = [];
    }

    try {
        gradeCapacity = JSON.parse(root.dataset.gradeCapacity || '{}') || {};
    } catch (error) {
        gradeCapacity = {};
    }

    const reviewSections = [
        {
            title: 'Ciclo e entrada',
            fields: ['ciclo_referencia', 'data_solicitacao', 'data_abertura_ciclo', 'data_fechamento_ciclo', 'nome_solicitante', 'email_solicitante'],
        },
        {
            title: 'Cadastro da solicitação',
            fields: ['tema_assunto', 'justificativa_tema', 'publicos_alvo[]', 'canais[]', 'data_publicacao_sugerida', 'classificacao_assunto', 'responsavel_tema', 'area_responsavel_tema', 'classificacao_demanda', 'grau_necessidade'],
        },
        {
            title: 'Análise e grade final',
            fields: ['status_analise', 'data_publicacao_final', 'canal_principal', 'canais_aprovados[]', 'responsavel_atendimento', 'parecer_analise'],
        },
    ];

    const entryTargets = [
        { cardId: 'gradeRequestEntryTypeCard', valueId: 'gradeRequestEntryType', copyId: 'gradeRequestEntryCopy' },
        { cardId: 'gradeRequestAnalysisEntryCard', valueId: 'gradeRequestAnalysisEntryType', copyId: 'gradeRequestAnalysisEntryCopy' },
        { cardId: 'gradeRequestFinalEntryCard', valueId: 'gradeRequestFinalEntryType', copyId: 'gradeRequestFinalEntryCopy' },
    ];

    const deadlineTargets = [
        { cardId: 'gradeRequestDeadlineCard', valueId: 'gradeRequestBriefingDeadline', copyId: 'gradeRequestDeadlineCopy' },
        { cardId: 'gradeRequestFinalDeadlineCard', valueId: 'gradeRequestFinalDeadline', copyId: 'gradeRequestFinalDeadlineCopy' },
    ];

    const lockTargets = [
        { cardId: 'gradeRequestLockCard', valueId: 'gradeRequestLockState', copyId: 'gradeRequestLockCopy' },
        { cardId: 'gradeRequestFinalLockCard', valueId: 'gradeRequestFinalLockState', copyId: 'gradeRequestFinalLockCopy' },
    ];

    let currentStep = 1;
    let currentOperator = null;
    let currentRequester = null;

    const roleLabels = {
        adm: 'ADM',
        analista: 'Analista',
    };

    const syncRequesterFields = () => {
        if (!nameField || !emailField) {
            return;
        }

        const requester = currentOperator || currentRequester;

        if (!requester) {
            nameField.value = '';
            emailField.value = '';

            if (requesterName) {
                requesterName.textContent = 'Aguardando identificação interna';
            }

            if (requesterEmail) {
                requesterEmail.textContent = 'O nome e o e-mail vêm do cadastro do usuário interno.';
            }

            return;
        }

        const displayName = requester.nome || requester.email;
        nameField.value = displayName;
        emailField.value = requester.email;

        if (requesterName) {
            requesterName.textContent = displayName;
        }

        if (requesterEmail) {
            requesterEmail.textContent = requester.email;
        }
    };

    const normalizeOperator = (payload) => {
        if (!payload || typeof payload !== 'object') {
            return null;
        }

        const role = String(payload.role || '').trim();
        const email = String(payload.email || '').trim().toLowerCase();
        const name = String(payload.nome || '').trim();

        if (!email || !['adm', 'analista'].includes(role)) {
            return null;
        }

        return { role, email, nome: name };
    };

    const normalizeRequester = (payload) => {
        if (!payload || typeof payload !== 'object') {
            return null;
        }

        const email = String(payload.email || '').trim().toLowerCase();
        const name = String(payload.nome || '').trim();

        if (!email) {
            return null;
        }

        return { email, nome: name };
    };

    const syncOperatorUi = () => {
        const hasOperator = Boolean(currentOperator);

        operatorCard?.classList.toggle('is-hidden', !hasOperator);

        if (!hasOperator) {
            adminCard?.classList.add('is-hidden');
            operatorRole?.classList.remove('is-danger', 'is-info');
            operatorRole?.classList.add('is-neutral');
            syncRequesterFields();
            return;
        }

        if (operatorName) {
            operatorName.textContent = currentOperator.nome || currentOperator.email;
        }

        if (operatorEmail) {
            operatorEmail.textContent = `${currentOperator.email} • perfil interno carregado para esta sessão.`;
        }

        if (operatorRole) {
            operatorRole.textContent = roleLabels[currentOperator.role] || currentOperator.role;
            operatorRole.classList.remove('is-neutral', 'is-danger', 'is-info');
            operatorRole.classList.add(currentOperator.role === 'adm' ? 'is-danger' : 'is-info');
        }

        adminCard?.classList.toggle('is-hidden', currentOperator.role !== 'adm');
        syncRequesterFields();
    };

    const applyCardState = (targets, state) => {
        targets.forEach(({ cardId, valueId, copyId }) => {
            const card = document.getElementById(cardId);
            const value = document.getElementById(valueId);
            const copy = document.getElementById(copyId);

            if (card) {
                card.dataset.tone = state.tone || 'neutral';
            }

            if (value) {
                value.textContent = state.label;
            }

            if (copy) {
                copy.textContent = state.copy;
            }
        });
    };

    const renderLimitList = (listId, emptyId, channels) => {
        const list = document.getElementById(listId);
        const empty = document.getElementById(emptyId);

        if (!list || !empty) return;

        const uniqueChannels = [...new Set(channels.filter(Boolean))];

        if (!uniqueChannels.length) {
            list.innerHTML = '';
            empty.classList.remove('is-hidden');
            return;
        }

        list.innerHTML = uniqueChannels.map((channel) => `
            <article class="grade-request__limit-item">
                <strong>${escapeHtml(channel)}</strong>
                <span>Limite diário: ${escapeHtml(channelLimits[channel] || 'Sem limite parametrizado')}</span>
            </article>
        `).join('');

        empty.classList.add('is-hidden');
    };

    const resolveEntryStateLegacy = () => {
        const requestDate = getFieldValue(form, 'data_solicitacao');
        const openingDate = getFieldValue(form, 'data_abertura_ciclo');
        const closingDate = getFieldValue(form, 'data_fechamento_ciclo');

        if (!requestDate || !openingDate || !closingDate) {
            return {
                label: 'Aguardando janela',
                copy: 'Defina abertura e fechamento para classificar a solicitação.',
                tone: 'neutral',
            };
        }

        if (requestDate < openingDate) {
            return {
                label: 'Aguardando abertura',
                copy: 'A solicitação foi posicionada antes da abertura do ciclo. Ajuste a janela para liberar a entrada.',
                tone: 'warning',
            };
        }

        if (requestDate > closingDate) {
            return {
                label: 'Encaixe',
                copy: 'Cadastro após o corte: a demanda entra automaticamente como encaixe.',
                tone: 'critical',
            };
        }

        return {
            label: 'Grade perfeita',
            copy: 'Solicitação dentro da janela: a demanda segue como grade perfeita.',
            tone: 'success',
        };
    };

    const resolveCutoffStateLegacy = () => {
        const requestDate = getFieldValue(form, 'data_solicitacao');
        const openingDate = getFieldValue(form, 'data_abertura_ciclo');
        const closingDate = getFieldValue(form, 'data_fechamento_ciclo');

        if (!openingDate || !closingDate) {
            return {
                label: 'Janela não configurada',
                copy: 'Sem datas ainda, então a regra de corte continua pendente.',
                tone: 'neutral',
            };
        }

        if (requestDate && requestDate < openingDate) {
            return {
                label: 'Ciclo ainda não abriu',
                copy: `Abertura em ${formatDateLabel(openingDate)} e fechamento em ${formatDateLabel(closingDate)}.`,
                tone: 'warning',
            };
        }

        if (requestDate && requestDate > closingDate) {
            return {
                label: 'Janela encerrada',
                copy: `Fechamento registrado em ${formatDateLabel(closingDate)}. Tudo o que entrar depois vira encaixe.`,
                tone: 'critical',
            };
        }

        return {
            label: 'Janela aberta',
            copy: `Abertura em ${formatDateLabel(openingDate)} e fechamento em ${formatDateLabel(closingDate)}.`,
            tone: 'success',
        };
    };

    const periodIsClosed = (period) => {
        const status = String(period?.status || '').trim().toLowerCase();
        return ['finalizado', 'finalizada', 'fechado', 'fechada'].includes(status);
    };

    const getScheduledPublicationDate = () => (
        getFieldValue(form, 'data_publicacao_final')
        || getFieldValue(form, 'data_publicacao_sugerida')
    );

    const findPeriodForDate = (date) => {
        if (!date) return null;

        return gradePeriods.find((period) => (
            date >= String(period.data_inicio || '')
            && date <= String(period.data_fim || '')
        )) || null;
    };

    const channelLimitValue = (channel) => {
        const rawLimit = String(channelLimits[channel] || '1 por dia');
        const match = rawLimit.match(/\d+/);

        return match ? Math.max(1, Number(match[0])) : 1;
    };

    const channelUsedOnDate = (period, channel, date) => {
        const periodKey = String(period?.id || '');

        return Number(gradeCapacity?.[periodKey]?.[channel]?.[date] || 0);
    };

    const isBusinessDayValue = (date) => {
        const parsed = parseIsoDate(date);

        if (!parsed) return false;

        const day = parsed.getDay();
        return day >= 1 && day <= 5;
    };

    const nextFreeCapacityDate = (period, channel, startDate) => {
        let cursor = String(startDate || period?.data_inicio || '');
        const end = String(period?.data_fim || '');
        const limit = channelLimitValue(channel);

        while (cursor && end && cursor <= end) {
            if (isBusinessDayValue(cursor) && channelUsedOnDate(period, channel, cursor) < limit) {
                return cursor;
            }

            cursor = addOneDay(cursor);
        }

        return '';
    };

    const resolveCapacityState = () => {
        const scheduledDate = getScheduledPublicationDate();
        const matchedPeriod = findPeriodForDate(scheduledDate);

        if (!scheduledDate || !matchedPeriod || periodIsClosed(matchedPeriod)) {
            return { ok: true };
        }

        const requestedChannels = getFieldValue(form, 'canais[]');
        const approvedChannels = getFieldValue(form, 'canais_aprovados[]');
        const channels = [...new Set((approvedChannels.length ? approvedChannels : requestedChannels).filter(Boolean))];

        for (const channel of channels) {
            const limit = channelLimitValue(channel);

            if (channelUsedOnDate(matchedPeriod, channel, scheduledDate) >= limit) {
                const nextDate = nextFreeCapacityDate(matchedPeriod, channel, scheduledDate);

                return {
                    ok: false,
                    channel,
                    date: scheduledDate,
                    nextDate,
                    message: nextDate
                        ? `${channel} ja atingiu o limite em ${formatDateLabel(scheduledDate)}. Proxima data livre: ${formatDateLabel(nextDate)}.`
                        : `${channel} ja atingiu o limite em ${formatDateLabel(scheduledDate)} e nao ha outra data livre nesta grade.`,
                };
            }
        }

        return { ok: true };
    };

    const syncCapacityValidity = () => {
        const capacityState = resolveCapacityState();
        const scheduledDate = getScheduledPublicationDate();
        const message = capacityState.ok ? '' : capacityState.message;

        ['data_publicacao_sugerida', 'data_publicacao_final'].forEach((fieldName) => {
            const field = form.elements.namedItem(fieldName);

            if (!field || typeof field.setCustomValidity !== 'function') {
                return;
            }

            field.setCustomValidity(field.value && field.value === scheduledDate ? message : '');
        });
    };

    const syncMatchedPeriodFields = () => {
        const scheduledDate = getScheduledPublicationDate();
        const matchedPeriod = scheduledDate ? findPeriodForDate(scheduledDate) : null;
        const cycleField = form.elements.namedItem('ciclo_referencia');
        const openingField = form.elements.namedItem('data_abertura_ciclo');
        const closingField = form.elements.namedItem('data_fechamento_ciclo');

        if (!scheduledDate) {
            return;
        }

        if (cycleField && matchedPeriod?.data_inicio) {
            cycleField.value = String(matchedPeriod.data_inicio).slice(0, 7);
        }

        if (openingField) {
            openingField.value = matchedPeriod?.data_inicio || '';
        }

        if (closingField) {
            closingField.value = matchedPeriod?.data_fim || '';
        }
    };

    const resolveEntryState = () => {
        const scheduledDate = getScheduledPublicationDate();
        const matchedPeriod = findPeriodForDate(scheduledDate);

        if (!scheduledDate) {
            return {
                label: 'Aguardando data',
                copy: 'Informe a data de publicacao para classificar a solicitacao.',
                tone: 'neutral',
            };
        }

        if (matchedPeriod && periodIsClosed(matchedPeriod)) {
            return {
                label: 'Encaixe',
                copy: `A grade ${matchedPeriod.nome || ''} ja foi fechada. Novas entradas ficam como encaixe.`,
                tone: 'warning',
            };
        }

        if (!matchedPeriod) {
            return {
                label: 'Encaixe',
                copy: 'Data fora das grades abertas: a solicitacao entra automaticamente como encaixe.',
                tone: 'critical',
            };
        }

        return {
            label: 'Perfeita',
            copy: `Data dentro da grade ${matchedPeriod.nome || ''}: a demanda segue como Perfeita.`,
            tone: 'success',
        };
    };

    const resolveCutoffState = () => {
        const scheduledDate = getScheduledPublicationDate();
        const matchedPeriod = findPeriodForDate(scheduledDate);

        if (!scheduledDate) {
            return {
                label: 'Janela nao configurada',
                copy: 'Escolha a data de publicacao para localizar a grade correspondente.',
                tone: 'neutral',
            };
        }

        if (!matchedPeriod) {
            return {
                label: 'Fora da janela',
                copy: 'Nao existe grade aberta cobrindo esta data. O pedido sera salvo como encaixe.',
                tone: 'critical',
            };
        }

        if (periodIsClosed(matchedPeriod)) {
            return {
                label: 'Grade fechada',
                copy: `${matchedPeriod.nome || 'Grade'} ja foi finalizada. Novos pedidos entram como encaixe.`,
                tone: 'warning',
            };
        }

        const capacityState = resolveCapacityState();

        if (!capacityState.ok) {
            return {
                label: 'Data sem vaga',
                copy: capacityState.message,
                tone: 'critical',
            };
        }

        return {
            label: 'Janela aberta',
            copy: `${matchedPeriod.nome || 'Grade'}: ${formatDateLabel(matchedPeriod.data_inicio)} a ${formatDateLabel(matchedPeriod.data_fim)}.`,
            tone: 'success',
        };
    };

    const resolveDeadlineState = () => {
        const publicationDate = getFieldValue(form, 'data_publicacao_final') || getFieldValue(form, 'data_publicacao_sugerida');

        if (!publicationDate) {
            return {
                label: 'Aguardando data final',
                copy: 'Defina a publicação para calcular o prazo do briefing.',
                tone: 'neutral',
            };
        }

        const deadline = subtractBusinessDays(publicationDate, 10);

        if (!deadline) {
            return {
                label: 'Data inválida',
                copy: 'Não consegui calcular o prazo do briefing com a data informada.',
                tone: 'warning',
            };
        }

        return {
            label: formatDateLabel(deadline),
            copy: `O briefing precisa entrar até ${formatDateLabel(deadline)}, dez dias úteis antes da publicação de ${formatDateLabel(publicationDate)}.`,
            tone: isDateBeforeToday(deadline) ? 'critical' : 'success',
        };
    };

    const resolveLockState = () => {
        const publicationDate = getFieldValue(form, 'data_publicacao_final') || getFieldValue(form, 'data_publicacao_sugerida');

        if (!publicationDate) {
            return {
                label: 'Sem trava por enquanto',
                copy: 'A data final ainda não foi definida.',
                tone: 'neutral',
            };
        }

        const deadline = subtractBusinessDays(publicationDate, 10);

        if (!deadline) {
            return {
                label: 'Aguardando revisão',
                copy: 'Revise a data final para liberar a trava automática.',
                tone: 'warning',
            };
        }

        if (isDateBeforeToday(deadline)) {
            return {
                label: 'Travado',
                copy: 'O prazo do briefing já passou. A solicitação deve ficar bloqueada após essa data.',
                tone: 'critical',
            };
        }

        return {
            label: 'Aberto',
            copy: 'Ainda existe tempo para enviar o briefing antes do prazo limite.',
            tone: 'success',
        };
    };

    const buildReview = () => {
        if (!review) return;

        review.innerHTML = reviewSections.map((section) => `
            <article class="briefing-wizard__review-card">
                <strong>${escapeHtml(section.title)}</strong>
                <div class="briefing-wizard__review-list">
                    ${section.fields.map((fieldName) => `
                        <div class="briefing-wizard__review-item">
                            <span>${escapeHtml(getFieldLabel(form, fieldName))}</span>
                            <p>${formatReviewValue(getFieldDisplayValue(form, fieldName))}</p>
                        </div>
                    `).join('')}
                </div>
            </article>
        `).join('');
    };

    const syncAnalysisDefaults = () => {
        const suggestedDateField = form.elements.namedItem('data_publicacao_sugerida');
        const finalDateField = form.elements.namedItem('data_publicacao_final');
        const principalChannelField = form.elements.namedItem('canal_principal');
        const requestedChannels = getFieldValue(form, 'canais[]');
        const approvedChannels = getNamedNodes(form, 'canais_aprovados[]');
        const hasApprovedChannels = approvedChannels.some((node) => node.checked);

        if (suggestedDateField && finalDateField && !finalDateField.value && suggestedDateField.value) {
            finalDateField.value = suggestedDateField.value;
        }

        if (!hasApprovedChannels && requestedChannels.length) {
            approvedChannels.forEach((node) => {
                node.checked = requestedChannels.includes(node.value);
            });
        }

        if (principalChannelField && !principalChannelField.value && requestedChannels.length) {
            principalChannelField.value = requestedChannels[0];
        }
    };

    const syncInsights = () => {
        const requestedChannels = getFieldValue(form, 'canais[]');
        const approvedChannels = getFieldValue(form, 'canais_aprovados[]');
        const limitChannels = approvedChannels.length ? approvedChannels : requestedChannels;

        syncMatchedPeriodFields();
        syncCapacityValidity();
        applyCardState(entryTargets, resolveEntryState());
        applyCardState([{ cardId: 'gradeRequestCutoffCard', valueId: 'gradeRequestCutoffStatus', copyId: 'gradeRequestCutoffCopy' }], resolveCutoffState());
        applyCardState(deadlineTargets, resolveDeadlineState());
        applyCardState(lockTargets, resolveLockState());

        renderLimitList('gradeRequestLimitList', 'gradeRequestLimitEmpty', limitChannels);
        renderLimitList('gradeRequestFinalLimitList', 'gradeRequestFinalLimitEmpty', limitChannels);
    };

    const syncFlow = () => {
        if (currentStep >= 3) {
            syncAnalysisDefaults();
        }

        panels.forEach((panel) => {
            panel.classList.toggle('is-active', Number(panel.dataset.gradeStepPanel) === currentStep);
        });

        triggers.forEach((trigger) => {
            trigger.classList.toggle('is-active', Number(trigger.dataset.gradeStepTrigger) === currentStep);
        });

        if (prevButton) {
            prevButton.disabled = currentStep === 1;
        }

        if (nextButton) {
            nextButton.classList.toggle('is-hidden', currentStep === panels.length);
        }

        if (finishButton) {
            finishButton.classList.toggle('is-hidden', currentStep !== panels.length);
        }

        const activePanel = panels[currentStep - 1];

        if (stepLabel) {
            stepLabel.textContent = `Etapa ${currentStep} de ${panels.length}`;
        }

        if (stepTitle && activePanel) {
            stepTitle.textContent = activePanel.dataset.gradeStepTitle || '';
        }

        if (progressBar) {
            progressBar.style.width = `${(currentStep / panels.length) * 100}%`;
        }

        if (currentStep === panels.length) {
            buildReview();
        }

        syncInsights();
    };

    const resetFlowState = () => {
        form.reset();

        if (review) {
            review.innerHTML = '';
        }

        currentStep = 1;
        syncFlow();
    };

    const openFlowForOperator = (operator) => {
        currentOperator = operator;
        currentRequester = null;
        resetFlowState();
        syncOperatorUi();
        identity?.classList.add('is-hidden');
        flow?.classList.remove('is-hidden');
        form.elements.namedItem('ciclo_referencia')?.focus();
    };

    const openFlowForRequester = (requester) => {
        currentOperator = null;
        currentRequester = requester;
        resetFlowState();
        syncOperatorUi();
        identity?.classList.add('is-hidden');
        flow?.classList.remove('is-hidden');
        form.elements.namedItem('ciclo_referencia')?.focus();
    };

    const showIdentityGate = (clearLookupEmail = false) => {
        currentOperator = null;
        form.reset();

        if (review) {
            review.innerHTML = '';
        }

        if (periodForm) {
            periodForm.reset();
        }

        periodResultCard?.classList.add('is-hidden');

        currentStep = 1;
        syncFlow();
        syncOperatorUi();
        flow?.classList.add('is-hidden');
        identity?.classList.remove('is-hidden');

        if (lookupEmailField) {
            if (clearLookupEmail) {
                lookupEmailField.value = '';
            }

            lookupEmailField.focus();
        }
    };

    const validatePanel = (step) => {
        const panel = panels[step - 1];
        if (!panel) return true;

        const requiredFields = [...panel.querySelectorAll('[required]')];
        for (const field of requiredFields) {
            const value = getFieldValue(form, field.name);
            const isEmpty = Array.isArray(value) ? value.length === 0 : !value;
            if (isEmpty) {
                field.reportValidity();
                return false;
            }

            if (typeof field.checkValidity === 'function' && !field.checkValidity()) {
                field.reportValidity();
                return false;
            }
        }

        const requiredGroups = [...panel.querySelectorAll('[data-required-group]')];
        for (const group of requiredGroups) {
            const fieldName = group.dataset.requiredGroup;
            const label = group.dataset.requiredLabel || 'este grupo';
            const value = getFieldValue(form, fieldName);
            const isEmpty = Array.isArray(value) ? value.length === 0 : !value;

            if (isEmpty) {
                showToast(`Faltou preencher ${label}.`, 'warning');
                return false;
            }
        }

        return true;
    };

    const validateForFinish = () => {
        for (let step = 1; step < panels.length; step += 1) {
            if (!validatePanel(step)) {
                currentStep = step;
                syncFlow();
                return false;
            }
        }

        const email = getFieldValue(form, 'email_solicitante');
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            currentStep = 1;
            syncFlow();
            emailField?.reportValidity();
            showToast('Me passa um e-mail válido para continuar.', 'warning');
            return false;
        }

        return true;
    };

    const applyCreatedPeriod = (period) => {
        const startDate = String(period?.data_inicio || '').trim();
        const endDate = String(period?.data_fim || '').trim();

        const cycleField = form.elements.namedItem('ciclo_referencia');
        const openingField = form.elements.namedItem('data_abertura_ciclo');
        const closingField = form.elements.namedItem('data_fechamento_ciclo');

        if (cycleField && startDate) {
            cycleField.value = startDate.slice(0, 7);
        }

        if (openingField && startDate) {
            openingField.value = startDate;
        }

        if (closingField && endDate) {
            closingField.value = endDate;
        }

        syncInsights();
    };

    identityForm?.addEventListener('submit', (event) => {
        event.preventDefault();
    });

    periodForm?.addEventListener('submit', async (event) => {
        event.preventDefault();

        if (!currentOperator || currentOperator.role !== 'adm') {
            showToast('Somente administradores podem criar uma nova grade.', 'warning');
            return;
        }

        const formData = new FormData(periodForm);
        const name = String(formData.get('nome') || '').trim();
        const startDate = String(formData.get('data_inicio') || '').trim();
        const endDate = String(formData.get('data_fim') || '').trim();

        if (!name || !startDate || !endDate) {
            showToast('Preencha nome, início e fim para criar a grade.', 'warning');
            return;
        }

        periodSubmitButton && (periodSubmitButton.disabled = true);

        try {
            const response = await fetch(createPeriodUrl, {
                method: 'POST',
                body: new URLSearchParams({
                    nome: name,
                    data_inicio: startDate,
                    data_fim: endDate,
                }).toString(),
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                },
            });

            const payload = await response.json();

            if (!response.ok || !payload.ok) {
                showToast(payload.message || 'Não consegui criar a grade agora.', 'warning');
                return;
            }

            const period = payload.period || {};

            if (periodResultTitle) {
                periodResultTitle.textContent = period.nome || 'Grade criada';
            }

            if (periodResultCopy) {
                periodResultCopy.textContent = `Janela ativa de ${period.data_inicio_br || ''} até ${period.data_fim_br || ''}. O ciclo da solicitação já foi atualizado com essas datas.`;
            }

            periodResultCard?.classList.remove('is-hidden');
            applyCreatedPeriod(period);
            showToast('Grade criada e janela aplicada ao ciclo.', 'success');
        } catch (error) {
            showToast('Tive um problema ao criar a grade.', 'warning');
        } finally {
            periodSubmitButton && (periodSubmitButton.disabled = false);
        }
    });

    triggers.forEach((trigger) => {
        trigger.addEventListener('click', () => {
            const targetStep = Number(trigger.dataset.gradeStepTrigger);

            if (targetStep > currentStep && !validatePanel(currentStep)) {
                return;
            }

            currentStep = targetStep;
            syncFlow();
        });
    });

    nextButton?.addEventListener('click', () => {
        if (!validatePanel(currentStep)) {
            return;
        }

        currentStep = Math.min(currentStep + 1, panels.length);
        syncFlow();
    });

    prevButton?.addEventListener('click', () => {
        currentStep = Math.max(currentStep - 1, 1);
        syncFlow();
    });

    resetButton?.addEventListener('click', () => {
        resetFlowState();
        showToast('Fluxo limpo para começar de novo.', 'info');
    });

    finishButton?.addEventListener('click', async () => {
        if (!validateForFinish()) {
            return;
        }

        const entryState = resolveEntryState();

        buildReview();
        syncInsights();
        const buttons = [prevButton, nextButton, finishButton, resetButton].filter(Boolean);

        if (!submitUrl) {
            showToast('Endpoint de envio da solicitacao nao configurado.', 'warning');
            return;
        }

        buttons.forEach((button) => {
            button.disabled = true;
        });

        try {
            const response = await fetch(submitUrl, {
                method: 'POST',
                body: new FormData(form),
            });
            const payload = await response.json();

            if (!response.ok || !payload.ok) {
                throw new Error(payload.message || 'Nao consegui salvar a solicitacao agora.');
            }

            await playBriefingSentCelebration();
            showToast(payload.message || `Solicitacao enviada como ${entryState.label}.`, 'success');
            window.location.href = payload.redirect_url || window.location.href;
        } catch (error) {
            showToast(error.message || 'Tive um problema ao salvar a solicitacao.', 'warning');
        } finally {
            buttons.forEach((button) => {
                button.disabled = false;
            });
        }

        return;
        await playBriefingSentCelebration();
        showToast(`Fluxo da grade preparado como ${entryState.label.toLowerCase()}. Você pode abrir outra solicitação sem sair desta sessão.`, 'success');
        resetFlowState();
        syncOperatorUi();
    });

    form.addEventListener('input', () => {
        syncInsights();

        if (currentStep === panels.length) {
            buildReview();
        }
    });

    form.addEventListener('change', () => {
        syncInsights();

        if (currentStep === panels.length) {
            buildReview();
        }
    });

    let initialOperator = null;
    let initialRequester = null;

    try {
        initialOperator = normalizeOperator(JSON.parse(initialOperatorPayload));
    } catch (error) {
        initialOperator = null;
    }

    try {
        initialRequester = normalizeRequester(JSON.parse(initialRequesterPayload));
    } catch (error) {
        initialRequester = null;
    }

    if (initialOperator) {
        openFlowForOperator(initialOperator);
        return;
    }

    openFlowForRequester(initialRequester);
}

function initCharts() {
    if (typeof Chart === 'undefined') return;

    document.querySelectorAll('[data-chart-config]').forEach((canvas) => {
        const rawConfig = canvas.getAttribute('data-chart-config');
        if (!rawConfig) return;

        try {
            const config = JSON.parse(rawConfig);
            new Chart(canvas, {
                ...config,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'bottom',
                            labels: {
                                usePointStyle: true,
                                boxWidth: 10,
                                color: '#64748B',
                                padding: 18,
                                font: { family: 'Manrope', size: 12, weight: '600' },
                            },
                        },
                    },
                    scales: config.type === 'bar' ? {
                        y: { grid: { color: 'rgba(217, 228, 236, 0.9)' }, ticks: { color: '#64748B' } },
                        x: { grid: { display: false }, ticks: { color: '#64748B' } },
                    } : {},
                },
            });
        } catch (error) {
            console.error('Falha ao carregar chart:', error);
        }
    });
}

function initIdentity() {
    const root = document.getElementById('meusBriefingsPage');
    if (!root) return;

    const requesterName = (root.dataset.requesterName || '').trim();
    const requesterEmail = (root.dataset.requesterEmail || '').trim().toLowerCase();
    const emailInput = document.getElementById('identityEmail');
    const wizardName = document.getElementById('wizardName');
    const wizardEmail = document.getElementById('wizardEmail');
    const identityPill = document.getElementById('identityPill');

    if (emailInput) {
        emailInput.value = requesterEmail;
    }

    if (wizardName) {
        wizardName.value = requesterName;
    }

    if (wizardEmail) {
        wizardEmail.value = requesterEmail;
    }

    applyIdentity(requesterEmail, identityPill);
}

function applyIdentity(email, identityPill) {
    const cards = document.querySelectorAll('[data-briefing-email]');
    const emptyState = document.getElementById('briefingEmptyState');
    let visibleCount = 0;

    cards.forEach((card) => {
        const shouldShow = !email || card.getAttribute('data-briefing-email') === email;
        card.hidden = !shouldShow;
        if (shouldShow) visibleCount += 1;
    });

    if (identityPill) {
        identityPill.textContent = email ? `Exibindo registros de ${email}` : 'Exibindo demonstracao geral';
    }

    if (emptyState) {
        emptyState.hidden = visibleCount > 0;
    }
}

function initWizard() {
    const wizard = document.getElementById('briefingWizard');
    if (!wizard) return;

    const panels = [...wizard.querySelectorAll('[data-step-panel]')];
    const triggers = [...document.querySelectorAll('[data-step-trigger]')];
    const nextButton = wizard.querySelector('[data-step-next]');
    const prevButton = wizard.querySelector('[data-step-prev]');
    const submitButton = document.getElementById('submitBriefing');
    const progressBar = document.getElementById('wizardProgressBar');
    const progressLabel = document.getElementById('wizardProgressLabel');
    let currentStep = 1;

    const syncWizard = () => {
        panels.forEach((panel) => panel.classList.toggle('is-active', Number(panel.dataset.stepPanel) === currentStep));
        triggers.forEach((trigger) => trigger.classList.toggle('is-active', Number(trigger.dataset.stepTrigger) === currentStep));

        if (prevButton) prevButton.disabled = currentStep === 1;
        if (nextButton) nextButton.classList.toggle('is-hidden', currentStep === panels.length);
        if (submitButton) submitButton.classList.toggle('is-hidden', currentStep !== panels.length);
        if (progressBar) progressBar.style.width = `${(currentStep / panels.length) * 100}%`;
        if (progressLabel) progressLabel.textContent = `Etapa ${currentStep} de ${panels.length}`;
    };

    triggers.forEach((trigger) => {
        trigger.addEventListener('click', () => {
            currentStep = Number(trigger.dataset.stepTrigger);
            syncWizard();
        });
    });

    if (nextButton) {
        nextButton.addEventListener('click', () => {
            currentStep = Math.min(currentStep + 1, panels.length);
            syncWizard();
        });
    }

    if (prevButton) {
        prevButton.addEventListener('click', () => {
            currentStep = Math.max(currentStep - 1, 1);
            syncWizard();
        });
    }

    syncWizard();
}

function initViewSwitch() {
    const buttons = document.querySelectorAll('[data-view-target]');
    const panels = document.querySelectorAll('[data-view-panel]');
    if (!buttons.length || !panels.length) return;

    buttons.forEach((button) => {
        button.addEventListener('click', () => {
            const target = button.dataset.viewTarget;
            buttons.forEach((item) => item.classList.toggle('is-active', item === button));
            panels.forEach((panel) => panel.classList.toggle('is-active', panel.dataset.viewPanel === target));
        });
    });
}

function initDemoForms() {
    document.querySelectorAll('[data-demo-submit]').forEach((button) => {
        button.addEventListener('click', () => {
            const action = button.dataset.demoSubmit;
            const message = action === 'send'
                ? 'Briefing enviado na demonstracao. Na proxima fase, esta acao gravara no banco.'
                : 'Rascunho salvo localmente na demonstracao.';
            showToast(message, action === 'send' ? 'success' : 'info');
        });
    });

    document.querySelectorAll('[data-demo-form]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            event.preventDefault();
            showToast('Acao preparada para integracao backend.', 'info');
        });
    });
}

function getNamedNodes(form, name) {
    const field = form.elements.namedItem(name);
    if (!field) return [];

    if (field instanceof RadioNodeList) {
        return [...field].filter(Boolean);
    }

    return [field].filter(Boolean);
}

function parseIsoDate(value) {
    const normalized = String(value || '').trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(normalized)) {
        return null;
    }

    const [year, month, day] = normalized.split('-').map(Number);
    return new Date(year, month - 1, day);
}

function toIsoDate(date) {
    const year = date.getFullYear();
    const month = `${date.getMonth() + 1}`.padStart(2, '0');
    const day = `${date.getDate()}`.padStart(2, '0');
    return `${year}-${month}-${day}`;
}

function getCurrentIsoMonth() {
    const today = new Date();
    return `${today.getFullYear()}-${`${today.getMonth() + 1}`.padStart(2, '0')}`;
}

function applyFutureOnlyDateFields(root) {
    if (!root) return;

    const applyMinimumValue = (field, fallbackMinimum) => {
        const minimum = field.getAttribute('min') || fallbackMinimum;

        if (!field.getAttribute('min')) {
            field.setAttribute('min', minimum);
        }

        if (field.value && field.value < minimum) {
            field.value = '';
        }

        field.addEventListener('change', () => {
            if (field.value && field.value < minimum) {
                field.value = '';
            }
        });
    };

    root.querySelectorAll('input[type="date"]:not([readonly])').forEach((field) => {
        applyMinimumValue(field, toIsoDate(new Date()));
    });

    root.querySelectorAll('input[type="month"]:not([readonly])').forEach((field) => {
        applyMinimumValue(field, getCurrentIsoMonth());
    });
}

function formatDateLabel(value) {
    const date = parseIsoDate(value);
    return date ? date.toLocaleDateString('pt-BR') : '';
}

function subtractBusinessDays(value, amount) {
    const date = parseIsoDate(value);
    if (!date) return '';

    let remaining = Number(amount || 0);

    while (remaining > 0) {
        date.setDate(date.getDate() - 1);

        const day = date.getDay();
        if (day !== 0 && day !== 6) {
            remaining -= 1;
        }
    }

    return toIsoDate(date);
}

function isDateBeforeToday(value) {
    const date = parseIsoDate(value);
    if (!date) return false;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return date < today;
}

function getFieldValue(form, name) {
    const field = form.elements.namedItem(name);
    if (!field) return '';

    if (field instanceof RadioNodeList) {
        const nodes = [...field].filter(Boolean);
        if (!nodes.length) return '';

        if (nodes.every((node) => node.type === 'checkbox')) {
            return nodes
                .filter((node) => node.checked)
                .map((node) => (node.value || '').trim())
                .filter(Boolean);
        }

        return (field.value || '').trim();
    }

    if (field.type === 'checkbox') {
        return field.checked ? field.value || '1' : '';
    }

    return (field.value || '').trim();
}

function getFieldLabel(form, name) {
    const field = form.elements.namedItem(name);
    const element = field instanceof RadioNodeList ? field[0] : field;
    const groupLabel = element?.closest('fieldset')?.querySelector('.briefing-wizard__group-head span');
    if (groupLabel) {
        return groupLabel.textContent.trim();
    }

    const label = element?.closest('label')?.querySelector('span');
    return label?.textContent?.trim() || name;
}

function getFieldDisplayValue(form, name) {
    const field = form.elements.namedItem(name);
    if (!field) return '';

    if (field instanceof RadioNodeList) {
        const nodes = [...field].filter(Boolean);
        if (!nodes.length) return '';

        if (nodes.every((node) => node.type === 'checkbox')) {
            return nodes
                .filter((node) => node.checked)
                .map((node) => getChoiceLabel(node));
        }

        const selected = nodes.find((node) => node.checked);
        return selected ? getChoiceLabel(selected) : '';
    }

    const element = field;

    if (element?.tagName === 'SELECT') {
        const option = element.options[element.selectedIndex];
        return option && option.value !== '' ? option.textContent.trim() : '';
    }

    return getFieldValue(form, name);
}

function formatReviewValue(value) {
    if (Array.isArray(value)) {
        if (!value.length) {
            return '<em>Não informado ainda.</em>';
        }

        return value.map((item) => escapeHtml(String(item))).join('<br>');
    }

    const normalized = String(value || '').trim();
    if (!normalized) {
        return '<em>Não informado ainda.</em>';
    }

    return escapeHtml(normalized).replace(/\n/g, '<br>');
}

function getChoiceLabel(node) {
    return node.getAttribute('data-label')
        || node.closest('label')?.querySelector('[data-choice-label]')?.textContent?.trim()
        || node.closest('label')?.querySelector('span')?.textContent?.trim()
        || (node.value || '').trim();
}

function showToast(message, tone = 'info') {
    const stack = document.getElementById('toastStack');
    if (!stack) return;

    const toast = document.createElement('div');
    toast.className = `toast-item ${tone}`;
    toast.textContent = message;
    stack.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('is-visible'));

    window.setTimeout(() => {
        toast.classList.remove('is-visible');
        window.setTimeout(() => toast.remove(), 240);
    }, 2800);
}

function bindBriefingStatusSelect(select) {
    if (!select || select.dataset.statusBound === '1') return;

    select.dataset.statusBound = '1';

    ['pointerdown', 'mousedown', 'click'].forEach((eventName) => {
        select.addEventListener(eventName, (event) => {
            event.stopPropagation();
        });
    });

    select.addEventListener('change', async (event) => {
        event.stopPropagation();

        const briefingId = String(select.dataset.briefingId || '').trim();
        const nextStatus = String(select.value || '').trim();
        const previousStatus = String(select.dataset.currentStatus || '').trim();
        const statusRoot = select.closest('[data-status-update-url]') || document.querySelector('[data-status-update-url]');
        const updateUrl = String(select.dataset.statusUpdateUrl || statusRoot?.dataset.statusUpdateUrl || '').trim();

        if (!briefingId || !nextStatus || !updateUrl) {
            select.value = previousStatus;
            showToast('Nao encontrei os dados para atualizar o status.', 'warning');
            return;
        }

        select.disabled = true;

        try {
            const response = await fetch(updateUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                },
                body: new URLSearchParams({
                    briefing_id: briefingId,
                    status: nextStatus,
                }).toString(),
            });
            const payload = await response.json();

            if (!response.ok || !payload.ok) {
                throw new Error(payload.message || 'Nao foi possivel atualizar o status.');
            }

            const status = payload.status || {};
            const statusKey = String(status.key || nextStatus || '').trim();
            const statusTone = String(status.tone || 'info').trim();
            const statusIcon = String(status.icon || 'bi-inbox').trim();
            const statusLabel = String(status.label || status.nome || select.options[select.selectedIndex]?.text || 'Aberto').trim();
            const toneClass = `is-${statusTone.replace(/[^a-z0-9_-]/gi, '').toLowerCase()}`;

            select.dataset.currentStatus = statusKey;
            select.value = statusKey;

            const escapedBriefingId = typeof CSS !== 'undefined' && CSS.escape
                ? CSS.escape(briefingId)
                : briefingId.replace(/[^a-z0-9_-]/gi, '\\$&');
            const wrappers = document.querySelectorAll(`.js-briefing-status-select[data-briefing-id="${escapedBriefingId}"]`);
            wrappers.forEach((statusSelect) => {
                statusSelect.value = statusKey;
                statusSelect.dataset.currentStatus = statusKey;
                const wrapper = statusSelect.closest('.grade-admin__status-select, .briefing-wizard__status-card');
                if (wrapper) {
                    [...wrapper.classList].forEach((className) => {
                        if (/^is-/.test(className)) {
                            wrapper.classList.remove(className);
                        }
                    });
                    wrapper.classList.add(toneClass);
                    wrapper.dataset.statusKey = statusKey;
                }
            });

            const icon = select.closest('.briefing-wizard__status-card')?.querySelector('[data-briefing-status-icon]');
            if (icon) {
                icon.className = `bi ${statusIcon}`;
            }

            showToast(payload.message || `Status atualizado para ${statusLabel}.`, 'success');
        } catch (error) {
            select.value = previousStatus;
            showToast(error.message || 'Nao foi possivel atualizar o status.', 'warning');
        } finally {
            select.disabled = false;
        }
    });
}

function initBriefingStatusControls() {
    document.querySelectorAll('.js-briefing-status-select').forEach(bindBriefingStatusSelect);
}

function applyGradeAdminQueueFilter(root = document.getElementById('gradeAdminPage')) {
    if (!root) return;

    const requestList = document.getElementById('gradeAdminRequestList');
    const pendingCount = document.getElementById('gradeAdminPendingCount');
    const filterEmpty = document.getElementById('gradeAdminFilterEmpty');
    const activeFilter = root.querySelector('[data-grade-origin-filter].is-active');
    const filter = String(activeFilter?.dataset.gradeOriginFilter || 'all');

    if (!requestList) return;

    let visibleCount = 0;
    const cards = [...requestList.querySelectorAll('.grade-admin__request')];

    cards.forEach((card) => {
        const origin = String(card.dataset.originCategory || 'briefing');
        const isVisible = filter === 'all' || origin === filter;
        card.classList.toggle('is-filtered-out', !isVisible);
        if (isVisible) {
            visibleCount += 1;
        }
    });

    if (pendingCount) {
        pendingCount.textContent = String(visibleCount);
    }

    filterEmpty?.classList.toggle('is-hidden', visibleCount > 0 || cards.length === 0);
}

function initGradeAdminQueueFilters() {
    const root = document.getElementById('gradeAdminPage');
    if (!root) return;

    root.querySelectorAll('[data-grade-origin-filter]').forEach((button) => {
        button.addEventListener('click', () => {
            root.querySelectorAll('[data-grade-origin-filter]').forEach((item) => {
                item.classList.toggle('is-active', item === button);
                item.setAttribute('aria-pressed', item === button ? 'true' : 'false');
            });
            applyGradeAdminQueueFilter(root);
        });
    });

    applyGradeAdminQueueFilter(root);
}

function initGradeAdminCalendar() {
    const root = document.getElementById('gradeAdminPage');
    const calendarNode = document.getElementById('gradeAdminCalendar');
    const eventsNode = document.getElementById('gradeAdminEvents');

    if (!root) {
        return;
    }

    const createPeriodUrl = String(root.dataset.createPeriodUrl || '').trim();
    const updatePeriodUrl = String(root.dataset.updatePeriodUrl || '').trim();
    const openCreateButton = document.getElementById('gradeAdminOpenCreateModal');
    const editPeriodButton = document.getElementById('gradeAdminEditPeriod');
    const periodModal = document.getElementById('gradeAdminCreateModal');
    const finalizeModal = document.getElementById('gradeAdminFinalizeModal');
    const finalizeConfirmButton = document.getElementById('gradeAdminFinalizeConfirm');
    const periodForm = document.getElementById('gradeAdminPeriodForm');
    const periodSubmit = document.getElementById('gradeAdminPeriodSubmit');
    const periodSelect = document.getElementById('gradeAdminPeriodSelect');
    const periodModalKicker = periodModal?.querySelector('.grade-admin__modal-head span');
    const periodModalTitle = document.getElementById('gradeAdminCreateTitle');
    const periodSubmitLabel = periodSubmit?.querySelector('span');
    let modalReturnFocus = null;

    try {
        const pendingToast = JSON.parse(sessionStorage.getItem('grade_admin_toast') || 'null');
        if (pendingToast?.message) {
            showToast(pendingToast.message, pendingToast.tone || 'success');
            sessionStorage.removeItem('grade_admin_toast');
        }
    } catch (error) {}

    const setPeriodFormMode = (mode) => {
        if (!periodForm) return;

        periodForm.dataset.mode = mode;
        const nameField = periodForm.elements.namedItem('nome');
        const startField = periodForm.elements.namedItem('data_inicio');
        const endField = periodForm.elements.namedItem('data_fim');

        if (mode === 'edit') {
            periodModalKicker && (periodModalKicker.textContent = 'Editar grade');
            periodModalTitle && (periodModalTitle.textContent = 'Editar grade');
            periodSubmitLabel && (periodSubmitLabel.textContent = 'Salvar grade');
            nameField && (nameField.value = String(root.dataset.periodName || '').trim());
            startField && (startField.value = String(root.dataset.periodStart || '').trim());
            endField && (endField.value = String(root.dataset.periodEnd || '').trim());
            startField?.removeAttribute('min');
            endField?.removeAttribute('min');
            return;
        }

        periodModalKicker && (periodModalKicker.textContent = 'Nova grade');
        periodModalTitle && (periodModalTitle.textContent = 'Criar grade');
        periodSubmitLabel && (periodSubmitLabel.textContent = 'Criar grade');
        periodForm.reset();
        const today = toIsoDate(new Date());
        startField?.setAttribute('min', today);
        endField?.setAttribute('min', today);
    };

    const setPeriodModalOpen = (isOpen) => {
        if (!periodModal) return;

        periodModal.classList.toggle('is-open', isOpen);
        periodModal.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
        document.body.classList.toggle('has-modal-open', isOpen);

        if (isOpen) {
            modalReturnFocus = document.activeElement;
            const firstField = periodModal.querySelector('input, select, textarea, button:not([data-grade-modal-close])');
            window.setTimeout(() => firstField?.focus(), 0);
        } else {
            modalReturnFocus?.focus?.();
        }
    };

    openCreateButton?.addEventListener('click', () => {
        setPeriodFormMode('create');
        setPeriodModalOpen(true);
    });

    editPeriodButton?.addEventListener('click', () => {
        setPeriodFormMode('edit');
        setPeriodModalOpen(true);
    });

    periodModal?.querySelectorAll('[data-grade-modal-close]').forEach((control) => {
        control.addEventListener('click', () => setPeriodModalOpen(false));
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && periodModal?.classList.contains('is-open')) {
            setPeriodModalOpen(false);
        }

        if (event.key === 'Escape' && finalizeModal?.classList.contains('is-open')) {
            setFinalizeModalOpen(false);
        }
    });

    periodSelect?.addEventListener('change', () => {
        const target = String(periodSelect.value || '').trim();

        if (target) {
            window.location.href = target;
        }
    });

    periodForm?.addEventListener('submit', async (event) => {
        event.preventDefault();

        const mode = periodForm.dataset.mode === 'edit' ? 'edit' : 'create';
        const endpoint = mode === 'edit' ? updatePeriodUrl : createPeriodUrl;

        if (!endpoint) return;

        const formData = new FormData(periodForm);
        const name = String(formData.get('nome') || '').trim();
        const startDate = String(formData.get('data_inicio') || '').trim();
        const endDate = String(formData.get('data_fim') || '').trim();

        if (!name || !startDate || !endDate) {
            showToast('Preencha nome, inicio e fim para criar a grade.', 'warning');
            return;
        }

        periodSubmit && (periodSubmit.disabled = true);

        try {
            const body = new URLSearchParams({
                nome: name,
                data_inicio: startDate,
                data_fim: endDate,
            });

            if (mode === 'edit') {
                body.set('periodo_id', String(root.dataset.periodId || ''));
            }

            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString(),
            });
            const payload = await response.json();

            if (!response.ok || !payload.ok) {
                throw new Error(payload.message || 'Nao consegui criar a grade agora.');
            }

            if (mode === 'edit') {
                try {
                    sessionStorage.setItem('grade_admin_toast', JSON.stringify({
                        message: payload.message || 'Grade atualizada com sucesso.',
                        tone: 'success',
                    }));
                } catch (storageError) {}
                window.location.reload();
                return;
            }

            const nextUrl = new URL(window.location.href);
            nextUrl.searchParams.set('periodo_id', payload.period.id);
            try {
                sessionStorage.setItem('grade_admin_toast', JSON.stringify({
                    message: payload.message || 'Grade criada com sucesso.',
                    tone: 'success',
                }));
            } catch (storageError) {}
            window.location.href = nextUrl.toString();
        } catch (error) {
            showToast(error.message || 'Tive um problema ao criar a grade.', 'warning');
        } finally {
            periodSubmit && (periodSubmit.disabled = false);
        }
    });

    if (!calendarNode || !eventsNode || typeof FullCalendar === 'undefined') {
        return;
    }

    let initialEvents = [];
    let channelRules = {};

    try {
        initialEvents = JSON.parse(eventsNode.textContent || '[]');
    } catch (error) {
        initialEvents = [];
    }

    try {
        channelRules = JSON.parse(root.dataset.channelRules || '{}');
    } catch (error) {
        channelRules = {};
    }

    const periodId = String(root.dataset.periodId || '').trim();
    const periodClosed = String(root.dataset.periodClosed || '') === '1';
    const calendarLocked = String(root.dataset.calendarLocked || '') === '1';
    const periodStart = String(root.dataset.periodStart || '').trim();
    const periodEnd = String(root.dataset.periodEnd || '').trim();
    const calendarStart = String(root.dataset.calendarStart || periodStart).trim();
    const calendarEnd = String(root.dataset.calendarEnd || periodEnd).trim();
    const scheduleUrl = String(root.dataset.scheduleUrl || '').trim();
    const moveUrl = String(root.dataset.moveUrl || '').trim();
    const removeUrl = String(root.dataset.removeUrl || '').trim();
    const statusUpdateUrl = String(root.dataset.statusUpdateUrl || '').trim();
    const priorityUpdateUrl = String(root.dataset.priorityUpdateUrl || '').trim();
    const finalizePeriodUrl = String(root.dataset.finalizePeriodUrl || '').trim();
    const requestList = document.getElementById('gradeAdminRequestList');
    const pendingCount = document.getElementById('gradeAdminPendingCount');
    const scheduledCount = document.getElementById('gradeAdminScheduledCount');
    const hintCard = document.getElementById('gradeAdminHintCard');
    const hintTitle = document.getElementById('gradeAdminHintTitle');
    const hintCopy = document.getElementById('gradeAdminHintCopy');
    const finalizeButton = document.getElementById('gradeAdminFinalizePeriod');
    let solicitationStatuses = [];
    let priorityOptions = [];

    try {
        solicitationStatuses = JSON.parse(root.dataset.solicitationStatuses || '[]');
    } catch (error) {
        solicitationStatuses = [];
    }

    try {
        priorityOptions = JSON.parse(root.dataset.priorityOptions || '[]');
    } catch (error) {
        priorityOptions = [];
    }

    const setFinalizeModalOpen = (isOpen) => {
        if (!finalizeModal) return;

        finalizeModal.classList.toggle('is-open', isOpen);
        finalizeModal.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
        document.body.classList.toggle('has-modal-open', isOpen);

        if (isOpen) {
            window.setTimeout(() => finalizeConfirmButton?.focus(), 0);
        }
    };

    finalizeModal?.querySelectorAll('[data-grade-finalize-close]').forEach((control) => {
        control.addEventListener('click', () => setFinalizeModalOpen(false));
    });

    const calendarDayCount = 7;

    calendarNode.style.setProperty('--grade-days', String(calendarDayCount));
    calendarNode.style.setProperty('--grade-calendar-width', '100%');

    const getChannelRule = (channel) => {
        const rule = channelRules[channel] || {};
        return {
            limit: Number(rule.limit || 1),
            label: rule.limit_label || '1 por dia',
        };
    };

    const dateKey = (value) => {
        if (!value) return '';
        if (value instanceof Date) return toIsoDate(value);

        const normalized = String(value).trim();
        return normalized.includes('T') ? normalized.split('T')[0] : normalized.slice(0, 10);
    };

    const slotTime = (slotValue) => {
        const slot = Math.max(1, Number(slotValue || 1));
        const totalMinutes = (8 * 60) + ((slot - 1) * 30);
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;

        return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00`;
    };

    const slotFromDate = (value) => {
        const date = value instanceof Date ? value : (value ? new Date(value) : null);

        if (!date || Number.isNaN(date.getTime())) return 1;

        const totalMinutes = (date.getHours() * 60) + date.getMinutes();
        return Math.max(1, Math.floor((totalMinutes - (8 * 60)) / 30) + 1);
    };

    const eventStart = (item) => {
        const value = String(item.start || item.date || '').trim();

        if (!value || value.includes('T')) {
            return value;
        }

        return `${dateKey(value)}T${slotTime(item.slot || item.extendedProps?.slot || 1)}`;
    };

    const eventTimeLabel = (date) => date
        ? date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        : '';

    const shortWeekday = (date) => new Intl.DateTimeFormat('pt-BR', { weekday: 'short' })
        .format(date)
        .replace('.', '');

    const dayMonth = (date) => new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: '2-digit' }).format(date);

    const isSameCalendarEvent = (event, excludedEvent = null) => {
        if (!excludedEvent) return false;
        if (event === excludedEvent) return true;

        const eventId = String(event.id || '');
        const excludedId = String(excludedEvent.id || '');

        if (eventId && excludedId && eventId === excludedId) return true;

        const eventBriefingId = String(event.extendedProps?.briefingId || '');
        const excludedBriefingId = String(excludedEvent.extendedProps?.briefingId || '');

        return Boolean(eventBriefingId && excludedBriefingId
            && eventBriefingId === excludedBriefingId
            && dateKey(event.start || event.startStr) === dateKey(excludedEvent.start || excludedEvent.startStr));
    };

    const eventSnapshot = (calendar, excludedEvent = null) => calendar.getEvents()
        .filter((event) => !isSameCalendarEvent(event, excludedEvent))
        .map((event) => ({
            id: String(event.id || ''),
            date: dateKey(event.start || event.startStr),
            channel: String(event.extendedProps.channel || ''),
            capacityUnits: Number(event.extendedProps.capacityUnits || 1),
        }));

    const usedSlots = (calendar, channel, date, excludedEvent = null) => eventSnapshot(calendar, excludedEvent)
        .filter((event) => event.channel === channel && event.date === date)
        .reduce((total, event) => total + Math.max(1, event.capacityUnits), 0);

    const isBusinessDay = (dateValue) => {
        const date = parseIsoDate(dateValue);
        if (!date) return false;
        const day = date.getDay();
        return day !== 0 && day !== 6;
    };

    const nextBusinessFreeDate = (calendar, channel, excludedEvent = null, startDate = calendarStart) => {
        const startCandidates = [startDate, calendarStart, toIsoDate(new Date())].filter(Boolean).sort();
        let cursor = parseIsoDate(startCandidates[startCandidates.length - 1]);
        const end = parseIsoDate(calendarEnd);
        const rule = getChannelRule(channel);

        if (!cursor || !end) return '';

        while (cursor <= end) {
            const dateKey = toIsoDate(cursor);

            if (isBusinessDay(dateKey) && usedSlots(calendar, channel, dateKey, excludedEvent) < rule.limit) {
                return dateKey;
            }

            cursor.setDate(cursor.getDate() + 1);
        }

        return '';
    };

    const clearDropGuidance = () => {
        root.classList.remove('is-guiding-drop', 'has-next-free-date', 'has-no-free-date');
        calendarNode.querySelectorAll('.is-next-free-date').forEach((node) => {
            node.classList.remove('is-next-free-date');
        });
    };

    const highlightNextFreeDate = (date) => {
        clearDropGuidance();
        root.classList.add('is-guiding-drop');

        if (!date) {
            root.classList.add('has-no-free-date');
            return;
        }

        root.classList.add('has-next-free-date');
        calendarNode.querySelectorAll(`[data-date="${date}"]`).forEach((node) => {
            node.classList.add('is-next-free-date');
        });
    };

    const renderHint = (calendar, item) => {
        if (!hintTitle || !hintCopy) return '';

        if (!item || !item.channel) {
            hintCard && (hintCard.dataset.tone = 'neutral');
            hintTitle.textContent = 'Selecione um pedido';
            hintCopy.textContent = 'Clique em um pedido ou evento para ver o proximo dia util livre conforme a regra do canal.';
            return '';
        }

        const rule = getChannelRule(item.channel);
        const nextDate = nextBusinessFreeDate(calendar, item.channel, item.excludeEvent || null, item.startDate || calendarStart);

        hintTitle.textContent = item.title || item.channel;
        hintCard && (hintCard.dataset.tone = nextDate ? 'success' : 'warning');
        hintCopy.textContent = nextDate
            ? `${item.channel}: limite de ${rule.label}. Proximo dia util livre: ${formatDateLabel(nextDate)}.`
            : `${item.channel}: nao ha dia util livre nesta grade para o limite de ${rule.label}.`;

        return nextDate;
    };

    const guideRequestPlacement = (item) => {
        const nextDate = renderHint(calendar, item);
        highlightNextFreeDate(nextDate);
    };

    const clearSelectedRequests = () => {
        requestList?.querySelectorAll('.grade-admin__request.is-selected').forEach((item) => {
            item.classList.remove('is-selected');
        });
    };

    const toneClassName = (tone) => `is-${String(tone || 'neutral').replace(/[^a-z0-9_-]/gi, '').toLowerCase()}`;

    const resetToneClasses = (node) => {
        if (!node) return;
        [...node.classList].forEach((className) => {
            if (/^is-/.test(className)) {
                node.classList.remove(className);
            }
        });
    };

    const contextMenu = document.createElement('div');
    contextMenu.className = 'grade-admin__context-menu';
    contextMenu.setAttribute('aria-hidden', 'true');
    document.body.appendChild(contextMenu);

    const closeContextMenu = () => {
        contextMenu.classList.remove('is-open');
        contextMenu.setAttribute('aria-hidden', 'true');
        contextMenu.innerHTML = '';
    };

    const positionContextMenu = (event) => {
        const gap = 8;
        contextMenu.style.left = `${event.clientX}px`;
        contextMenu.style.top = `${event.clientY}px`;
        contextMenu.classList.add('is-open');
        contextMenu.setAttribute('aria-hidden', 'false');

        const bounds = contextMenu.getBoundingClientRect();
        const left = Math.min(event.clientX, window.innerWidth - bounds.width - gap);
        const top = Math.min(event.clientY, window.innerHeight - bounds.height - gap);
        contextMenu.style.left = `${Math.max(gap, left)}px`;
        contextMenu.style.top = `${Math.max(gap, top)}px`;
    };

    const renderContextMenu = (event, items) => {
        event.preventDefault();
        event.stopPropagation();
        contextMenu.innerHTML = '';

        items.forEach((item) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = item.danger ? 'is-danger' : '';
            button.innerHTML = `${item.icon ? `<i class="bi ${escapeHtml(item.icon)}"></i>` : ''}<span>${escapeHtml(item.label)}</span>`;
            button.addEventListener('click', (clickEvent) => {
                clickEvent.stopPropagation();
                item.action?.();
            });
            contextMenu.appendChild(button);
        });

        positionContextMenu(event);
    };

    const renderContextSubmenu = (title, items) => {
        contextMenu.innerHTML = '';

        const header = document.createElement('div');
        header.className = 'grade-admin__context-menu-head';

        const back = document.createElement('button');
        back.type = 'button';
        back.innerHTML = '<i class="bi bi-arrow-left"></i><span>Voltar</span>';
        header.appendChild(back);

        const label = document.createElement('strong');
        label.textContent = title;
        header.appendChild(label);
        contextMenu.appendChild(header);

        items.forEach((item) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.innerHTML = `${item.icon ? `<i class="bi ${escapeHtml(item.icon)}"></i>` : ''}<span>${escapeHtml(item.label)}</span>`;
            button.addEventListener('click', (clickEvent) => {
                clickEvent.stopPropagation();
                item.action?.();
            });
            contextMenu.appendChild(button);
        });

        back.addEventListener('click', closeContextMenu);
    };

    document.addEventListener('click', closeContextMenu);
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeContextMenu();
        }
    });
    window.addEventListener('scroll', closeContextMenu, true);

    const updateRequestStatus = async (request, statusKey) => {
        const briefingId = String(request?.dataset.briefingId || '').trim();

        if (!statusUpdateUrl || !briefingId || !statusKey) {
            showToast('Nao encontrei os dados para atualizar o status.', 'warning');
            return;
        }

        try {
            const response = await fetch(statusUpdateUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: new URLSearchParams({ briefing_id: briefingId, status: statusKey }).toString(),
            });
            const payload = await response.json();

            if (!response.ok || !payload.ok) {
                throw new Error(payload.message || 'Nao foi possivel atualizar o status.');
            }

            const status = payload.status || {};
            const badge = request.querySelector('[data-request-status-badge]');
            const label = status.label || status.nome || statusKey;

            request.dataset.statusKey = status.key || statusKey;
            request.dataset.statusLabel = label;
            request.dataset.statusTone = status.tone || 'info';

            if (badge) {
                resetToneClasses(badge);
                badge.classList.add(toneClassName(status.tone || 'info'));
                badge.textContent = label;
                badge.title = label;
            }

            showToast(payload.message || `Status atualizado para ${label}.`, 'success');
        } catch (error) {
            showToast(error.message || 'Nao foi possivel atualizar o status.', 'warning');
        }
    };

    const updateRequestPriority = async (request, priorityKey) => {
        const briefingId = String(request?.dataset.briefingId || '').trim();

        if (!priorityUpdateUrl || !briefingId || !priorityKey) {
            showToast('Nao encontrei os dados para atualizar a prioridade.', 'warning');
            return;
        }

        try {
            const response = await fetch(priorityUpdateUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: new URLSearchParams({ briefing_id: briefingId, priority: priorityKey }).toString(),
            });
            const payload = await response.json();

            if (!response.ok || !payload.ok) {
                throw new Error(payload.message || 'Nao foi possivel atualizar a prioridade.');
            }

            const priority = payload.priority || {};
            const badge = request.querySelector('[data-request-priority-badge]');
            const label = priority.label || priority.nome || priorityKey;

            request.dataset.priorityKey = priority.key || priorityKey;

            if (badge) {
                resetToneClasses(badge);
                badge.classList.add(toneClassName(priority.tone || 'neutral'));
                badge.textContent = label;
                badge.title = label;
            }

            showToast(payload.message || `Prioridade atualizada para ${label}.`, 'success');
        } catch (error) {
            showToast(error.message || 'Nao foi possivel atualizar a prioridade.', 'warning');
        }
    };

    const showRequestContextMenu = (event, request) => {
        const editUrl = request.dataset.editUrl || '';

        renderContextMenu(event, [
            {
                label: 'Mudar Status',
                icon: 'bi-arrow-repeat',
                action: () => renderContextSubmenu('Mudar Status', (solicitationStatuses.length ? solicitationStatuses : [
                    { key: 'aberto', label: 'Aberto', icon: 'bi-inbox' },
                    { key: 'analisando', label: 'Analisando', icon: 'bi-search' },
                    { key: 'aprovado', label: 'Aprovado', icon: 'bi-check2-circle' },
                    { key: 'rejeitado', label: 'Rejeitado', icon: 'bi-x-circle' },
                ]).map((status) => ({
                    label: status.label || status.nome || status.key,
                    icon: status.icon || 'bi-circle',
                    action: () => {
                        closeContextMenu();
                        updateRequestStatus(request, status.key);
                    },
                }))),
            },
            {
                label: 'Mudar Prioridade',
                icon: 'bi-flag',
                action: () => renderContextSubmenu('Mudar Prioridade', (priorityOptions.length ? priorityOptions : [
                    { key: 'baixa', label: 'Baixa' },
                    { key: 'media', label: 'Media' },
                    { key: 'alta', label: 'Alta' },
                    { key: 'critica', label: 'Critica' },
                ]).map((priority) => ({
                    label: priority.label || priority.nome || priority.key,
                    icon: 'bi-flag',
                    action: () => {
                        closeContextMenu();
                        updateRequestPriority(request, priority.key);
                    },
                }))),
            },
            {
                label: 'Editar',
                icon: 'bi-pencil-square',
                action: () => {
                    closeContextMenu();
                    if (editUrl) {
                        window.location.href = editUrl;
                    }
                },
            },
        ]);
    };

    const showCalendarContextMenu = (event, calendarEvent) => {
        const editUrl = calendarEvent.extendedProps.editUrl || calendarEvent.url || '';

        renderContextMenu(event, [
            {
                label: 'Remover',
                icon: 'bi-calendar-x',
                danger: true,
                action: () => {
                    closeContextMenu();
                    removeEventFromGrade(calendarEvent);
                },
            },
            {
                label: 'Editar',
                icon: 'bi-pencil-square',
                action: () => {
                    closeContextMenu();
                    if (editUrl) {
                        window.location.href = editUrl;
                    }
                },
            },
        ]);
    };

    const buildEvent = (item) => {
        const slot = Math.max(1, Number(item.slot || item.extendedProps?.slot || 1));

        return {
            id: String(item.id || ''),
            title: item.title || 'Pedido sem titulo',
            url: item.edit_url || item.editUrl || item.url || item.extendedProps?.editUrl || '',
            start: eventStart({ ...item, slot }),
            allDay: false,
            editable: !calendarLocked,
            backgroundColor: item.channel_color || item.backgroundColor || '#1E5B8F',
            borderColor: item.channel_color || item.borderColor || '#1E5B8F',
            textColor: '#ffffff',
            classNames: ['planner-event'],
            extendedProps: {
                briefingId: String(item.briefing_id || item.briefingId || ''),
                channel: item.channel || item.extendedProps?.channel || 'Canal nao informado',
                area: item.area || item.extendedProps?.area || 'A definir',
                type: item.type || item.extendedProps?.type || '',
                editUrl: item.edit_url || item.editUrl || item.url || item.extendedProps?.editUrl || '',
                statusLabel: item.statusLabel || item.extendedProps?.statusLabel || 'Planejado',
                capacityUnits: Number(item.capacityUnits || item.extendedProps?.capacityUnits || 1),
                slot,
                canMove: !calendarLocked,
            },
        };
    };

    const syncCounters = (calendar) => {
        if (scheduledCount) {
            scheduledCount.textContent = String(calendar.getEvents().length);
        }

        if (pendingCount && requestList) {
            pendingCount.textContent = String(requestList.querySelectorAll('.grade-admin__request:not(.is-scheduled)').length);
        }

        applyGradeAdminQueueFilter(root);
    };

    const removePendingRequest = (briefingId) => {
        if (!requestList || !briefingId) return;
        const request = [...requestList.querySelectorAll('.grade-admin__request')]
            .find((item) => String(item.dataset.briefingId || '') === String(briefingId));
        request?.remove();
    };

    const bindRequestCard = (request) => {
        if (request.dataset.requestBound === '1') return;
        request.dataset.requestBound = '1';

        const guideFromRequest = () => guideRequestPlacement({
            title: request.dataset.title || request.textContent.trim(),
            channel: request.dataset.channel || '',
            area: request.dataset.area || '',
            startDate: calendarStart,
        });

        request.addEventListener('pointerdown', guideFromRequest);
        request.addEventListener('mouseenter', () => {
            if (!root.classList.contains('is-guiding-drop')) {
                renderHint(calendar, {
                    title: request.dataset.title || request.textContent.trim(),
                    channel: request.dataset.channel || '',
                    area: request.dataset.area || '',
                    startDate: calendarStart,
                });
            }
        });

        request.addEventListener('click', () => {
            clearSelectedRequests();
            request.classList.add('is-selected');

            if (request.dataset.editUrl) {
                window.location.href = request.dataset.editUrl;
            }
        });

        request.addEventListener('contextmenu', (event) => {
            clearSelectedRequests();
            request.classList.add('is-selected');
            showRequestContextMenu(event, request);
        });
    };

    const restorePendingRequest = (briefing) => {
        if (!requestList || !briefing?.id || requestList.querySelector(`[data-briefing-id="${briefing.id}"]`)) {
            return;
        }

        requestList.querySelector('.grade-admin__empty')?.remove();

        const request = document.createElement('article');
        request.className = 'grade-admin__request';
        request.draggable = true;
        request.dataset.briefingId = String(briefing.id);
        request.dataset.title = briefing.title || 'Pedido sem titulo';
        request.dataset.channel = briefing.channel || 'Canal nao informado';
        request.dataset.channelColor = briefing.channel_color || '#1E5B8F';
        request.dataset.area = briefing.area || 'A definir';
        request.dataset.type = briefing.type || 'Encaixe';
        request.dataset.originCategory = briefing.origin_category || 'briefing';
        request.dataset.originLabel = briefing.origin_label || 'Briefing';
        request.dataset.statusKey = briefing.status?.key || 'aberto';
        request.dataset.statusLabel = briefing.status?.label || briefing.status?.nome || 'Aberto';
        request.dataset.statusTone = briefing.status?.tone || 'info';
        request.dataset.priorityKey = briefing.priority_key || 'media';
        request.dataset.editUrl = briefing.edit_url || '';
        request.title = briefing.title || 'Pedido sem titulo';

        const code = document.createElement('span');
        code.className = 'grade-admin__request-code';
        code.textContent = briefing.codigo || `BRF-${briefing.id}`;
        request.appendChild(code);

        const title = document.createElement('strong');
        title.textContent = briefing.title || 'Pedido sem titulo';
        title.title = briefing.title || 'Pedido sem titulo';
        request.appendChild(title);

        const metaCopy = document.createElement('p');
        metaCopy.textContent = `${briefing.channel || 'Canal nao informado'} · ${briefing.area || 'A definir'}`;
        metaCopy.title = `${briefing.channel || 'Canal nao informado'} - ${briefing.area || 'A definir'}`;
        request.appendChild(metaCopy);

        const meta = document.createElement('div');
        meta.className = 'grade-admin__request-meta';

        const status = briefing.status || { key: 'aberto', label: 'Aberto', tone: 'info' };
        const statusBadge = document.createElement('span');
        statusBadge.className = `mini-badge grade-admin__status-badge ${toneClassName(status.tone || 'info')}`;
        statusBadge.dataset.requestStatusBadge = '1';
        statusBadge.textContent = status.label || status.nome || 'Aberto';
        statusBadge.title = statusBadge.textContent;
        meta.appendChild(statusBadge);

        const origin = document.createElement('span');
        origin.className = 'mini-badge is-neutral';
        origin.textContent = briefing.origin_label || 'Briefing';
        origin.title = briefing.origin_label || 'Briefing';
        meta.appendChild(origin);

        const priority = document.createElement('span');
        priority.className = `mini-badge ${briefing.priority_class || 'is-neutral'}`;
        priority.dataset.requestPriorityBadge = '1';
        priority.textContent = briefing.priority_label || 'Media';
        priority.title = priority.textContent;
        meta.appendChild(priority);

        const date = document.createElement('span');
        date.textContent = briefing.date_label || 'Sem data';
        meta.appendChild(date);

        request.appendChild(meta);
        requestList.prepend(request);
        bindRequestCard(request);
        applyGradeAdminQueueFilter(root);
    };

    const isPointerOutsideCalendar = (jsEvent) => {
        if (!jsEvent || typeof jsEvent.clientX !== 'number' || typeof jsEvent.clientY !== 'number') {
            return false;
        }

        const bounds = calendarNode.getBoundingClientRect();

        return jsEvent.clientX < bounds.left
            || jsEvent.clientX > bounds.right
            || jsEvent.clientY < bounds.top
            || jsEvent.clientY > bounds.bottom;
    };

    const removeEventFromGrade = async (event) => {
        const itemId = String(event.id || '');

        if (!removeUrl || !itemId || itemId.startsWith('pending-')) {
            return;
        }

        try {
            const response = await fetch(removeUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                },
                body: new URLSearchParams({
                    item_id: itemId,
                    periodo_id: periodId,
                }).toString(),
            });

            const payload = await response.json();

            if (!response.ok || !payload.ok) {
                throw new Error(payload.message || 'Nao foi possivel remover o evento da grade.');
            }

            event.remove();
            restorePendingRequest(payload.briefing);
            syncCounters(calendar);
            renderHint(calendar, null);
            showToast(payload.message || 'Evento removido da grade.', 'success');
        } catch (error) {
            showToast(error.message || 'Nao foi possivel remover o evento da grade.', 'warning');
        }
    };

    const initialCalendarDate = (() => {
        const today = toIsoDate(new Date());
        return today >= calendarStart && today <= calendarEnd ? today : calendarStart;
    })();

    const calendar = new FullCalendar.Calendar(calendarNode, {
        locale: 'pt-br',
        firstDay: 1,
        initialView: 'gradeWindow',
        initialDate: initialCalendarDate || calendarStart || undefined,
        headerToolbar: {
            left: 'prev',
            center: 'title',
            right: 'next',
        },
        buttonText: {
            prev: '‹',
            next: '›',
        },
        dateIncrement: { weeks: 1 },
        dateAlignment: 'week',
        titleFormat: {
            day: '2-digit',
            month: 'long',
            year: 'numeric',
        },
        views: {
            gradeWindow: {
                type: 'timeGrid',
                duration: { days: 7 },
                allDaySlot: false,
                slotMinTime: '08:00:00',
                slotMaxTime: '21:00:00',
                slotDuration: '00:30:00',
            },
        },
        slotLabelFormat: {
            hour: '2-digit',
            minute: '2-digit',
            hour12: false,
        },
        height: 'auto',
        editable: !calendarLocked,
        eventStartEditable: !calendarLocked,
        eventDurationEditable: false,
        defaultTimedEventDuration: '00:30:00',
        forceEventDuration: true,
        slotEventOverlap: false,
        droppable: !calendarLocked,
        dayMaxEvents: 25,
        fixedWeekCount: false,
        validRange: calendarStart && calendarEnd ? {
            start: calendarStart,
            end: addOneDay(calendarEnd),
        } : undefined,
        eventAllow(dropInfo) {
            return isBusinessDay(dateKey(dropInfo.start));
        },
        events: initialEvents.map((event) => buildEvent({
            ...event,
            date: event.start,
            channel: event.extendedProps?.channel,
            area: event.extendedProps?.area,
            type: event.extendedProps?.type,
            editUrl: event.extendedProps?.editUrl || event.url,
            statusLabel: event.extendedProps?.statusLabel,
            capacityUnits: event.extendedProps?.capacityUnits,
            slot: event.extendedProps?.slot,
        })),
        dayHeaderContent(arg) {
            const wrapper = document.createElement('div');
            wrapper.className = 'grade-admin__day-header';

            const weekDay = document.createElement('span');
            weekDay.textContent = shortWeekday(arg.date);
            wrapper.appendChild(weekDay);

            const dateLabel = document.createElement('strong');
            dateLabel.textContent = dayMonth(arg.date);
            wrapper.appendChild(dateLabel);

            return { domNodes: [wrapper] };
        },
        dayHeaderClassNames(arg) {
            return isBusinessDay(dateKey(arg.date)) ? [] : ['is-weekend-disabled'];
        },
        dayCellContent(arg) {
            if (arg.view.type !== 'dayGridMonth') {
                return undefined;
            }

            const wrapper = document.createElement('div');
            wrapper.className = 'grade-admin__day-cell-date';

            const weekDay = document.createElement('span');
            weekDay.textContent = shortWeekday(arg.date);
            wrapper.appendChild(weekDay);

            const dateLabel = document.createElement('strong');
            dateLabel.textContent = dayMonth(arg.date);
            wrapper.appendChild(dateLabel);

            return { domNodes: [wrapper] };
        },
        dayCellClassNames(arg) {
            return isBusinessDay(dateKey(arg.date)) ? [] : ['is-weekend-disabled'];
        },
        eventClick(info) {
            info.jsEvent?.preventDefault?.();
            clearSelectedRequests();
            const editUrl = info.event.extendedProps.editUrl || info.event.url;

            if (editUrl) {
                window.location.href = editUrl;
                return;
            }

            renderHint(calendar, {
                title: info.event.title,
                channel: info.event.extendedProps.channel,
                area: info.event.extendedProps.area,
                excludeEvent: info.event,
                startDate: dateKey(info.event.start || info.event.startStr),
            });
        },
        async eventReceive(info) {
            clearDropGuidance();

            if (calendarLocked) {
                info.event.remove();
                showToast('Esta grade ja foi fechada e nao pode mais ser editada.', 'warning');
                return;
            }

            const briefingId = info.event.extendedProps.briefingId;
            const channel = info.event.extendedProps.channel;
            const targetDate = dateKey(info.event.start || info.event.startStr);
            const targetSlot = slotFromDate(info.event.start || info.event.startStr);
            const rule = getChannelRule(channel);

            if (!targetDate) {
                info.event.remove();
                showToast('Solte o pedido em uma data valida dentro da grade.', 'warning');
                return;
            }

            if (!isBusinessDay(targetDate)) {
                info.event.remove();
                showToast('Sabado e domingo nao ficam disponiveis para encaixe na grade.', 'warning');
                return;
            }

            if (usedSlots(calendar, channel, targetDate, info.event) >= rule.limit) {
                const nextDate = nextBusinessFreeDate(calendar, channel, info.event, targetDate);
                info.event.remove();
                showToast(nextDate
                    ? `Limite do canal atingido. Proximo dia util livre: ${formatDateLabel(nextDate)}.`
                    : 'Limite do canal atingido e nao ha dia util livre nesta grade.', 'warning');
                renderHint(calendar, { title: info.event.title, channel, startDate: targetDate });
                return;
            }

            try {
                info.event.setExtendedProp('slot', targetSlot);

                const response = await fetch(scheduleUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    },
                    body: new URLSearchParams({
                        briefing_id: briefingId,
                        periodo_id: periodId,
                        data_publicacao: targetDate,
                        slot: targetSlot,
                    }).toString(),
                });

                const payload = await response.json();

                if (!response.ok || !payload.ok) {
                    throw new Error(payload.message || 'Nao foi possivel encaixar o pedido.');
                }

                info.event.remove();
                const createdEvent = calendar.addEvent(buildEvent(payload.item));
                removePendingRequest(briefingId);
                clearSelectedRequests();
                syncCounters(calendar);
                renderHint(calendar, {
                    title: createdEvent.title,
                    channel: createdEvent.extendedProps.channel,
                    excludeEvent: createdEvent,
                    startDate: dateKey(createdEvent.start || createdEvent.startStr),
                });
                showToast(payload.message || 'Pedido encaixado na grade.', 'success');
            } catch (error) {
                info.event.remove();
                showToast(error.message || 'Nao foi possivel encaixar o pedido.', 'warning');
            }
        },
        async eventDrop(info) {
            clearDropGuidance();

            if (calendarLocked) {
                info.revert();
                showToast('Esta grade ja foi fechada e nao pode mais ser editada.', 'warning');
                return;
            }

            const channel = info.event.extendedProps.channel;
            const targetDate = dateKey(info.event.start || info.event.startStr);
            const targetSlot = slotFromDate(info.event.start || info.event.startStr);
            const rule = getChannelRule(channel);

            if (!isBusinessDay(targetDate)) {
                info.revert();
                showToast('Sabado e domingo nao ficam disponiveis para encaixe na grade.', 'warning');
                return;
            }

            if (usedSlots(calendar, channel, targetDate, info.event) >= rule.limit) {
                const nextDate = nextBusinessFreeDate(calendar, channel, info.event, targetDate);
                info.revert();
                showToast(nextDate
                    ? `Limite do canal atingido. Proximo dia util livre: ${formatDateLabel(nextDate)}.`
                    : 'Limite do canal atingido e nao ha dia util livre nesta grade.', 'warning');
                return;
            }

            try {
                const response = await fetch(moveUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    },
                    body: new URLSearchParams({
                        item_id: info.event.id,
                        periodo_id: periodId,
                        data_publicacao: targetDate,
                        slot: targetSlot,
                    }).toString(),
                });

                const payload = await response.json();

                if (!response.ok || !payload.ok) {
                    throw new Error(payload.message || 'Nao foi possivel mover o evento.');
                }

                info.event.setExtendedProp('slot', Number(payload.slot || targetSlot));
                renderHint(calendar, {
                    title: info.event.title,
                    channel,
                    excludeEvent: info.event,
                    startDate: targetDate,
                });
                showToast('Evento movido no calendario.', 'success');
            } catch (error) {
                info.revert();
                showToast(error.message || 'Nao foi possivel mover o evento.', 'warning');
            }
        },
        eventDragStart(info) {
            guideRequestPlacement({
                title: info.event.title,
                channel: info.event.extendedProps.channel,
                excludeEvent: info.event,
                startDate: dateKey(info.event.start || info.event.startStr) || calendarStart,
            });
        },
        eventDragStop(info) {
            if (!calendarLocked && isPointerOutsideCalendar(info.jsEvent)) {
                removeEventFromGrade(info.event);
            }

            window.setTimeout(clearDropGuidance, 180);
        },
        eventDidMount(info) {
            info.el.addEventListener('contextmenu', (event) => {
                showCalendarContextMenu(event, info.event);
            });
        },
        eventContent(arg) {
            const wrapper = document.createElement('div');
            wrapper.className = 'planning-event-card';

            const title = document.createElement('strong');
            title.textContent = arg.event.title;
            title.title = arg.event.title;
            wrapper.appendChild(title);

            const channel = document.createElement('span');
            channel.className = 'planning-event-card__channel';
            channel.textContent = arg.event.extendedProps.channel || 'Canal';
            channel.title = arg.event.extendedProps.channel || 'Canal';
            wrapper.appendChild(channel);

            const meta = document.createElement('span');
            meta.textContent = [
                eventTimeLabel(arg.event.start),
                arg.event.extendedProps.type,
                arg.event.extendedProps.area || 'Area',
            ].filter(Boolean).join(' - ');
            meta.title = meta.textContent;
            wrapper.appendChild(meta);

            return { domNodes: [wrapper] };
        },
    });

    calendar.render();
    syncCounters(calendar);
    renderHint(calendar, null);

    if (!calendarLocked && requestList && FullCalendar.Draggable) {
        new FullCalendar.Draggable(requestList, {
            itemSelector: '.grade-admin__request',
            eventData(eventEl) {
                const briefingId = eventEl.dataset.briefingId || '';
                const nextSlot = Math.max(1, calendar.getEvents().length + 1);

                return {
                    id: briefingId ? `pending-${briefingId}` : '',
                    title: eventEl.dataset.title || 'Pedido sem titulo',
                    url: eventEl.dataset.editUrl || '',
                    backgroundColor: eventEl.dataset.channelColor || '#1E5B8F',
                    borderColor: eventEl.dataset.channelColor || '#1E5B8F',
                    textColor: '#ffffff',
                    extendedProps: {
                        briefingId,
                        channel: eventEl.dataset.channel || 'Canal nao informado',
                        area: eventEl.dataset.area || 'A definir',
                        type: eventEl.dataset.type || '',
                        editUrl: eventEl.dataset.editUrl || '',
                        capacityUnits: 1,
                        slot: nextSlot,
                        canMove: false,
                    },
                };
            },
        });

        requestList.querySelectorAll('.grade-admin__request').forEach(bindRequestCard);

        document.addEventListener('pointerup', () => {
            window.setTimeout(clearDropGuidance, 220);
        });
    }

    requestList?.querySelectorAll('.grade-admin__request').forEach(bindRequestCard);

    finalizeButton?.addEventListener('click', () => {
        if (!finalizePeriodUrl || !periodId || periodClosed) return;

        setFinalizeModalOpen(true);
    });

    finalizeConfirmButton?.addEventListener('click', async () => {
        if (!finalizePeriodUrl || !periodId || periodClosed) return;

        finalizeButton && (finalizeButton.disabled = true);
        finalizeConfirmButton.disabled = true;

        try {
            const response = await fetch(finalizePeriodUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                },
                body: new URLSearchParams({
                    periodo_id: periodId,
                }).toString(),
            });
            const payload = await response.json();

            if (!response.ok || !payload.ok) {
                throw new Error(payload.message || 'Nao consegui fechar a grade agora.');
            }

            setFinalizeModalOpen(false);
            showToast(payload.message || 'Grade fechada.', 'success');
            window.location.reload();
        } catch (error) {
            showToast(error.message || 'Tive um problema ao fechar a grade.', 'warning');
        } finally {
            finalizeButton && (finalizeButton.disabled = false);
            finalizeConfirmButton.disabled = false;
        }
    });
}

function initPlanningCalendarPage() {
    const root = document.getElementById('planningCalendarPage');
    const calendarNode = document.getElementById('planningCalendar');
    const eventsNode = document.getElementById('planningCalendarEvents');

    if (!root || !calendarNode || !eventsNode || typeof FullCalendar === 'undefined') {
        return;
    }

    let events = [];

    try {
        events = JSON.parse(eventsNode.textContent || '[]');
    } catch (error) {
        events = [];
    }

    const periodId = String(root.dataset.periodId || '').trim();
    const initialDate = String(root.dataset.initialDate || '').trim();
    const periodStart = String(root.dataset.periodStart || '').trim();
    const periodEnd = String(root.dataset.periodEnd || '').trim();
    const moveUrl = String(root.dataset.moveUrl || '').trim();
    const dayUrlBase = String(root.dataset.dayUrlBase || '').trim();
    const source = String(root.dataset.source || '').trim();

    const buildDayUrl = (dateString) => {
        const target = new URL(dayUrlBase, window.location.origin);
        target.searchParams.set('date', dateString);
        return target.toString();
    };

    const calendar = new FullCalendar.Calendar(calendarNode, {
        locale: 'pt-br',
        initialView: 'dayGridMonth',
        initialDate: initialDate || undefined,
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth',
        },
        buttonText: {
            today: 'Hoje',
            month: 'Mês',
        },
        height: 'auto',
        editable: true,
        eventStartEditable: true,
        dayMaxEvents: 3,
        fixedWeekCount: false,
        validRange: periodStart && periodEnd ? {
            start: periodStart,
            end: addOneDay(periodEnd),
        } : undefined,
        events,
        dateClick(info) {
            window.location.href = buildDayUrl(info.dateStr);
        },
        eventClick(info) {
            info.jsEvent.preventDefault();
            window.location.href = info.event.extendedProps.dayUrl || buildDayUrl(info.event.startStr);
        },
        async eventDrop(info) {
            const canMove = Boolean(info.event.extendedProps.canMove);

            if (!canMove || !moveUrl || source !== 'database') {
                info.revert();
                showToast('Este evento não pode ser movido neste modo.', 'warning');
                return;
            }

            try {
                const response = await fetch(moveUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    },
                    body: new URLSearchParams({
                        item_id: info.event.id,
                        periodo_id: periodId,
                        data_publicacao: info.event.startStr,
                    }).toString(),
                });

                const payload = await response.json();

                if (!response.ok || !payload.ok) {
                    throw new Error(payload.message || 'Não foi possível mover o evento.');
                }

                info.event.setExtendedProp('dayUrl', buildDayUrl(info.event.startStr));
                showToast('Evento movido no calendário.', 'success');
            } catch (error) {
                info.revert();
                showToast(error.message || 'Não foi possível mover o evento.', 'warning');
            }
        },
        eventContent(arg) {
            const wrapper = document.createElement('div');
            wrapper.className = 'planning-event-card';

            const title = document.createElement('strong');
            title.textContent = arg.event.title;
            wrapper.appendChild(title);

            const meta = document.createElement('span');
            meta.textContent = `${arg.event.extendedProps.channel || 'Canal'} • ${arg.event.extendedProps.area || 'Área'}`;
            wrapper.appendChild(meta);

            return { domNodes: [wrapper] };
        },
    });

    calendar.render();
}

function addOneDay(dateString) {
    if (!dateString) {
        return dateString;
    }

    const baseDate = new Date(`${dateString}T00:00:00`);

    if (Number.isNaN(baseDate.getTime())) {
        return dateString;
    }

    baseDate.setDate(baseDate.getDate() + 1);
    return baseDate.toISOString().slice(0, 10);
}

function formatFileSize(bytes) {
    const size = Number(bytes || 0);

    if (size <= 0) {
        return '0 KB';
    }

    if (size < 1024 * 1024) {
        return `${Math.max(1, Math.round(size / 1024))} KB`;
    }

    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function playBriefingSentCelebration() {
    const celebration = document.getElementById('sendCelebration');
    if (!celebration) {
        return Promise.resolve();
    }

    celebration.classList.add('is-visible');
    celebration.setAttribute('aria-hidden', 'false');

    return new Promise((resolve) => {
        window.setTimeout(() => {
            celebration.classList.remove('is-visible');
            celebration.setAttribute('aria-hidden', 'true');
            resolve();
        }, 2200);
    });
}

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function hexToRgba(hex, alpha = 1) {
    const normalized = String(hex || '').replace('#', '');
    if (normalized.length !== 6) {
        return `rgba(255, 255, 255, ${alpha})`;
    }

    const red = parseInt(normalized.slice(0, 2), 16);
    const green = parseInt(normalized.slice(2, 4), 16);
    const blue = parseInt(normalized.slice(4, 6), 16);
    return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
}
